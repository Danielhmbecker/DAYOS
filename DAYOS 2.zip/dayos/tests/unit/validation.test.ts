import { describe, expect, it } from 'vitest'
import {
  loginSchema,
  setupSchema,
  transactionSchema,
  shiftSchema,
  taskSchema,
  noteSchema,
  stockItemSchema,
  changePasswordSchema,
} from '@/lib/validation/schemas'

describe('validation schemas', () => {
  it('accepts a valid login', () => {
    expect(loginSchema.safeParse({ email: 'a@b.co', password: 'x' }).success).toBe(true)
  })

  it('accepts a bare username for login but rejects empty identifiers', () => {
    expect(loginSchema.safeParse({ email: 'root', password: 'x' }).success).toBe(true)
    expect(loginSchema.safeParse({ email: '', password: 'x' }).success).toBe(false)
    expect(loginSchema.safeParse({ email: 'a@b.co', password: '' }).success).toBe(false)
  })

  it('enforces owner password strength', () => {
    expect(setupSchema.safeParse({ name: 'Dan', email: 'a@b.co', password: 'short' }).success).toBe(false)
    expect(
      setupSchema.safeParse({ name: 'Dan', email: 'a@b.co', password: 'Sup3rSecret!!' }).success,
    ).toBe(true)
  })

  it('coerces transaction amounts and rejects negatives', () => {
    expect(transactionSchema.safeParse({ type: 'EXPENSE', amount: '12.50', date: '2026-09-01' }).success).toBe(true)
    expect(transactionSchema.safeParse({ type: 'EXPENSE', amount: '-5', date: '2026-09-01' }).success).toBe(false)
    expect(transactionSchema.safeParse({ type: 'NOPE', amount: '5', date: '2026-09-01' }).success).toBe(false)
  })

  it('rejects identical shift start/end', () => {
    expect(
      shiftSchema.safeParse({ date: '2026-09-01', startTime: '17:00', endTime: '17:00' }).success,
    ).toBe(false)
  })

  it('validates tasks, notes and stock items', () => {
    expect(taskSchema.safeParse({ title: 'Do thing' }).success).toBe(true)
    expect(taskSchema.safeParse({ title: '' }).success).toBe(false)
    expect(noteSchema.safeParse({ title: 'Hi' }).success).toBe(true)
    expect(stockItemSchema.safeParse({ name: 'Keg' }).success).toBe(true)
  })

  it('requires matching password confirmation', () => {
    expect(
      changePasswordSchema.safeParse({
        currentPassword: 'a',
        newPassword: 'Sup3rSecret!!',
        confirm: 'Sup3rSecret!!',
      }).success,
    ).toBe(true)
    expect(
      changePasswordSchema.safeParse({
        currentPassword: 'a',
        newPassword: 'Sup3rSecret!!',
        confirm: 'different',
      }).success,
    ).toBe(false)
  })
})
