import { describe, expect, it } from 'vitest'
import { formatMoney, greeting, relativeDays, startOfMonth, endOfMonth } from '@/lib/utils'

describe('formatting helpers', () => {
  it('formats GBP by default', () => {
    expect(formatMoney(1284.5)).toBe('£1,284.50')
  })

  it('formats other currencies when configured', () => {
    expect(formatMoney(10, 'EUR')).toContain('10.00')
  })

  it('greets by time of day', () => {
    expect(greeting(new Date(2026, 8, 23, 8))).toBe('Good morning')
    expect(greeting(new Date(2026, 8, 23, 14))).toBe('Good afternoon')
    expect(greeting(new Date(2026, 8, 23, 21))).toBe('Good evening')
  })

  it('describes relative days', () => {
    const today = new Date(2026, 8, 23)
    expect(relativeDays(new Date(2026, 8, 23), today)).toBe('today')
    expect(relativeDays(new Date(2026, 8, 25), today)).toBe('in 2 days')
    expect(relativeDays(new Date(2026, 8, 20), today)).toBe('3 days ago')
  })

  it('bounds months correctly', () => {
    const s = startOfMonth(new Date(2026, 1, 15))
    const e = endOfMonth(new Date(2026, 1, 15))
    expect(s.getDate()).toBe(1)
    expect(e.getDate()).toBe(28)
  })
})
