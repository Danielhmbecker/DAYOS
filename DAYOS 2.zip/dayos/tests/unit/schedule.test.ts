import { describe, expect, it } from 'vitest'
import {
  workedMinutes,
  overtimeMinutes,
  shiftPay,
  hoursLabel,
  scheduleStatus,
  addFrequency,
  frequencyDays,
} from '@/lib/calc/schedule'

const at = (day: number, h: number, m = 0) => new Date(2026, 8, day, h, m, 0, 0)

describe('shift calculations', () => {
  it('computes worked minutes subtracting breaks', () => {
    expect(workedMinutes(at(1, 17), at(1, 23, 30), 30)).toBe(360)
  })

  it('supports shifts crossing midnight', () => {
    expect(workedMinutes(at(1, 22), at(2, 6), 0)).toBe(480)
    expect(workedMinutes(at(1, 22), at(1, 6), 0)).toBe(480) // end recorded as next-day time
  })

  it('never returns negative minutes', () => {
    expect(workedMinutes(at(1, 10), at(1, 10), 30)).toBe(0)
  })

  it('splits overtime at the threshold', () => {
    expect(overtimeMinutes(600, 480)).toBe(120)
    expect(overtimeMinutes(400, 480)).toBe(0)
  })

  it('pays overtime at the configured multiplier', () => {
    // 16:00 → 01:00 = 9h, minus 30m break = 8h30m worked → 30m overtime
    const pay = shiftPay(at(1, 16), at(2, 1, 0), 30, 14.5, 480, 1.5)
    expect(pay.workedMinutes).toBe(480 + 30)
    expect(pay.overtimeMinutes).toBe(30)
    // 8h × 14.5 + 0.5h × 14.5 × 1.5 = 116 + 10.875
    expect(pay.pay).toBe(126.88)
  })

  it('formats hour labels', () => {
    expect(hoursLabel(480)).toBe('8h')
    expect(hoursLabel(510)).toBe('8h 30m')
  })
})

describe('recurring schedule status', () => {
  it('marks never-completed items due', () => {
    expect(scheduleStatus(null, 'WEEKLY')).toBe('due')
  })

  it('marks fresh items ok', () => {
    expect(scheduleStatus(new Date(), 'WEEKLY')).toBe('ok')
  })

  it('marks overdue items', () => {
    const last = new Date()
    last.setDate(last.getDate() - 10)
    expect(scheduleStatus(last, 'WEEKLY')).toBe('overdue')
  })

  it('marks items due on their due day', () => {
    const last = new Date()
    last.setDate(last.getDate() - 7)
    last.setHours(23, 59, 0, 0)
    expect(scheduleStatus(last, 'WEEKLY')).toBe('due')
  })

  it('adds frequency intervals', () => {
    const base = new Date(2026, 0, 31)
    expect(addFrequency(base, 'MONTHLY').getMonth()).toBe(1)
    expect(addFrequency(base, 'YEARLY').getFullYear()).toBe(2027)
    expect(frequencyDays('DAILY')).toBe(1)
  })
})
