import { expect, test, type Page } from '@playwright/test'

const DEMO_EMAIL = 'dan@dayos.app'
const DEMO_PASSWORD = 'DemoPass123!'
const OWNER_EMAIL = `owner-${Date.now()}@e2e.dayos`
const OWNER_PASSWORD = 'Sup3rSecret!!'

async function signIn(page: Page): Promise<void> {
  await page.goto('/login')
  // First-run setup flow when the instance has no owner yet.
  const setupTab = page.getByRole('tab', { name: 'Create account' })
  if (await setupTab.isVisible().catch(() => false)) {
    await setupTab.click()
    await page.getByLabel('Your name').fill('E2E Owner')
    await page.getByLabel('Email').fill(OWNER_EMAIL)
    await page.getByLabel('Password', { exact: true }).fill(OWNER_PASSWORD)
    await page.getByRole('button', { name: 'Create account' }).click()
  } else {
    await page.getByLabel('Email').fill(DEMO_EMAIL)
    await page.getByLabel('Password', { exact: true }).fill(DEMO_PASSWORD)
    await page.getByRole('button', { name: 'Sign in', exact: true }).click()
  }
  // Strong assertion: we must land on the dashboard, not stay on /login.
  await expect(page).toHaveURL('/')
  await expect(page.getByRole('heading', { level: 1 }).first()).toContainText(
    /Good (morning|afternoon|evening)/,
  )
}

function quickCapture(page: Page) {
  return page.getByRole('dialog', { name: 'Quick capture' })
}

/** Open quick capture in a given mode via the dashboard quick-action tiles. */
async function openQuickCapture(page: Page, mode: 'Expense' | 'Income' | 'Task' | 'Note' | 'Event') {
  await page.keyboard.press('Escape')
  await page.goto('/')
  await page.getByRole('main').getByRole('button', { name: mode, exact: true }).click()
  await expect(quickCapture(page)).toBeVisible()
}

test.describe('DAYOS core flows', () => {
  test('login → dashboard shows greeting and data', async ({ page }) => {
    await signIn(page)
    await expect(page.getByText('Available balance').first()).toBeVisible()
  })

  test('quick capture creates an expense', async ({ page }) => {
    await signIn(page)
    await openQuickCapture(page, 'Expense')
    const sheet = quickCapture(page)
    await sheet.getByLabel('Amount (£)').fill('12.34')
    await sheet.getByLabel('Note (optional)').fill('E2E coffee')
    await sheet.getByRole('button', { name: 'Log expense' }).click()
    await expect(page.getByText('Saved').first()).toBeVisible()
    await page.goto('/money?tab=transactions')
    await expect(page.getByText('E2E coffee').first()).toBeVisible()
  })

  test('create income, task and note', async ({ page }) => {
    await signIn(page)
    // Income
    await openQuickCapture(page, 'Income')
    let sheet = quickCapture(page)
    await sheet.getByLabel('Amount (£)').fill('250')
    await sheet.getByLabel('Note (optional)').fill('E2E freelance')
    await sheet.getByRole('button', { name: 'Log income' }).click()
    await expect(page.getByText('Saved').first()).toBeVisible()
    // Task
    await openQuickCapture(page, 'Task')
    sheet = quickCapture(page)
    await sheet.getByLabel('Task').fill('E2E task')
    await sheet.getByRole('button', { name: 'Add task' }).click()
    await expect(page.getByText('Saved').first()).toBeVisible()
    // Note
    await openQuickCapture(page, 'Note')
    sheet = quickCapture(page)
    await sheet.getByLabel('Note', { exact: true }).fill('E2E note body')
    await sheet.getByRole('button', { name: 'Save note' }).click()
    await expect(page.getByText('Saved').first()).toBeVisible()
    await page.goto('/tasks')
    await expect(page.getByText('E2E task').first()).toBeVisible()
    await page.goto('/notes')
    await expect(page.getByText('E2E note body').first()).toBeVisible()
  })

  test('create a shift in Work', async ({ page }) => {
    await signIn(page)
    await page.goto('/work')
    await page.getByRole('button', { name: 'Add shift' }).first().click()
    const dialog = page.getByRole('dialog', { name: 'New shift' })
    await dialog.getByLabel('Start').fill('17:00')
    await dialog.getByLabel('End').fill('23:00')
    await dialog.getByRole('button', { name: 'Add shift' }).click()
    await expect(page.getByText('Shift added').first()).toBeVisible()
    await expect(page.getByText('17:00 → 23:00').first()).toBeVisible()
  })

  test('navigates every module', async ({ page, viewport }) => {
    await signIn(page)
    const isMobile = (viewport?.width ?? 1280) < 768
    const go = async (label: string, path: string) => {
      await page.goto(path)
      await expect(page.getByRole('heading', { level: 1, name: label }).first()).toBeVisible()
    }
    await go('Money', '/money')
    await go('Work', '/work')
    await go('Career', '/career')
    await go('Notes', '/notes')
    await go('Vault', '/vault')
    await go('Calendar', '/calendar')
    await go('Tasks', '/tasks')
    await go('Stockroom', '/stockroom')
    await go('Settings', '/settings')
    await go('More', '/more')
    if (isMobile) {
      await expect(page.getByRole('navigation', { name: 'Primary' }).last()).toBeVisible()
    } else {
      await expect(page.getByRole('link', { name: 'Stockroom' }).first()).toBeVisible()
    }
  })

  test('logout returns to login', async ({ page }) => {
    await signIn(page)
    await page.getByLabel('Account menu').click()
    await page.getByRole('button', { name: 'Sign out' }).click()
    await expect(page).toHaveURL('/login')
  })
})

test.describe('PWA & mobile shell', () => {
  test('manifest and service worker are served', async ({ page }) => {
    const manifest = await page.request.get('/manifest.webmanifest')
    expect(manifest.status()).toBe(200)
    const body = await manifest.json()
    expect(body.display).toBe('standalone')
    expect(body.icons.length).toBeGreaterThan(3)
    const sw = await page.request.get('/sw.js')
    expect(sw.status()).toBe(200)
  })

  test('health endpoint responds', async ({ page }) => {
    const res = await page.request.get('/api/health')
    expect(res.status()).toBe(200)
    expect(await res.json()).toMatchObject({ status: 'ok' })
  })

  test('bottom navigation respects safe areas and touch sizes', async ({ page, viewport }) => {
    test.skip((viewport?.width ?? 1280) >= 768, 'desktop uses sidebar')
    await signIn(page)
    const nav = page.getByRole('navigation', { name: 'Primary' }).last()
    await expect(nav).toBeVisible()
    const home = nav.getByRole('link', { name: 'Home' })
    const box = await home.boundingBox()
    expect(box?.height).toBeGreaterThanOrEqual(44)
    // No horizontal scrolling
    const scroll = await page.evaluate(() => ({
      scrollW: document.documentElement.scrollWidth,
      clientW: document.documentElement.clientWidth,
    }))
    expect(scroll.scrollW).toBeLessThanOrEqual(scroll.clientW + 1)
  })
})
