/**
 * Integration test environment: an in-memory PGlite Postgres served over the
 * wire protocol on port 5439, with migrations applied. Workers connect with a
 * standard DATABASE_URL (connection_limit=1 — PGlite is single-session).
 */
import { PGlite } from '@electric-sql/pglite'
import { PGLiteSocketServer } from '@electric-sql/pglite-socket'
import { applyMigrations } from '../scripts/migrations'

const PORT = 5439

export async function setup() {
  const db = await PGlite.create()
  await applyMigrations(db)
  const server = new PGLiteSocketServer({ db, port: PORT, host: '127.0.0.1', maxConnections: 4 })

  let hadConnections = false
  const timer = setInterval(() => {
    const stats = server.getStats()
    if (stats.activeConnections > 0) hadConnections = true
    else if (hadConnections) {
      hadConnections = false
      db.exec('DEALLOCATE ALL').catch(() => {})
    }
  }, 200)

  server.addEventListener('connection', (event) => {
    const socket = (event as CustomEvent).detail as { on?: (ev: string, cb: () => void) => void }
    socket.on?.('close', () => {
      db.exec('DEALLOCATE ALL').catch(() => {})
    })
  })

  await server.start()
  process.env.DATABASE_URL = `postgresql://test:test@127.0.0.1:${PORT}/test?connection_limit=1`
  process.env.DATA_DIR = './data/test-storage'
  ;(globalThis as Record<string, unknown>).__testServer = server
  ;(globalThis as Record<string, unknown>).__testDb = db
  ;(globalThis as Record<string, unknown>).__testTimer = timer
}

export async function teardown() {
  const g = globalThis as Record<string, unknown>
  clearInterval(g.__testTimer as NodeJS.Timeout)
  await (g.__testServer as PGLiteSocketServer)?.stop()
  await (g.__testDb as PGlite)?.close()
}
