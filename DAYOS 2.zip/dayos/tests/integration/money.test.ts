import { beforeAll, describe, expect, it } from 'vitest'
import { db } from '@/lib/db/client'
import { hashPassword } from '@/lib/auth/password'
import {
  availableBalance,
  budgetProgress,
  materialiseRecurring,
  monthTotals,
  monthlySeries,
  payBill,
  upcomingBills,
} from '@/lib/services/money'

let userId: string
let foodId: string

const now = new Date()
const inMonth = (day: number, hour = 12) => new Date(now.getFullYear(), now.getMonth(), day, hour)

describe('money service', () => {
  beforeAll(async () => {
    const email = `money-${Date.now()}@test.dayos`
    const user = await db.user.create({ data: { email, name: 'Money', passwordHash: await hashPassword('Sup3rSecret!!') } })
    userId = user.id
    foodId = (await db.category.create({ data: { userId, name: 'Food', type: 'EXPENSE' } })).id
    await db.category.create({ data: { userId, name: 'Salary', type: 'INCOME' } })
  })

  it('totals income and spending for the month', async () => {
    await db.transaction.createMany({
      data: [
        { userId, type: 'INCOME', amount: 1000, date: inMonth(2) },
        { userId, type: 'EXPENSE', amount: 250, categoryId: foodId, date: inMonth(3) },
        { userId, type: 'EXPENSE', amount: 50.5, categoryId: foodId, date: inMonth(4) },
      ],
    })
    const totals = await monthTotals(userId, now)
    expect(totals.income).toBe(1000)
    expect(totals.expense).toBe(300.5)
    expect(totals.remaining).toBe(699.5)
    expect(await availableBalance(userId)).toBe(699.5)
  })

  it('produces a monthly chart series', async () => {
    const series = await monthlySeries(userId, 6)
    expect(series).toHaveLength(6)
    expect(series[5].income).toBe(1000)
    expect(series[5].expense).toBe(300.5)
  })

  it('materialises recurring transactions idempotently', async () => {
    await db.transaction.create({
      data: {
        userId,
        type: 'EXPENSE',
        amount: 35,
        categoryId: foodId,
        note: 'Weekly repeat',
        date: inMonth(1),
        recurrence: 'WEEKLY',
        nextDueDate: inMonth(1),
      },
    })
    const created = await materialiseRecurring(userId, now)
    expect(created).toBeGreaterThanOrEqual(2)
    const again = await materialiseRecurring(userId, now)
    expect(again).toBe(0)
    const instances = await db.transaction.count({ where: { userId, parentId: { not: null } } })
    expect(instances).toBe(created)
  })

  it('tracks budget progress and over-budget state', async () => {
    // Self-contained category so recurring instances from other tests don't leak in.
    const treats = await db.category.create({ data: { userId, name: 'Treats', type: 'EXPENSE' } })
    await db.transaction.create({ data: { userId, type: 'EXPENSE', amount: 250, categoryId: treats.id, date: inMonth(6) } })
    await db.budget.create({ data: { userId, categoryId: treats.id, monthlyLimit: 200 } })
    const budget = (await budgetProgress(userId, now)).find((b) => b.categoryId === treats.id)!
    expect(budget.used).toBe(250)
    expect(budget.over).toBe(true)
    expect(budget.percent).toBe(100)
  })

  it('schedules bills and records payment as an expense', async () => {
    const bill = await db.bill.create({
      data: { userId, name: 'Rent', amount: 900, frequency: 'MONTHLY', nextDueDate: inMonth(5) },
    })
    const before = await availableBalance(userId)
    await payBill(bill.id, userId, inMonth(6))
    const refreshed = await db.bill.findUnique({ where: { id: bill.id } })
    expect(refreshed!.nextDueDate.getMonth()).toBe((now.getMonth() + 1) % 12)
    expect(refreshed!.lastPaidAt).not.toBeNull()
    expect(await availableBalance(userId)).toBeLessThan(before)
    const due = await upcomingBills(userId, 60, now)
    expect(due.every((b) => b.name !== 'Rent' || b.days > 0)).toBe(true)
  })
})
