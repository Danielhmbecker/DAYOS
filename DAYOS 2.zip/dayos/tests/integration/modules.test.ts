import { beforeAll, describe, expect, it } from 'vitest'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { db } from '@/lib/db/client'
import { hashPassword } from '@/lib/auth/password'
import { deleteNote, listNotes, saveNote } from '@/lib/services/notes'
import { listStock, recordCount, cleaningStatus, completeCleaning, categoryHealth } from '@/lib/services/stockroom'
import { uploadDocument, listDocuments, deleteDocument, getDocumentForUser } from '@/lib/services/vault'
import { globalSearch } from '@/lib/services/search'
import { monthSummary } from '@/lib/services/work'
import { shiftsInRange } from '@/lib/services/work'

let userId: string

describe('module services', () => {
  beforeAll(async () => {
    const email = `mods-${Date.now()}@test.dayos`
    const user = await db.user.create({
      data: {
        email,
        name: 'Modules',
        passwordHash: await hashPassword('Sup3rSecret!!'),
        settings: { create: { workHourlyRate: 12 } },
      },
    })
    userId = user.id
    process.env.DATA_DIR = mkdtempSync(path.join(tmpdir(), 'dayos-test-'))
  })

  it('creates, tags, searches and deletes notes', async () => {
    const note = await saveNote(userId, null, {
      title: 'Interview prep',
      content: 'STAR stories',
      tags: ['career'],
      favourite: true,
    })
    expect(note.id).toBeTruthy()
    const found = await listNotes(userId, { search: 'interview' })
    expect(found).toHaveLength(1)
    const tagged = await listNotes(userId, { tag: 'career' })
    expect(tagged).toHaveLength(1)
    await saveNote(userId, note.id, { title: 'Interview prep v2', content: 'updated', tags: ['career'], favourite: false })
    expect((await listNotes(userId, {}))[0].title).toBe('Interview prep v2')
    await deleteNote(userId, note.id)
    expect(await listNotes(userId, {})).toHaveLength(0)
  })

  it('records stock counts and flags low items', async () => {
    const item = await db.stockItem.create({
      data: { userId, name: 'Punk IPA keg', category: 'Kegs', unit: 'keg', quantity: 5, threshold: 4 },
    })
    await recordCount(userId, item.id, 3, 'weekly')
    const [row] = await listStock(userId)
    expect(row.quantity).toBe(3)
    expect(row.low).toBe(true)
    const counts = await db.stockCount.findMany({ where: { itemId: item.id } })
    expect(Number(counts[0].delta)).toBe(-2)
    expect(categoryHealth(await listStock(userId))[0].ok).toBe(0)
  })

  it('tracks cleaning schedules through due → ok', async () => {
    const task = await db.cleaningTask.create({
      data: { userId, title: 'Line clean', frequency: 'WEEKLY', lastCompletedAt: new Date(Date.now() - 9 * 86400000) },
    })
    expect((await cleaningStatus(userId)).find((c) => c.id === task.id)?.status).toBe('overdue')
    await completeCleaning(userId, task.id)
    expect((await cleaningStatus(userId)).find((c) => c.id === task.id)?.status).toBe('ok')
  })

  it('uploads, lists and deletes vault documents via the storage layer', async () => {
    const doc = await uploadDocument(
      userId,
      { name: 'tenancy.pdf', mime: 'application/pdf', bytes: Buffer.from('%PDF-1.4 test') },
      { name: 'Tenancy agreement', category: 'HOUSING', tags: ['flat'] },
    )
    expect(doc.storageKey).toContain(userId)
    const listed = await listDocuments(userId, { category: 'HOUSING' })
    expect(listed).toHaveLength(1)
    const fetched = await getDocumentForUser(userId, doc.id)
    expect(fetched?.sizeBytes).toBe(13)
    await deleteDocument(userId, doc.id)
    expect(await listDocuments(userId, {})).toHaveLength(0)
  })

  it('rejects oversized and disallowed uploads', async () => {
    await expect(
      uploadDocument(userId, { name: 'x.exe', mime: 'application/x-msdownload', bytes: Buffer.from('x') }, { name: 'x', category: 'OTHER', tags: [] }),
    ).rejects.toThrow(/Unsupported file type/)
    await expect(
      uploadDocument(
        userId,
        { name: 'big.pdf', mime: 'application/pdf', bytes: Buffer.alloc(11 * 1024 * 1024) },
        { name: 'big', category: 'OTHER', tags: [] },
      ),
    ).rejects.toThrow(/too large/i)
  })

  it('searches across modules', async () => {
    await db.task.create({ data: { userId, title: 'Pay rent' } })
    const hits = await globalSearch(userId, 'rent')
    expect(hits.some((h) => h.type === 'Task')).toBe(true)
  })

  it('calculates work shift pay from settings', async () => {
    const start = new Date()
    start.setHours(17, 0, 0, 0)
    const end = new Date(start.getTime() + 8 * 3600000)
    await db.workShift.create({ data: { userId, date: start, start, end, breakMinutes: 0 } })
    const summary = await monthSummary(userId, new Date())
    expect(summary.shiftCount).toBe(1)
    expect(summary.hoursMinutes).toBe(480)
    expect(summary.estimatedPay).toBe(96) // 8h × £12
    const shifts = await shiftsInRange(userId, new Date(start.getTime() - 86400000), new Date(start.getTime() + 86400000))
    expect(shifts[0].pay.overtimeMinutes).toBe(0)
  })

  it('cleans up temp storage', async () => {
    rmSync(process.env.DATA_DIR!, { recursive: true, force: true })
  })
})
