import { beforeAll, describe, expect, it } from 'vitest'
import { db } from '@/lib/db/client'
import { authenticate, changePassword, setupOwner, updateProfile } from '@/lib/services/auth'
import { hashPassword } from '@/lib/auth/password'

const email = `auth-${Date.now()}@test.dayos`

describe('authentication service', () => {
  beforeAll(async () => {
    // Owner setup is only allowed on an empty instance — start from a clean slate.
    await db.user.deleteMany({})
  })

  it('creates the owner account with a hashed password', async () => {
    const res = await setupOwner({ name: 'Test Owner', email, password: 'Sup3rSecret!!' })
    expect(res.ok).toBe(true)
    const user = await db.user.findUnique({ where: { email } })
    expect(user).not.toBeNull()
    expect(user?.passwordHash).not.toBe('Sup3rSecret!!')
    expect(user?.passwordHash.startsWith('$2')).toBe(true)
    // settings row created alongside
    expect(await db.settings.findUnique({ where: { userId: user!.id } })).not.toBeNull()
  })

  it('refuses a second owner', async () => {
    const res = await setupOwner({ name: 'Impostor', email: `second-${Date.now()}@test.dayos`, password: 'Sup3rSecret!!' })
    expect(res.ok).toBe(false)
  })

  it('authenticates correct credentials and rejects wrong ones', async () => {
    expect((await authenticate({ email, password: 'Sup3rSecret!!' })).ok).toBe(true)
    const bad = await authenticate({ email, password: 'WrongPassword1!' })
    expect(bad.ok).toBe(false)
    const missing = await authenticate({ email: 'ghost@test.dayos', password: 'Sup3rSecret!!' })
    expect(missing.ok).toBe(false)
  })

  it('resolves a bare username to <name>@dayos.local', async () => {
    await db.user.create({
      data: {
        name: 'Root',
        email: 'root@dayos.local',
        passwordHash: await hashPassword('root'),
        settings: { create: {} },
      },
    })
    expect((await authenticate({ email: 'root', password: 'root' })).ok).toBe(true)
    expect((await authenticate({ email: 'ROOT', password: 'root' })).ok).toBe(true)
    expect((await authenticate({ email: 'root@dayos.local', password: 'root' })).ok).toBe(true)
    expect((await authenticate({ email: 'root', password: 'wrong' })).ok).toBe(false)
  })

  it('never stores or returns secrets in payloads', async () => {
    const user = await db.user.findUnique({ where: { email } })
    const json = JSON.stringify(user)
    expect(json).not.toContain('Sup3rSecret!!')
  })

  it('updates profile and blocks duplicate emails', async () => {
    const user = await db.user.findUnique({ where: { email } })
    const other = await db.user.create({
      data: { email: `other-${Date.now()}@test.dayos`, name: 'Other', passwordHash: await hashPassword('Sup3rSecret!!') },
    })
    const dup = await updateProfile(user!.id, { name: 'Renamed', email: other.email })
    expect(dup.ok).toBe(false)
    const ok = await updateProfile(user!.id, { name: 'Renamed', email })
    expect(ok.ok).toBe(true)
    expect((await db.user.findUnique({ where: { id: user!.id } }))?.name).toBe('Renamed')
    await db.user.delete({ where: { id: other.id } })
  })

  it('changes password and invalidates the old one', async () => {
    const res = await changePassword(await (async () => (await db.user.findUnique({ where: { email } }))!.id)(), {
      currentPassword: 'Sup3rSecret!!',
      newPassword: 'An0therSecret!!',
      confirm: 'An0therSecret!!',
    })
    expect(res.ok).toBe(true)
    expect((await authenticate({ email, password: 'Sup3rSecret!!' })).ok).toBe(false)
    expect((await authenticate({ email, password: 'An0therSecret!!' })).ok).toBe(true)
  })
})
