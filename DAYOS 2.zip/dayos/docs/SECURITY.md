# DAYOS security pass (Stage 16)

## Authentication & sessions
- Passwords hashed with bcrypt, cost 12 (`lib/auth/password.ts`). Never logged,
  never serialized to the client.
- Sessions: 256-bit random token, SHA-256 hash stored in DB; the cookie carries
  a signed JWT (HS256, `AUTH_SECRET`) referencing the session row — revocation
  is a DB delete.
- Cookie flags: `HttpOnly`, `SameSite=Lax`, `Secure` in production, `Path=/`,
  30-day sliding expiry with refresh at half-life.
- Login rate limiting: 30 attempts/min per IP+identifier (in-memory; document a
  proxy-level limit if scaling past one replica).
- Sign-in identifier: a full email, or a bare username that resolves to
  `<name>@dayos.local` (e.g. `root`). Account creation still requires a valid
  email and a strong password; the shorthand is input normalisation, not an
  auth bypass — bcrypt comparison and rate limiting apply identically.
- Constant-ish-time login: a dummy bcrypt compare runs when the user is
  unknown to avoid timing oracle on email existence.
- "Sign out other sessions" revokes every session except the current one.

## Authorization
- Every server action and API route resolves the session server-side and
  scopes **all** queries by `userId` (`requireUserId` + `where: { id, userId }`).
- Document downloads verify ownership before touching storage; storage keys are
  validated against path traversal (`lib/storage/local.ts`).

## CSRF / XSS / injection
- Mutations happen via server actions (Next.js verifies the `Origin` header in
  production) or same-origin POSTs; `SameSite=Lax` cookies block cross-site
  form posts.
- React escaping by default; no `dangerouslySetInnerHTML`; no user-supplied
  URLs rendered as links except plain text.
- All database access via Prisma parameterised queries — no string-built SQL.
  The only raw query is the health check `SELECT 1`.

## Input validation
- Zod schemas for every action payload (`lib/validation/schemas.ts`), including
  amount ranges, date coercion, enum whitelists and cross-field refinements
  (password confirmation, shift start≠end).

## Uploads
- MIME allowlist (PDF, images, Office, plain text/CSV/JSON), 10 MB cap,
  server-side re-check (never trusts client headers alone), randomised storage
  keys, `X-Content-Type-Options: nosniff` + `Content-Disposition: attachment`
  on download.

## Secrets & supply chain
- `.env` git-ignored; `.env.example` documents every variable.
- No secrets in the Docker image (build-time `DATABASE_URL` is a dummy for
  Prisma generate; runtime values come from OpenShift Secrets).
- Lockfile committed; `npm ci` in Docker for reproducible installs.

## Headers & transport
- HSTS (2y, includeSubDomains), `X-Content-Type-Options`, `X-Frame-Options
  DENY`, `Referrer-Policy`, `Permissions-Policy` (camera/mic/geo/payment off),
  `Cross-Origin-Opener-Policy`.
- OpenShift route terminates TLS and redirects HTTP→HTTPS; secure cookies then
  apply automatically.

## Error handling
- Production Next.js error boundaries; API routes return minimal JSON; stack
  traces never rendered. Prisma logs restricted to `error` in production.

## Known limitations (documented, not hidden)
- In-memory rate limiter and single-replica deployment model (personal app).
- No CSP header yet: Next.js injects inline bootstrap scripts; adding nonces is
  a tracked hardening step.
- Web Push notifications are a future module; the Notification model exists.
