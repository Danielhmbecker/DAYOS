# Future: the DAYOS AI assistant

Design notes for the eventual assistant. **Not part of the MVP** — implemented
only when it can be added without compromising the core.

## Ground rules
1. Runs **server-side only**, inside the authenticated session. The model never
   receives a raw database connection or the user's password/session secret.
2. Tool-calling architecture: the assistant calls the *same* Zod-validated
   service functions the UI uses (`lib/services/*`), so permissions and
   ownership checks are identical to human actions.
3. Every write the assistant performs is attributed and reversible where
   possible (audit row in `Notification`).

## Example capabilities mapped to existing services
| Question / command | Service call |
| --- | --- |
| "How much money do I have available?" | `money.availableBalance` |
| "What bills are due this week?" | `money.upcomingBills(userId, 7)` |
| "How many hours did I work this month?" | `work.monthSummary` |
| "What tasks are overdue?" | `db.task.findMany({ status≠DONE, dueDate < now })` |
| "Show my upcoming interviews" | `db.careerApplication.findMany({ status: INTERVIEW })` |
| "Create a task for tomorrow" | `tasks.saveTask` (via action wrapper) |
| "Log £12.50 as food" | `money.saveTransaction` with category lookup |

## Interface sketch
- `/api/assistant` route (POST, session-guarded) streaming responses.
- Chat sheet behind the quick-capture FAB; history stored per user.
- Provider-agnostic adapter (OpenAI-compatible / local Ollama) configured via
  env (`AI_PROVIDER`, `AI_MODEL`, `AI_API_KEY`) — all optional; the module is
  invisible when unconfigured.

## Privacy
- Prompt payload minimisation: only the fields a tool call returns.
- Opt-in per installation; explicit banner the first time it is enabled.
