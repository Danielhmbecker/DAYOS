# Module architecture & future modules

DAYOS is deliberately modular so new capabilities plug in without rewriting
the core.

## Anatomy of a module

1. **Route**: `app/(app)/<module>/page.tsx` — server component, fetches via
   `lib/services/*`, renders client panels.
2. **Actions**: `app/(app)/<module>/actions.ts` — `"use server"` functions,
   Zod-validated, ownership-checked, `revalidatePath` after writes.
3. **Services**: `lib/services/<module>.ts` — pure business logic, shared by
   actions, dashboard and tests.
4. **Components**: `components/<module>/*` — client islands (dialogs, charts).
5. **Navigation**: register in `lib/nav.ts` (`MORE_NAV` or `PRIMARY_NAV`).
6. **Data**: add models to `prisma/schema.prisma`, generate a migration with
   `npx prisma migrate diff --from-migrations … ` or `prisma migrate dev`.
7. **Alerts (optional)**: extend `lib/services/notifications.ts` so the bell
   surfaces module events.
8. **Search (optional)**: extend `lib/services/search.ts`.

Checklist for a new module: route + nav entry + actions + services + empty
state + at least one unit/integration test + E2E navigation assertion.

## Documented future modules

These are intentionally **not** implemented in the MVP. The More screen shows
them marked "Soon" — never as fake-working buttons.

- **BetLab** — bet tracking & value analysis
- **Turbo** — crypto/asset terminal views
- **AI assistant** — see docs/AI_ASSISTANT.md
- **Habits**, **Health**, **Projects**, **Portfolio**, **Automations**
- **Push notifications** (Web Push on top of the existing Notification model)
- **Bank connections** (read-only Open Banking imports into Money)
- **AI document extraction** (receipt → transaction suggestions in Vault)

Each maps to the anatomy above: e.g. BetLab adds `Bet`/`Bookmaker` models, a
`/betlab` route, services for EV calculations and a nav entry — with zero
changes to existing modules.

## Storage drivers

`lib/storage` defines the `StorageDriver` interface (`put/get/remove`).
`local` ships today (files under `$DATA_DIR/documents`, i.e. a PVC on
OpenShift). An S3-compatible driver implements the same three methods and is
selected via `STORAGE_DRIVER=s3` — no application code changes.
