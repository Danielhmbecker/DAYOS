# DAYOS — Build Progress

Live record of the staged build. A stage is marked COMPLETE only after the
project built, tests ran and the functionality was verified against a running
instance (embedded PGlite Postgres + production Next.js build).

| Stage | Name | Status | Progress |
| --- | --- | --- | --- |
| 1 | Foundation | COMPLETE | 10% |
| 2 | App shell | COMPLETE | 20% |
| 3 | Authentication | COMPLETE | 25% |
| 4 | Database | COMPLETE | 30% |
| 5 | Home / dashboard | COMPLETE | 40% |
| 6 | Money | COMPLETE | 50% |
| 7 | Work | COMPLETE | 60% |
| 8 | Career | COMPLETE | 65% |
| 9 | Notes + quick capture | COMPLETE | 70% |
| 10 | Vault | COMPLETE | 75% |
| 11 | Tasks + calendar | COMPLETE | 80% |
| 12 | Stockroom | COMPLETE | 85% |
| 13 | PWA | COMPLETE | 90% |
| 14 | OpenShift | COMPLETE | 95% |
| 15 | Testing | COMPLETE | 98% |
| 16 | Security pass | COMPLETE | 99% |
| 17 | Final polish | COMPLETE | 100% |

## Stage notes

### STAGE 1 — FOUNDATION — COMPLETE — 10%
Next.js 15 (App Router, TypeScript strict), Tailwind dark-first design system,
component primitives, ESLint 9 flat config + Prettier, env handling, Prisma 6
configured, PWA plumbing, error/empty/loading patterns, mobile-first layout.
`npm run build` verified green before continuing.

### STAGE 2 — APP SHELL — COMPLETE — 20%
Desktop sidebar + mobile bottom nav (HOME / MONEY / WORK / CAREER / MORE),
MORE grid (Notes, Vault, Calendar, Tasks, Stockroom, Settings + clearly marked
future modules), sticky header with page titles, user menu, notifications area
(computed alerts), global search, quick-capture command button.

### STAGE 3 — AUTHENTICATION — COMPLETE — 25%
First-run owner setup, login/logout, DB-backed sessions with signed JWT cookie
(httpOnly, SameSite=Lax, Secure in production, 30-day sliding expiry), protected
routes via middleware-free server guards, bcrypt(12) hashing, login rate
limiting, /settings/account (profile, password, sign out other sessions).
`.env.example` documents every variable.

### STAGE 4 — DATABASE — COMPLETE — 30%
26 relational models with FKs, indexes, timestamps and cascade rules
(users, sessions, settings, categories, transactions, budgets, bills,
savings goals, work locations/shifts/tasks, career stages/applications/courses/
certificates/skills, tasks, events, notes/tags, documents, stock items/counts,
cleaning tasks, notifications). Migration generated with `prisma migrate diff`
and applied with `prisma migrate deploy`.

### STAGE 5 — HOME / DASHBOARD — COMPLETE — 40%
Greeting + date, optional Open-Meteo weather (off by default, configurable),
cards: available balance, savings, tasks remaining, work today, next event,
career goal, bills due soon, quick actions. Cards hideable in Settings
(reordering documented as a future feature).

### STAGE 6 — MONEY — COMPLETE — 50%
Overview (income/spending/remaining/savings + 6-month Recharts bar chart +
budget progress + upcoming bills), transactions with search/filter/edit/delete,
recurring transactions that materialise idempotently, budgets per category,
bills with pay-now (logs expense + reschedules), savings goals with top-ups,
category management, GBP default with configurable currency.

### STAGE 7 — WORK — COMPLETE — 60%
Shifts (date/start/end/break/location/role/notes) with automatic worked hours,
overtime (threshold + multiplier from Settings) and estimated pay, midnight
crossing support ("Close"), month summary (shifts/hours/overtime/est. pay),
work task checklist, work locations with optional rate override.

### STAGE 8 — CAREER — COMPLETE — 65%
Visual roadmap (current → target → future → long-term, reorderable, set-current),
applications with all six statuses + interview dates + CV version + notes,
courses, certificates, skills with levels.

### STAGE 9 — NOTES + QUICK CAPTURE — COMPLETE — 70%
Notes with tags, favourites, archive, search; quick capture sheet (note, task,
expense, income, event) reachable from the FAB and dashboard tiles in ≤2 taps.

### STAGE 10 — VAULT — COMPLETE — 75%
Document metadata in Postgres; binaries in a pluggable storage driver (local
PV today, S3 documented as a future driver). Upload validation (MIME allowlist,
10 MB cap), folders/categories, tags, search, authenticated download route,
delete removes binary + metadata.

### STAGE 11 — TASKS + CALENDAR — COMPLETE — 80%
Unified tasks (priority/status/due/category, overdue highlighting), calendar
with month grid + week strip + day agenda; events surface on the dashboard and
in notifications.

### STAGE 12 — STOCKROOM — COMPLETE — 85%
Generic stock items (custom categories, units, thresholds, locations), ±
adjustments, stock counts with delta history, category health cards, cleaning
schedules with ok/due/overdue computed from completion history. No
BrewDog-specific logic in core — seed data only demonstrates it.

### STAGE 13 — PWA — COMPLETE — 90%
Web manifest (standalone, theme colours, maskable icon), hand-written service
worker (shell precache, network-first navigations with /offline fallback,
SWR static assets), offline banner, Apple web-app meta, safe-area padding,
icons 64→1024 + favicon.ico + apple-touch-icon.

### STAGE 14 — OPENSHIFT — COMPLETE — 95%
Multi-stage non-root Dockerfile with HEALTHCHECK, docker-compose for local
dev, OpenShift manifests (deployment with startup/readiness/liveness probes on
/api/health, service, edge-TLS route with HTTP→HTTPS redirect, configmap,
secret examples, PVC, in-cluster Postgres, migrate Job) and a step-by-step
runbook (openshift/README.md).

### STAGE 15 — TESTING — COMPLETE — 98%
Vitest: 42 unit + integration tests (calculations, validation, finance, shifts,
auth, money, notes, vault storage, stockroom, search) against in-memory PGlite.
Playwright: 31 E2E tests across iPhone SE (375×812), iPhone 13 (390×844),
iPhone 14 Pro Max (430×932) and desktop — login, dashboard, expense/income/
task/note creation, shift creation, module navigation, logout, manifest/SW,
touch targets, no horizontal scroll. All green (`npm test`, `npm run test:e2e`).

### STAGE 16 — SECURITY PASS — COMPLETE — 99%
See docs/SECURITY.md: bcrypt hashing, server-side authorisation on every
action/route, CSRF posture (SameSite + Next.js origin checks), no raw SQL
interpolation (Prisma parameterised), Zod validation on all inputs, upload
MIME/size validation, secure cookies, secrets out of VCS, security headers,
login rate limiting, production error handling.

### STAGE 17 — FINAL POLISH — COMPLETE — 100%
No lorem ipsum, no dead buttons (future modules visibly marked "Soon"),
loading/empty/error states, confirmation dialogs on destructive actions,
toast feedback everywhere, console debugging removed, lint clean with
`--max-warnings 0`.

---

## POST-RELEASE PASSES

### LOCAL `root` LOGIN (2026-09-23)
Sign-in now accepts a bare username as shorthand for `<name>@dayos.local`
(`root` → `root@dayos.local`); account creation still requires a valid email
and a strong password. The login field became "Email or username"
(`type="text"`, `autoComplete="username"`). Covered by unit + integration
tests (43/43) and documented in docs/SECURITY.md and README §3.

### PERFORMANCE PASS (2026-09-23)
Symptom: preview navigations and quick-capture submits could stall for
20s+. Root cause: the dashboard awaited an external weather API
(api.open-meteo.com) with no timeout on every render, and every mutation
revalidates `/`; when sandbox egress degraded, renders hung. Fixes:

- `getWeather`: in-process 10-min TTL cache, `AbortSignal.timeout(2500)`,
  stale-on-error with 30s retry backoff — an unreachable weather API can no
  longer block or slow any render.
- Dashboard: settings load first, then data + weather resolve in parallel.
- `loading.tsx` boundaries on all 11 app routes (`PageSkeleton`): instant
  navigation feedback and App Router shell prefetching for dynamic routes.
- `getCurrentSession` wrapped in React `cache()`: layout + page share one
  session lookup per request (auth DB queries halved).
- Recharts (~131KB gz) code-split out of the Money route via `next/dynamic`
  (`components/money/chart-lazy.tsx`, `ssr: false`): /money First Load JS
  151KB total.
- Embedded PGlite server: idle `DEALLOCATE ALL` now tracks connection counts,
  so short-lived CLI clients (<1.5s) no longer leak prepared statements into
  the next connection.

Measured (desktop, standalone build, localhost): login→dashboard 1361→825ms;
cold dashboard 1062→842ms; client-side navigation 316→~100ms; quick-capture
submit→toast: stalls of 20s+ → ~350ms consistently. Full E2E suite green:
35 passed, 0 flaky, 1 skipped (1.2m). Vitest 43/43.
