import type { Config } from 'tailwindcss'
import tailwindcssAnimate from 'tailwindcss-animate'

/**
 * DAYOS design language — premium dark, mobile-first.
 * Near-black backgrounds, elevated cards, subtle borders, neon accents.
 */
const config: Config = {
  darkMode: 'class',
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './lib/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // Surfaces
        bg: '#05070D',
        surface: '#0A0F1C',
        card: '#0D1526',
        elevate: '#131C31',
        line: '#1C2740',
        // Text
        ink: '#E8EEF9',
        muted: '#8A97B1',
        faint: '#5A6784',
        // Accents
        accent: {
          DEFAULT: '#38BDF8',
          soft: '#0EA5E9',
          deep: '#3B82F6',
        },
        success: '#34D399',
        warning: '#FBBF24',
        danger: '#FB7185',
        violet: '#A78BFA',
        amber: '#F59E0B',
        mint: '#2DD4BF',
      },
      fontFamily: {
        sans: [
          '-apple-system',
          'BlinkMacSystemFont',
          'SF Pro Text',
          'SF Pro Display',
          'Inter',
          'Segoe UI',
          'system-ui',
          'Roboto',
          'sans-serif',
        ],
        mono: ['SF Mono', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      borderRadius: {
        card: '18px',
        tile: '14px',
        pill: '999px',
      },
      boxShadow: {
        card: '0 1px 0 0 rgb(255 255 255 / 0.03) inset, 0 8px 24px -12px rgb(0 0 0 / 0.7)',
        glow: '0 0 24px -6px rgb(56 189 248 / 0.35)',
        sheet: '0 -12px 40px -12px rgb(0 0 0 / 0.8)',
      },
      keyframes: {
        'fade-in': { from: { opacity: '0' }, to: { opacity: '1' } },
        'slide-up': {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'sheet-up': {
          from: { transform: 'translateY(100%)' },
          to: { transform: 'translateY(0)' },
        },
        'scale-in': {
          from: { opacity: '0', transform: 'scale(0.97)' },
          to: { opacity: '1', transform: 'scale(1)' },
        },
      },
      animation: {
        'fade-in': 'fade-in 200ms ease-out',
        'slide-up': 'slide-up 240ms cubic-bezier(0.22, 1, 0.36, 1)',
        'sheet-up': 'sheet-up 280ms cubic-bezier(0.22, 1, 0.36, 1)',
        'scale-in': 'scale-in 180ms ease-out',
      },
      minHeight: {
        touch: '44px',
      },
      minWidth: {
        touch: '44px',
      },
    },
  },
  plugins: [tailwindcssAnimate],
}

export default config
