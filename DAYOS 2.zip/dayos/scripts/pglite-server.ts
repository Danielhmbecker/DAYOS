/**
 * Embedded zero-infrastructure Postgres for local demos and CI.
 *
 * Starts a file-backed PGlite instance (real Postgres, WASM build), applies
 * Prisma migrations directly, optionally seeds demo data, then serves the
 * database over the standard Postgres wire protocol so the app (and any
 * single Prisma client) connects with an ordinary DATABASE_URL.
 *
 *   npm run db:demo            # embedded PG + migrations
 *   DEMO_SEED=1 npm run db:demo  # …plus demo data on first boot
 *
 * Notes / limitations (documented in README):
 *  - PGlite is a single-session database. Prisma prepared statements live in
 *    that session, so this server runs DEALLOCATE ALL whenever a client
 *    disconnects, and demo mode expects ONE client process at a time (the
 *    app). For concurrent clients (CLI + app together) use real PostgreSQL
 *    via docker-compose or OpenShift.
 */
import { mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { PGlite } from '@electric-sql/pglite'
import { PGLiteSocketServer } from '@electric-sql/pglite-socket'
import { loadEnv } from '../lib/env'
import { applyMigrations } from './migrations'

loadEnv()

const port = parseInt(process.env.PGLITE_PORT ?? '5433', 10)
const host = process.env.PGLITE_HOST ?? '127.0.0.1'
const dataDir = process.env.PGLITE_DATA ?? './data/pg'

async function main() {
  mkdirSync(dirname(resolve(dataDir)), { recursive: true })
  const db = await PGlite.create(dataDir)

  const applied = await applyMigrations(db)
  if (applied.length > 0) console.log(`[dayos] applied migrations: ${applied.join(', ')}`)

  const server = new PGLiteSocketServer({ db, port, host, maxConnections: 4 })

  // PGlite is single-session: Prisma prepared statements outlive each client
  // connection. Clear them whenever a client disconnects (and as a fallback
  // whenever the server goes idle) so the next client starts clean.
  let connectionsSeen = 0
  server.addEventListener('connection', (event) => {
    connectionsSeen += 1
    const socket = (event as CustomEvent).detail as { on?: (ev: string, cb: () => void) => void }
    socket.on?.('close', () => {
      db.exec('DEALLOCATE ALL').catch(() => {})
    })
  })

  await server.start()

  // Fallback for connections that open and close between polls (e.g. short
  // CLI scripts): once idle after any new connection, deallocate again.
  let lastResetAt = 0
  const resetTimer = setInterval(() => {
    const stats = server.getStats()
    if (stats.activeConnections === 0 && connectionsSeen > lastResetAt) {
      lastResetAt = connectionsSeen
      db.exec('DEALLOCATE ALL').catch(() => {})
    }
  }, 1500)
  resetTimer.unref?.()

  if (process.env.DEMO_SEED === '1') {
    const { seedIfEmpty, closeSeedClient } = await import('../prisma/seed')
    await seedIfEmpty()
    await closeSeedClient()
  }
  console.log(`[dayos] embedded Postgres (PGlite) listening on ${host}:${port} (data: ${dataDir})`)
  console.log(`[dayos] DATABASE_URL="postgresql://dayos:dayos@${host}:${port}/dayos?connection_limit=1"`)

  const shutdown = async () => {
    await server.stop()
    await db.close()
    process.exit(0)
  }
  process.on('SIGINT', shutdown)
  process.on('SIGTERM', shutdown)
}

main().catch((err) => {
  console.error('[dayos] failed to start embedded Postgres:', err)
  process.exit(1)
})
