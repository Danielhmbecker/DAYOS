/**
 * Generates the DAYOS icon set from inline SVGs:
 *  - /public/icons/*.svg            (module icons, vector)
 *  - /public/icons/dayos-*.png      (64/120/180/512/1024)
 *  - /public/icons/dayos-maskable-512.png
 *  - /public/apple-touch-icon.png   (180)
 *  - /public/favicon.ico            (16/32/48, PNG payloads)
 *
 * Run: npm run icons
 */
import sharp from 'sharp'
import { mkdir, writeFile } from 'node:fs/promises'
import path from 'node:path'

const OUT = path.resolve('public/icons')
await mkdir(OUT, { recursive: true })

const tile = (bg1, bg2, inner) => `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${bg1}"/>
      <stop offset="1" stop-color="${bg2}"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="112" fill="url(#bg)"/>
  ${inner}
</svg>`

const stroke = (d, color = '#ffffff', w = 30) =>
  `<path d="${d}" fill="none" stroke="${color}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"/>`

// ── DAYOS mark: orbital D ───────────────────────────────────────────────────
const dayosInner = `
  <circle cx="256" cy="256" r="150" fill="none" stroke="#38BDF8" stroke-width="14" opacity="0.35"/>
  <ellipse cx="256" cy="256" rx="196" ry="78" fill="none" stroke="#38BDF8" stroke-width="12" opacity="0.55" transform="rotate(-24 256 256)"/>
  <path d="M186 146 h60 a110 110 0 0 1 0 220 h-60 z" fill="none" stroke="#E8EEF9" stroke-width="34" stroke-linejoin="round"/>
  <circle cx="404" cy="150" r="22" fill="#38BDF8"/>
`

const moduleIcons = {
  dayos: tile('#0B1220', '#12203C', dayosInner),
  money: tile('#065F46', '#10B981', stroke('M146 176 h220 a28 28 0 0 1 28 28 v132 a28 28 0 0 1 -28 28 h-220 a28 28 0 0 1 -28 -28 v-132 a28 28 0 0 1 28 -28 z M330 268 h44') + `<circle cx="352" cy="268" r="10" fill="#fff"/>`),
  work: tile('#312E81', '#6366F1', stroke('M156 208 h200 a24 24 0 0 1 24 24 v112 a24 24 0 0 1 -24 24 h-200 a24 24 0 0 1 -24 -24 v-112 a24 24 0 0 1 24 -24 z M216 208 v-28 a24 24 0 0 1 24 -24 h32 a24 24 0 0 1 24 24 v28 M132 288 h248')),
  career: tile('#7F1D1D', '#F43F5E', stroke('M136 344 l72 -76 56 48 96 -112 M300 204 h60 v60')),
  notes: tile('#78350F', '#F59E0B', stroke('M168 136 h176 a24 24 0 0 1 24 24 v192 a24 24 0 0 1 -24 24 h-176 a24 24 0 0 1 -24 -24 v-192 a24 24 0 0 1 24 -24 z M196 216 h120 M196 268 h120 M196 320 h72')),
  vault: tile('#0C4A6E', '#0EA5E9', stroke('M144 168 h96 l24 28 h104 a24 24 0 0 1 24 24 v128 a24 24 0 0 1 -24 24 h-224 a24 24 0 0 1 -24 -24 v-156 a24 24 0 0 1 24 -24 z M256 268 v40')),
  stockroom: tile('#7C2D12', '#F97316', stroke('M256 136 l112 60 v120 l-112 60 -112 -60 v-120 z M144 196 l112 60 112 -60 M256 256 v120')),
  calendar: tile('#1E3A8A', '#3B82F6', stroke('M152 168 h208 a24 24 0 0 1 24 24 v152 a24 24 0 0 1 -24 24 h-208 a24 24 0 0 1 -24 -24 v-152 a24 24 0 0 1 24 -24 z M128 240 h256 M200 136 v56 M312 136 v56')),
  tasks: tile('#134E4A', '#2DD4BF', stroke('M168 152 h176 a24 24 0 0 1 24 24 v160 a24 24 0 0 1 -24 24 h-176 a24 24 0 0 1 -24 -24 v-160 a24 24 0 0 1 24 -24 z M204 256 l40 40 76 -84')),
  settings: tile('#1F2937', '#4B5563', `<circle cx="256" cy="256" r="52" fill="none" stroke="#fff" stroke-width="30"/>` + stroke('M256 132 v44 M256 336 v44 M132 256 h44 M336 256 h44 M168 168 l32 32 M312 312 l32 32 M344 168 l-32 32 M200 312 l-32 32')),
  betlab: tile('#4A044E', '#D946EF', stroke('M208 148 h96 M224 148 v76 l-72 116 a28 28 0 0 0 24 44 h160 a28 28 0 0 0 24 -44 l-72 -116 v-76') + `<circle cx="236" cy="320" r="12" fill="#fff"/><circle cx="280" cy="340" r="12" fill="#fff"/>`),
  turbo: tile('#713F12', '#FACC15', `<path d="M280 128 L176 288 h72 l-16 96 112 -164 h-72 z" fill="#fff"/>`),
}

for (const [name, svg] of Object.entries(moduleIcons)) {
  await writeFile(path.join(OUT, `${name}.svg`), svg.trim())
}

// ── Rasterise the DAYOS mark ────────────────────────────────────────────────
const sizes = [64, 120, 180, 512, 1024]
const buffers = new Map()
for (const size of sizes) {
  const buf = await sharp(Buffer.from(moduleIcons.dayos)).resize(size, size).png().toBuffer()
  buffers.set(size, buf)
  await writeFile(path.join(OUT, `dayos-${size}.png`), buf)
}

// Maskable: full-bleed background with safe-zone content
const maskable = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <rect width="512" height="512" fill="#0B1220"/>
  <g transform="translate(256 256) scale(0.72) translate(-256 -256)">${dayosInner}</g>
</svg>`
await writeFile(path.join(OUT, 'dayos-maskable-512.png'), await sharp(Buffer.from(maskable)).resize(512, 512).png().toBuffer())

// Apple touch icon (180, precomposed)
await writeFile(path.resolve('public/apple-touch-icon.png'), buffers.get(180))

// ── favicon.ico (ICO container with PNG payloads: 16/32/48) ─────────────────
async function ico(entries) {
  const header = Buffer.alloc(6)
  header.writeUInt16LE(0, 0)
  header.writeUInt16LE(1, 2)
  header.writeUInt16LE(entries.length, 4)
  let offset = 6 + entries.length * 16
  const dirs = []
  const payloads = []
  for (const { size, buf } of entries) {
    const dir = Buffer.alloc(16)
    dir.writeUInt8(size < 256 ? size : 0, 0)
    dir.writeUInt8(size < 256 ? size : 0, 1)
    dir.writeUInt16LE(1, 4)
    dir.writeUInt16LE(32, 6)
    dir.writeUInt32LE(buf.length, 8)
    dir.writeUInt32LE(offset, 12)
    dirs.push(dir)
    payloads.push(buf)
    offset += buf.length
  }
  return Buffer.concat([header, ...dirs, ...payloads])
}

const icoBuf = await ico(
  await Promise.all(
    [16, 32, 48].map(async (size) => ({
      size,
      buf: await sharp(Buffer.from(moduleIcons.dayos)).resize(size, size).png().toBuffer(),
    })),
  ),
)
await writeFile(path.resolve('public/favicon.ico'), icoBuf)

console.log('[dayos] icons generated:', sizes.join(', '), '+ maskable, apple-touch, favicon.ico')
