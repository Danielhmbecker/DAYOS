import { readdirSync, readFileSync } from 'node:fs'
import path from 'node:path'
import type { PGlite } from '@electric-sql/pglite'

/**
 * Applies prisma/migrations/*\/migration.sql in order to a PGlite instance,
 * tracking applied migrations in a bookkeeping table. Used by the embedded
 * demo server and by integration tests; production uses `prisma migrate
 * deploy` against real PostgreSQL.
 */
export function migrationFiles(dir = path.join(process.cwd(), 'prisma', 'migrations')): {
  name: string
  sql: string
}[] {
  return readdirSync(dir, { withFileTypes: true })
    .filter((e) => e.isDirectory())
    .map((e) => e.name)
    .sort()
    .map((name) => ({
      name,
      sql: readFileSync(path.join(dir, name, 'migration.sql'), 'utf8'),
    }))
}

export async function applyMigrations(db: PGlite): Promise<string[]> {
  await db.exec(`CREATE TABLE IF NOT EXISTS _dayos_migrations (
    name TEXT PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
  )`)
  const done = new Set(
    (await db.query<{ name: string }>('SELECT name FROM _dayos_migrations')).rows.map((r) => r.name),
  )
  const applied: string[] = []
  for (const migration of migrationFiles()) {
    if (done.has(migration.name)) continue
    await db.exec(migration.sql)
    await db.query(`INSERT INTO _dayos_migrations (name) VALUES ($1)`, [migration.name])
    applied.push(migration.name)
  }
  return applied
}
