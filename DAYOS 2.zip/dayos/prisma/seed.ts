/**
 * DAYOS seed — optional demo data.
 *
 *   npm run db:seed
 *
 * Creates (or refreshes) a demo owner account with representative data for
 * every module. Safe to re-run: it skips when the demo user already exists.
 *
 * Demo login: dan@dayos.app / DemoPass123!
 */
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
import { loadEnv } from '../lib/env'

loadEnv()

const db = new PrismaClient()

const DEMO_EMAIL = 'dan@dayos.app'
const DEMO_PASSWORD = 'DemoPass123!'

function daysFromNow(days: number, hour = 12, minute = 0): Date {
  const d = new Date()
  d.setDate(d.getDate() + days)
  d.setHours(hour, minute, 0, 0)
  return d
}

function shiftDate(days: number, startHour: number, startMin: number, endHour: number, endMin: number) {
  const start = daysFromNow(days, startHour, startMin)
  let end = daysFromNow(days, endHour, endMin)
  if (end <= start) end = new Date(end.getTime() + 86400000)
  return { start, end }
}

export async function seedIfEmpty(): Promise<void> {
  const existing = await db.user.findUnique({ where: { email: DEMO_EMAIL } })
  if (existing) {
    console.log('[seed] demo user already exists — skipping. Login:', DEMO_EMAIL)
    return
  }

  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 12)
  const user = await db.user.create({
    data: {
      name: 'Dan',
      email: DEMO_EMAIL,
      passwordHash,
      settings: {
        create: {
          currency: 'GBP',
          weatherEnabled: true,
          weatherLatitude: 51.5074,
          weatherLongitude: -0.1278,
          weatherLabel: 'London',
          workHourlyRate: 14.5,
          workOvertimeThresholdMin: 480,
          workOvertimeMultiplier: 1.5,
        },
      },
    },
  })
  const uid = user.id

  // ── Categories ────────────────────────────────────────────────────────────
  const cat = async (name: string, type: 'INCOME' | 'EXPENSE', color: string) =>
    (await db.category.create({ data: { userId: uid, name, type, color } })).id
  const cSalary = await cat('Salary', 'INCOME', '#34D399')
  const cTips = await cat('Tips', 'INCOME', '#2DD4BF')
  const cHousing = await cat('Housing', 'EXPENSE', '#FB7185')
  const cBills = await cat('Bills', 'EXPENSE', '#FBBF24')
  const cFood = await cat('Food', 'EXPENSE', '#F59E0B')
  const cTransport = await cat('Transport', 'EXPENSE', '#38BDF8')
  const cFun = await cat('Entertainment', 'EXPENSE', '#A78BFA')
  const cSubs = await cat('Subscriptions', 'EXPENSE', '#818CF8')

  // ── Transactions: 6 months of history ─────────────────────────────────────
  const tx: { type: 'INCOME' | 'EXPENSE'; amount: number; categoryId: string; note: string; date: Date }[] = []
  for (let m = 5; m >= 0; m--) {
    const base = new Date()
    base.setDate(1)
    base.setMonth(base.getMonth() - m)
    const at = (day: number, h = 12) => new Date(base.getFullYear(), base.getMonth(), Math.min(day, 28), h)
    tx.push({ type: 'INCOME', amount: 2450, categoryId: cSalary, note: 'Monthly salary', date: at(28, 9) })
    tx.push({ type: 'EXPENSE', amount: 933, categoryId: cHousing, note: 'Rent', date: at(1, 8) })
    tx.push({ type: 'EXPENSE', amount: 225, categoryId: cBills, note: 'Council tax', date: at(5, 8) })
    tx.push({ type: 'EXPENSE', amount: 116, categoryId: cBills, note: 'Utilities', date: at(7, 8) })
    tx.push({ type: 'EXPENSE', amount: 50, categoryId: cBills, note: 'Phone', date: at(10, 8) })
    tx.push({ type: 'EXPENSE', amount: 46 + m * 3, categoryId: cFood, note: 'Weekly shop', date: at(6, 18) })
    tx.push({ type: 'EXPENSE', amount: 32 + m * 2, categoryId: cFood, note: 'Weekly shop', date: at(14, 18) })
    tx.push({ type: 'EXPENSE', amount: 24, categoryId: cTransport, note: 'Travelcard top-up', date: at(9, 8) })
    tx.push({ type: 'EXPENSE', amount: 15.99, categoryId: cSubs, note: 'Streaming bundle', date: at(12, 8) })
    tx.push({ type: 'EXPENSE', amount: 28 + m, categoryId: cFun, note: 'Night out', date: at(20, 21) })
    tx.push({ type: 'INCOME', amount: 60 + m * 12, categoryId: cTips, note: 'Tip share', date: at(27, 23) })
  }
  // This month, recent days
  tx.push({ type: 'EXPENSE', amount: 12.5, categoryId: cFood, note: 'Lunch with team', date: daysFromNow(-1, 13) })
  tx.push({ type: 'EXPENSE', amount: 4.8, categoryId: cTransport, note: 'Bus', date: daysFromNow(-2, 8) })
  tx.push({ type: 'EXPENSE', amount: 9.99, categoryId: cSubs, note: 'Music', date: daysFromNow(-3, 7) })
  // Recurring template: weekly fuel
  await db.transaction.create({
    data: {
      userId: uid,
      type: 'EXPENSE',
      amount: 35,
      categoryId: cTransport,
      note: 'Fuel (recurring)',
      date: daysFromNow(-7, 17),
      recurrence: 'WEEKLY',
      nextDueDate: daysFromNow(0, 17),
    },
  })
  for (const t of tx) {
    await db.transaction.create({ data: { ...t, userId: uid } })
  }

  // ── Budgets, bills, savings ───────────────────────────────────────────────
  await db.budget.createMany({
    data: [
      { userId: uid, categoryId: cFood, monthlyLimit: 260 },
      { userId: uid, categoryId: cTransport, monthlyLimit: 120 },
      { userId: uid, categoryId: cFun, monthlyLimit: 100 },
      { userId: uid, categoryId: cSubs, monthlyLimit: 40 },
    ],
  })
  await db.bill.createMany({
    data: [
      { userId: uid, name: 'Rent', amount: 933, frequency: 'MONTHLY', nextDueDate: daysFromNow(2, 8) },
      { userId: uid, name: 'Council Tax', amount: 225, frequency: 'MONTHLY', nextDueDate: daysFromNow(5, 8) },
      { userId: uid, name: 'Utilities', amount: 116, frequency: 'MONTHLY', nextDueDate: daysFromNow(5, 8) },
      { userId: uid, name: 'Phone', amount: 50, frequency: 'MONTHLY', nextDueDate: daysFromNow(8, 8) },
    ],
  })
  await db.savingsGoal.createMany({
    data: [
      { userId: uid, name: 'Emergency fund', targetAmount: 3000, savedAmount: 1850, color: '#34D399' },
      { userId: uid, name: 'Japan 2027', targetAmount: 2500, savedAmount: 640, deadline: daysFromNow(300), color: '#38BDF8' },
    ],
  })

  // ── Work ──────────────────────────────────────────────────────────────────
  const soho = await db.workLocation.create({
    data: { userId: uid, name: 'BrewDog Soho', role: 'Duty Manager', hourlyRate: 14.5 },
  })
  const shifts: { offset: number; s: [number, number]; e: [number, number] }[] = [
    { offset: 0, s: [17, 0], e: [23, 30] },
    { offset: 2, s: [16, 0], e: [23, 0] },
    { offset: 4, s: [12, 0], e: [21, 0] },
    { offset: -1, s: [17, 0], e: [23, 45] },
    { offset: -3, s: [15, 0], e: [23, 0] },
    { offset: -5, s: [12, 0], e: [20, 0] },
    { offset: -8, s: [17, 0], e: [23, 30] },
    { offset: -10, s: [16, 30], e: [23, 30] },
    { offset: 7, s: [17, 0], e: [23, 0] },
    { offset: 9, s: [12, 0], e: [20, 30] },
  ]
  for (const s of shifts) {
    const { start, end } = shiftDate(s.offset, s.s[0], s.s[1], s.e[0], s.e[1])
    await db.workShift.create({
      data: {
        userId: uid,
        locationId: soho.id,
        role: 'Duty Manager',
        date: start,
        start,
        end,
        breakMinutes: 30,
        notes: s.offset === 0 ? 'Late open + stock delivery' : null,
      },
    })
  }
  await db.workTask.createMany({
    data: [
      { userId: uid, title: 'Complete line checks', locationId: soho.id },
      { userId: uid, title: 'Stock count — keg room', locationId: soho.id },
      { userId: uid, title: 'Staff training: new till flow', locationId: soho.id, done: true },
      { userId: uid, title: 'Update stock sheet', locationId: soho.id },
    ],
  })

  // ── Career ────────────────────────────────────────────────────────────────
  await db.careerStage.createMany({
    data: [
      { userId: uid, title: 'Duty Manager', subtitle: 'BrewDog Soho', order: 1, isCurrent: true },
      { userId: uid, title: 'Assistant Manager', subtitle: 'Target · next 12 months', order: 2 },
      { userId: uid, title: 'General Manager', subtitle: 'Future · 2–4 years', order: 3 },
      { userId: uid, title: 'Operations Manager', subtitle: 'Long-term goal', order: 4 },
    ],
  })
  await db.careerApplication.createMany({
    data: [
      { userId: uid, company: 'The Ivy Collection', role: 'Assistant Manager', salary: '£38k', location: 'London', workMode: 'ONSITE', status: 'INTERVIEW', appliedDate: daysFromNow(-12), interviewDate: daysFromNow(3, 10), cvVersion: 'v4' },
      { userId: uid, company: 'Young’s Pubs', role: 'Deputy Manager', salary: '£36k', location: 'South London', workMode: 'ONSITE', status: 'APPLIED', appliedDate: daysFromNow(-6), cvVersion: 'v4' },
      { userId: uid, company: 'Dash Living', role: 'Operations Coordinator', salary: '£34k', location: 'London', workMode: 'HYBRID', status: 'SAVED', cvVersion: 'v3' },
      { userId: uid, company: 'Gail’s Bakery', role: 'Shift Manager', salary: '£32k', location: 'Soho', workMode: 'ONSITE', status: 'REJECTED', appliedDate: daysFromNow(-40) },
    ],
  })
  await db.course.createMany({
    data: [
      { userId: uid, title: 'Level 3 Hospitality Supervision', provider: 'BIIAB', status: 'IN_PROGRESS' },
      { userId: uid, title: 'Personal Licence Holder (APLH)', provider: 'BIIAB', status: 'COMPLETED', completedAt: daysFromNow(-200) },
      { userId: uid, title: 'First Aid at Work', provider: 'St John Ambulance', status: 'PLANNED' },
    ],
  })
  await db.certificate.createMany({
    data: [
      { userId: uid, title: 'APLH Personal Licence', issuer: 'BIIAB', issuedAt: daysFromNow(-200), expiresAt: daysFromNow(800) },
      { userId: uid, title: 'Level 2 Food Safety', issuer: 'CIEH', issuedAt: daysFromNow(-400) },
    ],
  })
  await db.skill.createMany({
    data: [
      { userId: uid, name: 'Team leadership', level: 4 },
      { userId: uid, name: 'Stock & cellar management', level: 4 },
      { userId: uid, name: 'P&L reading', level: 3 },
      { userId: uid, name: 'Conflict resolution', level: 4 },
    ],
  })

  // ── Tasks, events, notes ──────────────────────────────────────────────────
  await db.task.createMany({
    data: [
      { userId: uid, title: 'Pay rent', dueDate: daysFromNow(2), priority: 'HIGH' },
      { userId: uid, title: 'Finish Level 3 module 4', dueDate: daysFromNow(6), priority: 'MEDIUM', status: 'IN_PROGRESS' },
      { userId: uid, title: 'Book dentist', dueDate: daysFromNow(-2), priority: 'LOW' },
      { userId: uid, title: 'Renew passport photos', priority: 'LOW', status: 'DONE' },
      { userId: uid, title: 'Prep interview answers for The Ivy', dueDate: daysFromNow(1), priority: 'HIGH' },
    ],
  })
  await db.calendarEvent.createMany({
    data: [
      { userId: uid, title: 'Interview — The Ivy', start: daysFromNow(3, 10), end: daysFromNow(3, 11, 30), location: 'West End' },
      { userId: uid, title: 'Gym', start: daysFromNow(1, 7), end: daysFromNow(1, 8), },
      { userId: uid, title: 'Family call', start: daysFromNow(0, 19), end: daysFromNow(0, 20) },
      { userId: uid, title: 'Flat viewing', start: daysFromNow(6, 12, 30), end: daysFromNow(6, 13, 15), location: 'Hackney' },
    ],
  })
  const note1 = await db.note.create({
    data: {
      userId: uid,
      title: 'Interview prep — The Ivy',
      content: 'STAR stories:\n1. Turned around failing shift roster\n2. Cut cellar waste 18%\n3. Handled refund escalation calmly\n\nQuestions to ask: team size, rota ownership, training budget.',
      favourite: true,
    },
  })
  await db.note.create({
    data: { userId: uid, title: 'Flat ideas', content: 'Budget max £1,400 pcm. Zones: E8, E5, N16. Must allow cats.', },
  })
  await db.note.create({
    data: { userId: uid, title: 'Reading list', content: '– The Management Myth\n– Setting the Table\n– Atomic Habits', archived: false },
  })
  const tagIdeas = await db.tag.create({ data: { userId: uid, name: 'career' } })
  await db.noteTag.create({ data: { noteId: note1.id, tagId: tagIdeas.id } })

  // ── Stockroom ─────────────────────────────────────────────────────────────
  await db.stockItem.createMany({
    data: [
      { userId: uid, name: 'Punk IPA keg', category: 'Kegs', unit: 'keg', quantity: 5, threshold: 4, location: 'Cellar' },
      { userId: uid, name: 'Hazy Jane keg', category: 'Kegs', unit: 'keg', quantity: 2, threshold: 3, location: 'Cellar' },
      { userId: uid, name: 'Dead Pony keg', category: 'Kegs', unit: 'keg', quantity: 6, threshold: 3, location: 'Cellar' },
      { userId: uid, name: 'Lager line', category: 'Lines', unit: 'line', quantity: 12, threshold: 0, location: 'Bar' },
      { userId: uid, name: 'Coffee beans', category: 'Dry', unit: 'kg', quantity: 3.5, threshold: 2, location: 'Store' },
      { userId: uid, name: 'Takeaway cups', category: 'Dry', unit: 'box', quantity: 1, threshold: 2, location: 'Store' },
    ],
  })
  await db.cleaningTask.createMany({
    data: [
      { userId: uid, title: 'Line clean', area: 'Bar', frequency: 'WEEKLY', lastCompletedAt: daysFromNow(-5) },
      { userId: uid, title: 'Cellar floor scrub', area: 'Cellar', frequency: 'WEEKLY', lastCompletedAt: daysFromNow(-7) },
      { userId: uid, title: 'Grease trap check', area: 'Kitchen', frequency: 'MONTHLY', lastCompletedAt: daysFromNow(-33) },
      { userId: uid, title: 'Till wipe-down', area: 'Bar', frequency: 'DAILY', lastCompletedAt: daysFromNow(0, 9) },
    ],
  })
  const keg = await db.stockItem.findFirst({ where: { userId: uid, name: 'Punk IPA keg' } })
  if (keg) {
    await db.stockCount.createMany({
      data: [
        { userId: uid, itemId: keg.id, countedQuantity: 7, delta: 0, countedAt: daysFromNow(-7), note: 'Weekly count' },
        { userId: uid, itemId: keg.id, countedQuantity: 5, delta: -2, countedAt: daysFromNow(0, 10), note: 'Weekly count' },
      ],
    })
  }

  console.log('[seed] demo data created.')
  console.log('[seed] login:', DEMO_EMAIL, '/', DEMO_PASSWORD)
}

/** Disconnect the seed's Prisma client (used when seeded in-process). */
export async function closeSeedClient(): Promise<void> {
  await db.$disconnect()
}

const isDirectRun = process.argv[1]?.includes('seed')
if (isDirectRun) {
  seedIfEmpty()
    .catch((e) => {
      console.error('[seed] failed:', e)
      process.exit(1)
    })
    .finally(() => db.$disconnect())
}
