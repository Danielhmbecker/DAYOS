# Deploying DAYOS to OpenShift

Complete, ordered runbook. Assumes the `oc` CLI is installed and you have a
project (namespace) with permission to create deployments, services, routes,
PVCs and jobs.

## 0. Prerequisites

- OpenShift cluster 4.x with a default StorageClass
- A container registry you can push to (the cluster's internal registry works)
- Docker or Podman locally to build the image

## 1. Login and project

```bash
oc login https://your-cluster-api:6443 --token=YOUR_TOKEN   # or --username/--password
oc project YOUR_PROJECT                                      # or: oc new-project dayos
```

## 2. Create PostgreSQL (in-cluster)

```bash
cd openshift/postgres
cp secret.example.yaml secret.yaml    # edit credentials first!
oc apply -f secret.yaml
oc apply -f pvc.yaml
oc apply -f service.yaml
oc apply -f deployment.yaml
oc rollout status deployment/dayos-postgresql
```

(Using a managed/database-as-a-service Postgres instead? Skip this step and use
its connection string in the next secret.)

## 3. Configure DAYOS secrets & config

```bash
cd ..                                    # back in openshift/
cp secret.example.yaml secret.yaml
# database-url: postgresql://dayos:<password>@dayos-postgresql:5432/dayos?schema=public
# auth-secret:  output of `openssl rand -base64 32`
oc apply -f secret.yaml
oc apply -f configmap.yaml
oc apply -f pvc.yaml                     # document storage volume
```

## 4. Build & push the image

```bash
# Option A — internal registry via oc build (no local docker needed):
oc new-build --name=dayos --binary --strategy=docker
oc start-build dayos --from-dir=.. --follow

# Option B — local build + push:
docker build -t image-registry.openshift-image-registry.svc:5000/YOUR_PROJECT/dayos:latest ..
oc registry login --token=$(oc whoami -t)
docker push image-registry.openshift-image-registry.svc:5000/YOUR_PROJECT/dayos:latest
```

If you used Option A, tag the image stream so the deployment's image reference
resolves:

```bash
oc tag dayos:latest dayos:latest   # imagestream → deployment reference
```

## 5. Deploy DAYOS

```bash
oc apply -f service.yaml
oc apply -f deployment.yaml
oc rollout status deployment/dayos
```

## 6. Run migrations

```bash
oc apply -f migrate-job.yaml
oc logs job/dayos-migrate -f          # "All migrations have been successfully applied."
```

## 7. (Optional) Seed demo data

Seeding runs from your machine against a port-forward, so demo data and the
seed script never need to ship in the container image:

```bash
oc port-forward svc/dayos-postgresql 5432:5432 &     # keep running
# from the project root (needs node_modules installed locally):
DATABASE_URL="postgresql://dayos:<password>@127.0.0.1:5432/dayos" npm run db:seed
kill %1
```

The seed is idempotent: it exits early when the demo owner already exists.

## 8. Expose HTTPS route

```bash
oc apply -f route.yaml
oc get route dayos -o jsonpath='{.spec.host}'   # → https://dayos-YOUR_PROJECT.apps…
```

The route uses edge TLS termination and redirects HTTP → HTTPS. Update
`configmap.yaml` `app-url` with this host and `oc apply` it again.

On iPhone the route certificate must be trusted: use the cluster's default
domain with a publicly trusted cert, or install your organisation's CA profile
via Settings → General → VPN & Device Management before adding to Home Screen.

## 9. Verify health

```bash
curl -f https://$(oc get route dayos -o jsonpath='{.spec.host}')/api/health
# {"status":"ok",...}
oc get pods                       # READY 1/1
oc get events --sort-by=.lastTimestamp | tail
```

## 10. Updating the application

```bash
docker build -t …/dayos:latest .. && docker push …/dayos:latest   # or oc start-build
oc rollout status deployment/dayos
oc delete job dayos-migrate --ignore-not-found
oc apply -f migrate-job.yaml      # migrations are idempotent
```

## Backups

- Database: `oc rsh deployment/dayos-postgresql pg_dump -U dayos dayos > backup.sql`
  (or scheduled CronJob / volume snapshots)
- Documents: the `dayos-data` PVC holds `/data/documents` — snapshot the PVC or
  sync it with `oc rsync`.

## Troubleshooting

| Symptom | Check |
| --- | --- |
| Pod CrashLoopBackOff | `oc logs deployment/dayos` — usually missing secret or failed migration |
| Route 503 | service selector vs pod labels; `oc get endpoints dayos` |
| Health 503 degraded | database connectivity: secret `database-url`, postgres pod ready |
| Uploads disappear | PVC not bound: `oc get pvc`; deployment must mount `/data` |
