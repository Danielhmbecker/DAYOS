import { NextResponse } from 'next/server'
import { getCurrentSession } from '@/lib/auth/session'
import { getDocumentForUser } from '@/lib/services/vault'
import { storage } from '@/lib/storage'

export const dynamic = 'force-dynamic'

/** Authenticated document download — ownership is always verified. */
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await getCurrentSession()
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 })
  const { id } = await params
  const doc = await getDocumentForUser(session.user.id, id)
  if (!doc) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const object = await storage().get(doc.storageKey)
  if (!object) return NextResponse.json({ error: 'File missing from storage' }, { status: 410 })

  const safeName = doc.name.replace(/["\\\r\n]/g, '_')
  return new NextResponse(new Uint8Array(object.bytes), {
    headers: {
      'Content-Type': doc.mime || 'application/octet-stream',
      'Content-Length': String(object.bytes.byteLength),
      'Content-Disposition': `attachment; filename="${safeName}"`,
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'no-store',
    },
  })
}
