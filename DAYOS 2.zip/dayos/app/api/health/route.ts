import { NextResponse } from 'next/server'
import { db } from '@/lib/db/client'

export const dynamic = 'force-dynamic'

/** Liveness/readiness probe target for Docker + OpenShift. */
export async function GET(request: Request) {
  const url = new URL(request.url)
  const deep = url.searchParams.has('deep')
  const payload: Record<string, unknown> = { status: 'ok', app: 'dayos', time: new Date().toISOString() }
  if (deep) {
    try {
      await db.$queryRaw`SELECT 1`
      payload.database = 'up'
    } catch {
      return NextResponse.json({ ...payload, status: 'degraded', database: 'down' }, { status: 503 })
    }
  }
  return NextResponse.json(payload)
}
