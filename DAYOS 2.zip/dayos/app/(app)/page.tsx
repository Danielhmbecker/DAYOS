import Link from 'next/link'
import { Suspense } from 'react'
import {
  Wallet,
  PiggyBank,
  Briefcase,
  ListTodo,
  TrendingUp,
  CalendarClock,
  ReceiptText,
  CloudSun,
} from 'lucide-react'
import { requireUser } from '@/lib/auth/session'
import { db } from '@/lib/db/client'
import { getDashboard, getWeather, settingsSafe, weatherLabel } from '@/lib/services/dashboard'
import { shiftLabel } from '@/lib/services/work'
import { formatMoney, formatDate, formatTime, greeting } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { PageHeader } from '@/components/shell/page-header'
import { QuickActions } from '@/components/dashboard/quick-actions'
import { CardSkeleton } from '@/components/ui/skeleton'

export const metadata = { title: 'Home' }
export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const user = await requireUser()
  const now = new Date()
  const settings = await db.settings.findUnique({ where: { userId: user.id } })
  // Dashboard data and (optional, cached, time-boxed) weather load in parallel.
  const [data, weather] = await Promise.all([
    getDashboard(user.id, now),
    settings?.weatherEnabled && settings.weatherLatitude != null && settings.weatherLongitude != null
      ? getWeather(settings.weatherLatitude, settings.weatherLongitude)
      : Promise.resolve(null),
  ])
  const hidden = settingsSafe(settings)
  const currency = settings?.currency ?? 'GBP'

  const show = (key: string) => !hidden.includes(key)

  return (
    <>
      <PageHeader
        title={`${greeting(now)}, ${user.name.split(' ')[0]}`}
        subtitle={formatDate(now, 'long')}
        actions={
          weather ? (
            <div className="flex items-center gap-2 rounded-xl border border-line/60 bg-surface px-3 py-2 text-[13px] text-muted">
              <CloudSun className="h-4 w-4 text-accent" />
              <span className="font-semibold text-ink">{Math.round(weather.tempC)}°C</span>
              <span className="hidden sm:inline">{weatherLabel(weather.code)}</span>
            </div>
          ) : undefined
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {show('balance') && (
          <Card className="col-span-2 border-accent/25 bg-gradient-to-br from-card to-accent-deep/10">
            <CardContent className="pt-4">
              <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Available balance</p>
              <p className="mt-1 text-[32px] font-bold tracking-tight text-ink">
                {formatMoney(data.balance, currency)}
              </p>
              <div className="mt-2 flex gap-4 text-[13px]">
                <span className="text-success">+{formatMoney(data.month.income, currency)} in</span>
                <span className="text-danger">−{formatMoney(data.month.expense, currency)} out</span>
              </div>
            </CardContent>
          </Card>
        )}
        {show('savings') && (
          <Link href="/money?tab=savings" className="col-span-1">
            <Card className="h-full transition-colors hover:border-accent/40">
              <CardContent className="pt-4">
                <PiggyBank className="h-4 w-4 text-success" />
                <p className="mt-2 text-[12px] font-semibold uppercase tracking-wider text-muted">Savings</p>
                <p className="mt-0.5 text-[20px] font-bold text-ink">{formatMoney(data.savings, currency)}</p>
              </CardContent>
            </Card>
          </Link>
        )}
        {show('tasks') && (
          <Link href="/tasks" className="col-span-1">
            <Card className="h-full transition-colors hover:border-accent/40">
              <CardContent className="pt-4">
                <ListTodo className="h-4 w-4 text-violet" />
                <p className="mt-2 text-[12px] font-semibold uppercase tracking-wider text-muted">Tasks</p>
                <p className="mt-0.5 text-[20px] font-bold text-ink">
                  {data.tasksRemaining} <span className="text-[13px] font-medium text-muted">remaining</span>
                </p>
              </CardContent>
            </Card>
          </Link>
        )}
      </div>

      <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-3">
        {show('work') && (
          <Link href="/work">
            <Card className="h-full transition-colors hover:border-accent/40">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <Briefcase className="h-4 w-4 text-accent" />
                  <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Work today</p>
                </div>
                {data.todayShift ? (
                  <>
                    <p className="mt-2 text-[17px] font-semibold text-ink">{shiftLabel(data.todayShift)}</p>
                    <p className="mt-0.5 truncate text-[13px] text-muted">
                      {data.todayShift.locationName ?? 'Shift'}
                      {data.todayShift.role ? ` · ${data.todayShift.role}` : ''}
                    </p>
                  </>
                ) : (
                  <p className="mt-2 text-[15px] text-muted">No shift today — enjoy the day off.</p>
                )}
              </CardContent>
            </Card>
          </Link>
        )}
        {show('event') && (
          <Link href="/calendar">
            <Card className="h-full transition-colors hover:border-accent/40">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <CalendarClock className="h-4 w-4 text-mint" />
                  <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Next up</p>
                </div>
                {data.nextEvent ? (
                  <>
                    <p className="mt-2 truncate text-[17px] font-semibold text-ink">{data.nextEvent.title}</p>
                    <p className="mt-0.5 text-[13px] text-muted">
                      {data.nextEvent.allDay ? 'All day' : formatTime(data.nextEvent.start)} ·{' '}
                      {formatDate(data.nextEvent.start, 'short')}
                    </p>
                  </>
                ) : (
                  <p className="mt-2 text-[15px] text-muted">Nothing scheduled ahead.</p>
                )}
              </CardContent>
            </Card>
          </Link>
        )}
        {show('career') && (
          <Link href="/career">
            <Card className="h-full transition-colors hover:border-accent/40">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-amber" />
                  <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Career</p>
                </div>
                <p className="mt-2 truncate text-[17px] font-semibold text-ink">
                  {data.careerCurrent ?? 'Set your current role'}
                </p>
                <p className="mt-0.5 text-[13px] text-muted">Current goal on your path</p>
              </CardContent>
            </Card>
          </Link>
        )}
      </div>

      {show('bills') && (
        <Card className="mt-3">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ReceiptText className="h-4 w-4 text-warning" />
                <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Bills due soon</p>
              </div>
              <Link href="/money?tab=bills" className="text-[13px] font-medium text-accent">
                View all
              </Link>
            </div>
            {data.billsSoon.length === 0 ? (
              <p className="mt-3 text-[14px] text-muted">No bills due in the next two weeks.</p>
            ) : (
              <ul className="mt-3 divide-y divide-line/50">
                {data.billsSoon.map((b) => (
                  <li key={b.id} className="flex items-center justify-between py-2.5">
                    <span className="truncate text-[14px] text-ink">{b.name}</span>
                    <span className="flex items-center gap-3">
                      <span className="text-[14px] font-semibold text-ink">{formatMoney(b.amount, currency)}</span>
                      <span
                        className={`w-20 text-right text-[12px] font-medium ${
                          b.days < 0 ? 'text-danger' : b.days <= 3 ? 'text-warning' : 'text-muted'
                        }`}
                      >
                        {b.days < 0 ? `${Math.abs(b.days)}d over` : b.days === 0 ? 'today' : `${b.days} days`}
                      </span>
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      )}

      {show('quick') && (
        <div className="mt-5">
          <p className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-muted">Quick actions</p>
          <Suspense fallback={<CardSkeleton />}>
            <QuickActions />
          </Suspense>
        </div>
      )}

      <p className="mt-6 flex items-center justify-center gap-1.5 text-center text-[12px] text-faint">
        <Wallet className="h-3.5 w-3.5" /> Productive today. A better tomorrow.
      </p>
    </>
  )
}
