import { requireUser } from '@/lib/auth/session'
import { getSettings } from '@/lib/services/work'
import { settingsSafe } from '@/lib/services/dashboard'
import { toDecimalNumber } from '@/lib/utils'
import { PageHeader } from '@/components/shell/page-header'
import { SettingsView } from '@/components/settings/settings-view'

export const metadata = { title: 'Settings' }
export const dynamic = 'force-dynamic'

export default async function SettingsPage() {
  const user = await requireUser()
  const settings = await getSettings(user.id)
  return (
    <>
      <PageHeader title="Settings" subtitle="Profile, dashboard, work rates and security" />
      <SettingsView
        data={{
          name: user.name,
          email: user.email,
          currency: settings.currency,
          weatherEnabled: settings.weatherEnabled,
          weatherLatitude: settings.weatherLatitude,
          weatherLongitude: settings.weatherLongitude,
          weatherLabel: settings.weatherLabel,
          workHourlyRate: toDecimalNumber(settings.workHourlyRate),
          workOvertimeThresholdMin: settings.workOvertimeThresholdMin,
          workOvertimeMultiplier: toDecimalNumber(settings.workOvertimeMultiplier),
          dashboardHidden: settingsSafe(settings),
        }}
      />
    </>
  )
}
