'use server'

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db/client'
import { requireUserId, type ActionResult } from '@/lib/actions/guard'
import { endAllSessions, requireSession } from '@/lib/auth/session'
import { changePassword, updateProfile } from '@/lib/services/auth'
import { getSettings } from '@/lib/services/work'
import {
  changePasswordSchema,
  dashboardConfigSchema,
  preferencesSchema,
  profileSchema,
  workRatesSchema,
} from '@/lib/validation/schemas'

export async function updateProfileAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = profileSchema.safeParse({ name: form.get('name'), email: form.get('email') })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const res = await updateProfile(userId, parsed.data)
  if (!res.ok) return res
  revalidatePath('/settings')
  revalidatePath('/')
  return { ok: true }
}

export async function updatePreferencesAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = preferencesSchema.safeParse({
    currency: form.get('currency') ?? 'GBP',
    weatherEnabled: form.get('weatherEnabled') === 'true',
    weatherLatitude: form.get('weatherLatitude') || null,
    weatherLongitude: form.get('weatherLongitude') || null,
    weatherLabel: form.get('weatherLabel') || null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await getSettings(userId).then((s) =>
    db.settings.update({
      where: { id: s.id },
      data: {
        currency: parsed.data.currency.toUpperCase(),
        weatherEnabled: parsed.data.weatherEnabled,
        weatherLatitude: parsed.data.weatherLatitude ?? null,
        weatherLongitude: parsed.data.weatherLongitude ?? null,
        weatherLabel: parsed.data.weatherLabel ?? null,
      },
    }),
  )
  revalidatePath('/settings')
  revalidatePath('/')
  return { ok: true }
}

export async function updateWorkRatesAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = workRatesSchema.safeParse({
    workHourlyRate: form.get('workHourlyRate') ?? '0',
    workOvertimeThresholdMin: form.get('workOvertimeThresholdMin') ?? '480',
    workOvertimeMultiplier: form.get('workOvertimeMultiplier') ?? '1.5',
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const settings = await getSettings(userId)
  await db.settings.update({ where: { id: settings.id }, data: parsed.data })
  revalidatePath('/settings')
  revalidatePath('/work')
  return { ok: true }
}

export async function updateDashboardConfigAction(hidden: string[]): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = dashboardConfigSchema.safeParse({ hidden })
  if (!parsed.success) return { ok: false, error: 'Invalid configuration' }
  const settings = await getSettings(userId)
  await db.settings.update({ where: { id: settings.id }, data: { dashboardHidden: parsed.data.hidden } })
  revalidatePath('/')
  revalidatePath('/settings')
  return { ok: true }
}

export async function changePasswordAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = changePasswordSchema.safeParse({
    currentPassword: form.get('currentPassword'),
    newPassword: form.get('newPassword'),
    confirm: form.get('confirm'),
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const res = await changePassword(userId, parsed.data)
  if (!res.ok) return res
  // Other sessions stay valid; the current one continues too.
  return { ok: true }
}

export async function signOutEverywhereAction(): Promise<ActionResult> {
  const session = await requireSession().catch(() => null)
  if (!session) return { ok: false, error: 'Not authenticated' }
  await endAllSessions(session.user.id, session.sessionId)
  revalidatePath('/settings')
  return { ok: true }
}
