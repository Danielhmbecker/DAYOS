'use server'

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db/client'
import { requireUserId, type ActionResult } from '@/lib/actions/guard'
import { adjustStock, completeCleaning, recordCount } from '@/lib/services/stockroom'
import { cleaningTaskSchema, stockCountSchema, stockItemSchema } from '@/lib/validation/schemas'

function field(form: FormData, key: string): string | undefined {
  const v = form.get(key)
  return v === null || v === '' ? undefined : String(v)
}

export async function saveStockItemAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = stockItemSchema.safeParse({
    name: form.get('name'),
    category: field(form, 'category') ?? 'General',
    unit: field(form, 'unit') ?? 'unit',
    quantity: form.get('quantity') ?? '0',
    threshold: form.get('threshold') ?? '0',
    location: field(form, 'location') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const id = field(form, 'id')
  if (id) {
    const existing = await db.stockItem.findFirst({ where: { id, userId } })
    if (!existing) return { ok: false, error: 'Item not found' }
    await db.stockItem.update({ where: { id }, data: parsed.data })
  } else {
    await db.stockItem.create({ data: { ...parsed.data, userId } })
  }
  revalidatePath('/stockroom')
  return { ok: true }
}

export async function adjustStockAction(itemId: string, delta: number): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  try {
    await adjustStock(userId, itemId, delta)
  } catch {
    return { ok: false, error: 'Item not found' }
  }
  revalidatePath('/stockroom')
  return { ok: true }
}

export async function recordCountAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = stockCountSchema.safeParse({
    itemId: form.get('itemId'),
    countedQuantity: form.get('countedQuantity'),
    note: field(form, 'note') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  try {
    await recordCount(userId, parsed.data.itemId, parsed.data.countedQuantity, parsed.data.note)
  } catch {
    return { ok: false, error: 'Item not found' }
  }
  revalidatePath('/stockroom')
  return { ok: true }
}

export async function deleteStockItemAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const existing = await db.stockItem.findFirst({ where: { id, userId } })
  if (!existing) return { ok: false, error: 'Item not found' }
  await db.stockItem.delete({ where: { id } })
  revalidatePath('/stockroom')
  return { ok: true }
}

export async function saveCleaningTaskAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = cleaningTaskSchema.safeParse({
    title: form.get('title'),
    area: field(form, 'area') ?? null,
    frequency: field(form, 'frequency') ?? 'WEEKLY',
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await db.cleaningTask.create({ data: { ...parsed.data, userId } })
  revalidatePath('/stockroom')
  return { ok: true }
}

export async function completeCleaningAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  try {
    await completeCleaning(userId, id)
  } catch {
    return { ok: false, error: 'Task not found' }
  }
  revalidatePath('/stockroom')
  return { ok: true }
}

export async function deleteCleaningTaskAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const existing = await db.cleaningTask.findFirst({ where: { id, userId } })
  if (!existing) return { ok: false, error: 'Task not found' }
  await db.cleaningTask.delete({ where: { id } })
  revalidatePath('/stockroom')
  return { ok: true }
}
