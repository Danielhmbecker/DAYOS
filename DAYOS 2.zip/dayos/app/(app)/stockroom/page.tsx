import { requireUser } from '@/lib/auth/session'
import { categoryHealth, cleaningStatus, listStock } from '@/lib/services/stockroom'
import { PageHeader } from '@/components/shell/page-header'
import { StockroomView } from '@/components/stockroom/stockroom-view'

export const metadata = { title: 'Stockroom' }
export const dynamic = 'force-dynamic'

export default async function StockroomPage() {
  const user = await requireUser()
  const [items, cleaning] = await Promise.all([listStock(user.id), cleaningStatus(user.id)])

  return (
    <>
      <PageHeader title="Stockroom" subtitle="Stock levels, counts and cleaning schedules" />
      <StockroomView
        items={items}
        health={categoryHealth(items)}
        cleaning={cleaning.map((c) => ({ ...c, lastCompletedAt: c.lastCompletedAt?.toISOString() ?? null }))}
      />
    </>
  )
}
