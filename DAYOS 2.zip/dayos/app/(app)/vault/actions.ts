'use server'

import { revalidatePath } from 'next/cache'
import { requireUserId, type ActionResult } from '@/lib/actions/guard'
import { deleteDocument, updateDocumentMeta, uploadDocument } from '@/lib/services/vault'
import { documentMetaSchema, MAX_UPLOAD_BYTES } from '@/lib/validation/schemas'

function tagsFrom(raw: unknown): string[] {
  return String(raw ?? '')
    .split(',')
    .map((t) => t.trim())
    .filter(Boolean)
    .slice(0, 10)
}

export async function uploadDocumentAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const file = form.get('file')
  if (!(file instanceof File) || file.size === 0) {
    return { ok: false, error: 'Choose a file to upload' }
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    return { ok: false, error: 'File too large — the limit is 10 MB' }
  }
  const parsed = documentMetaSchema.safeParse({
    name: form.get('name') || file.name,
    category: form.get('category') ?? 'OTHER',
    tags: tagsFrom(form.get('tags')),
    description: form.get('description') || null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const bytes = Buffer.from(await file.arrayBuffer())
  try {
    await uploadDocument(userId, { name: file.name, mime: file.type || 'application/octet-stream', bytes }, parsed.data)
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Upload failed' }
  }
  revalidatePath('/vault')
  return { ok: true }
}

export async function updateDocumentAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const id = String(form.get('id') ?? '')
  const parsed = documentMetaSchema.safeParse({
    name: form.get('name'),
    category: form.get('category') ?? 'OTHER',
    tags: tagsFrom(form.get('tags')),
    description: form.get('description') || null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  try {
    await updateDocumentMeta(userId, id, parsed.data)
  } catch {
    return { ok: false, error: 'Document not found' }
  }
  revalidatePath('/vault')
  return { ok: true }
}

export async function deleteDocumentAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  try {
    await deleteDocument(userId, id)
  } catch {
    return { ok: false, error: 'Document not found' }
  }
  revalidatePath('/vault')
  return { ok: true }
}
