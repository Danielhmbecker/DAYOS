import { requireUser } from '@/lib/auth/session'
import { listDocuments, humanSize } from '@/lib/services/vault'
import { PageHeader } from '@/components/shell/page-header'
import { VaultView } from '@/components/vault/vault-view'

export const metadata = { title: 'Vault' }
export const dynamic = 'force-dynamic'

export default async function VaultPage() {
  const user = await requireUser()
  const documents = await listDocuments(user.id)
  return (
    <>
      <PageHeader title="Vault" subtitle="Private documents — stored on your infrastructure" />
      <VaultView
        documents={documents.map((d) => ({
          id: d.id,
          name: d.name,
          mime: d.mime,
          size: humanSize(d.sizeBytes),
          category: d.category,
          tags: d.tags,
          uploadedAt: d.uploadedAt.toISOString(),
          description: d.description,
        }))}
      />
    </>
  )
}
