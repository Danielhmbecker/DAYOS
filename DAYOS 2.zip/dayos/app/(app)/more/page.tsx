import Link from 'next/link'
import { MORE_NAV, FUTURE_MODULES } from '@/lib/nav'
import { PageHeader } from '@/components/shell/page-header'
import { Badge } from '@/components/ui/badge'

export const metadata = { title: 'More' }

export default function MorePage() {
  return (
    <>
      <PageHeader title="More" subtitle="Everything else in your operating system" />
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
        {MORE_NAV.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="flex min-h-[96px] flex-col items-center justify-center gap-2 rounded-card border border-line/70 bg-card p-3 text-muted transition-colors hover:border-accent/40 hover:text-ink active:scale-[0.98]"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-elevate">
              <item.icon className="h-5 w-5 text-accent" />
            </span>
            <span className="text-[13px] font-medium text-ink">{item.label}</span>
          </Link>
        ))}
        {FUTURE_MODULES.map((item) => (
          <div
            key={item.href}
            aria-disabled="true"
            className="flex min-h-[96px] flex-col items-center justify-center gap-2 rounded-card border border-dashed border-line/60 bg-surface/40 p-3 opacity-60"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-elevate/60">
              <item.icon className="h-5 w-5 text-faint" />
            </span>
            <span className="text-[13px] font-medium text-muted">{item.label}</span>
            <Badge tone="neutral">Soon</Badge>
          </div>
        ))}
      </div>
      <p className="mt-6 text-[13px] leading-relaxed text-muted">
        DAYOS is modular by design: BetLab, Turbo, an AI assistant, habits, health and projects are
        documented future modules that plug into the same architecture (see docs/MODULES.md). Nothing
        here is a dead button — future modules are clearly marked until they ship.
      </p>
    </>
  )
}
