'use server'

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db/client'
import { requireUserId, type ActionResult } from '@/lib/actions/guard'
import {
  billSchema,
  budgetSchema,
  categorySchema,
  savingsGoalSchema,
  transactionSchema,
} from '@/lib/validation/schemas'
import { payBill } from '@/lib/services/money'

function field(form: FormData, key: string): string | undefined {
  const v = form.get(key)
  return v === null || v === '' ? undefined : String(v)
}

async function own(id: string, userId: string, model: 'transaction' | 'budget' | 'bill' | 'savingsGoal' | 'category') {
  const map = {
    transaction: db.transaction,
    budget: db.budget,
    bill: db.bill,
    savingsGoal: db.savingsGoal,
    category: db.category,
  } as const
  const row = await (map[model] as never as { findFirst: (a: unknown) => Promise<{ id: string; userId: string } | null> }).findFirst({
    where: { id, userId },
  })
  return row
}

export async function saveTransactionAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = transactionSchema.safeParse({
    type: form.get('type'),
    amount: form.get('amount'),
    categoryId: field(form, 'categoryId') ?? null,
    note: field(form, 'note') ?? null,
    date: form.get('date'),
    recurrence: field(form, 'recurrence') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const id = field(form, 'id')
  const data = {
    type: parsed.data.type,
    amount: parsed.data.amount,
    categoryId: parsed.data.categoryId ?? null,
    note: parsed.data.note ?? null,
    date: parsed.data.date,
    recurrence: parsed.data.recurrence ?? null,
    nextDueDate: parsed.data.recurrence ? parsed.data.date : null,
  }
  if (id) {
    if (!(await own(id, userId, 'transaction'))) return { ok: false, error: 'Transaction not found' }
    await db.transaction.update({ where: { id }, data })
  } else {
    await db.transaction.create({ data: { ...data, userId } })
  }
  revalidatePath('/money')
  revalidatePath('/')
  return { ok: true }
}

export async function deleteTransactionAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await own(id, userId, 'transaction'))) return { ok: false, error: 'Transaction not found' }
  await db.transaction.delete({ where: { id } })
  revalidatePath('/money')
  revalidatePath('/')
  return { ok: true }
}

export async function saveCategoryAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = categorySchema.safeParse({
    name: form.get('name'),
    type: form.get('type'),
    color: field(form, 'color') ?? '#38BDF8',
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const existing = await db.category.findFirst({
    where: { userId, name: parsed.data.name, type: parsed.data.type },
  })
  if (existing) return { ok: false, error: 'That category already exists' }
  await db.category.create({ data: { ...parsed.data, userId } })
  revalidatePath('/money')
  return { ok: true }
}

export async function saveBudgetAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = budgetSchema.safeParse({
    categoryId: form.get('categoryId'),
    monthlyLimit: form.get('monthlyLimit'),
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const id = field(form, 'id')
  if (id) {
    if (!(await own(id, userId, 'budget'))) return { ok: false, error: 'Budget not found' }
    await db.budget.update({ where: { id }, data: { monthlyLimit: parsed.data.monthlyLimit } })
  } else {
    const existing = await db.budget.findFirst({ where: { userId, categoryId: parsed.data.categoryId } })
    if (existing) return { ok: false, error: 'This category already has a budget' }
    await db.budget.create({ data: { ...parsed.data, userId } })
  }
  revalidatePath('/money')
  return { ok: true }
}

export async function deleteBudgetAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await own(id, userId, 'budget'))) return { ok: false, error: 'Budget not found' }
  await db.budget.delete({ where: { id } })
  revalidatePath('/money')
  return { ok: true }
}

export async function saveBillAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = billSchema.safeParse({
    name: form.get('name'),
    amount: form.get('amount'),
    frequency: field(form, 'frequency') ?? 'MONTHLY',
    nextDueDate: form.get('nextDueDate'),
    notes: field(form, 'notes') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const id = field(form, 'id')
  if (id) {
    if (!(await own(id, userId, 'bill'))) return { ok: false, error: 'Bill not found' }
    await db.bill.update({ where: { id }, data: parsed.data })
  } else {
    await db.bill.create({ data: { ...parsed.data, userId } })
  }
  revalidatePath('/money')
  revalidatePath('/')
  return { ok: true }
}

export async function payBillAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  try {
    await payBill(id, userId)
  } catch {
    return { ok: false, error: 'Bill not found' }
  }
  revalidatePath('/money')
  revalidatePath('/')
  return { ok: true }
}

export async function deleteBillAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await own(id, userId, 'bill'))) return { ok: false, error: 'Bill not found' }
  await db.bill.delete({ where: { id } })
  revalidatePath('/money')
  return { ok: true }
}

export async function saveGoalAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = savingsGoalSchema.safeParse({
    name: form.get('name'),
    targetAmount: form.get('targetAmount'),
    savedAmount: form.get('savedAmount') ?? '0',
    deadline: field(form, 'deadline') ?? null,
    color: field(form, 'color') ?? '#34D399',
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const id = field(form, 'id')
  if (id) {
    if (!(await own(id, userId, 'savingsGoal'))) return { ok: false, error: 'Goal not found' }
    await db.savingsGoal.update({ where: { id }, data: parsed.data })
  } else {
    await db.savingsGoal.create({ data: { ...parsed.data, userId } })
  }
  revalidatePath('/money')
  revalidatePath('/')
  return { ok: true }
}

export async function addToGoalAction(id: string, amount: number): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const goal = await db.savingsGoal.findFirst({ where: { id, userId } })
  if (!goal) return { ok: false, error: 'Goal not found' }
  if (!Number.isFinite(amount) || amount <= 0) return { ok: false, error: 'Enter a positive amount' }
  await db.savingsGoal.update({ where: { id }, data: { savedAmount: { increment: amount } } })
  revalidatePath('/money')
  revalidatePath('/')
  return { ok: true }
}

export async function deleteGoalAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await own(id, userId, 'savingsGoal'))) return { ok: false, error: 'Goal not found' }
  await db.savingsGoal.delete({ where: { id } })
  revalidatePath('/money')
  return { ok: true }
}
