import Link from 'next/link'
import { requireUser } from '@/lib/auth/session'
import { db } from '@/lib/db/client'
import {
  budgetProgress,
  materialiseRecurring,
  monthTotals,
  monthlySeries,
  savingsTotal,
  upcomingBills,
  availableBalance,
  listTransactions,
} from '@/lib/services/money'
import { formatMoney } from '@/lib/utils'
import { toDecimalNumber } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { PageHeader } from '@/components/shell/page-header'
import { MoneyChart } from '@/components/money/chart-lazy'
import { TransactionsPanel } from '@/components/money/transactions-panel'
import { BudgetsPanel } from '@/components/money/budgets-panel'
import { BillsPanel } from '@/components/money/bills-panel'
import { SavingsPanel } from '@/components/money/savings-panel'
import { Progress } from '@/components/ui/progress'

export const metadata = { title: 'Money' }
export const dynamic = 'force-dynamic'

const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'transactions', label: 'Transactions' },
  { id: 'budgets', label: 'Budgets' },
  { id: 'bills', label: 'Bills' },
  { id: 'savings', label: 'Savings' },
] as const

type TabId = (typeof TABS)[number]['id']

export default async function MoneyPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const { tab: rawTab } = await searchParams
  const tab: TabId = TABS.some((t) => t.id === rawTab) ? (rawTab as TabId) : 'overview'
  const user = await requireUser()
  const now = new Date()

  await materialiseRecurring(user.id, now)

  const [totals, series, budgets, bills, savings, transactions, categories, balance] = await Promise.all([
    monthTotals(user.id, now),
    monthlySeries(user.id, 6),
    budgetProgress(user.id, now),
    upcomingBills(user.id, 60, now),
    savingsTotal(user.id),
    listTransactions(user.id),
    db.category.findMany({ where: { userId: user.id, archived: false }, orderBy: { name: 'asc' } }),
    availableBalance(user.id, now),
  ])

  const settings = await db.settings.findUnique({ where: { userId: user.id } })
  const currency = settings?.currency ?? 'GBP'

  const txRows = transactions.map((t) => ({
    id: t.id,
    type: t.type,
    amount: toDecimalNumber(t.amount),
    note: t.note,
    date: t.date.toISOString(),
    categoryName: t.category?.name ?? null,
    categoryColor: t.category?.color ?? null,
    recurrence: t.recurrence,
  }))
  const categoryOptions = categories.map((c) => ({ id: c.id, name: c.name, type: c.type, color: c.color }))

  return (
    <>
      <PageHeader title="Money" subtitle={`Available ${formatMoney(balance, currency)} · ${now.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}`} />

      <nav aria-label="Money sections" className="mb-4 flex gap-1 overflow-x-auto rounded-xl border border-line/60 bg-surface p-1">
        {TABS.map((t) => (
          <Link
            key={t.id}
            href={`/money?tab=${t.id}`}
            aria-current={tab === t.id ? 'page' : undefined}
            className={`flex h-9 flex-1 whitespace-nowrap items-center justify-center rounded-lg px-3 text-[13px] font-medium transition-colors ${
              tab === t.id ? 'bg-elevate text-ink' : 'text-muted hover:text-ink'
            }`}
          >
            {t.label}
          </Link>
        ))}
      </nav>

      {tab === 'overview' && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Card>
              <CardContent className="pt-4">
                <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Income</p>
                <p className="mt-1 text-[20px] font-bold text-success">{formatMoney(totals.income, currency)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Spending</p>
                <p className="mt-1 text-[20px] font-bold text-danger">{formatMoney(totals.expense, currency)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Remaining</p>
                <p className="mt-1 text-[20px] font-bold text-ink">{formatMoney(totals.remaining, currency)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Savings</p>
                <p className="mt-1 text-[20px] font-bold text-mint">{formatMoney(savings, currency)}</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardContent className="pt-4">
              <p className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-muted">Last 6 months</p>
              <MoneyChart data={series} currency={currency} />
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <Card>
              <CardContent className="pt-4">
                <p className="mb-3 text-[12px] font-semibold uppercase tracking-wider text-muted">Budget progress</p>
                {budgets.length === 0 ? (
                  <p className="text-[14px] text-muted">No budgets yet — add one in the Budgets tab.</p>
                ) : (
                  <ul className="space-y-3">
                    {budgets.slice(0, 4).map((b) => (
                      <li key={b.id}>
                        <div className="flex justify-between text-[13px]">
                          <span className="text-ink">{b.category}</span>
                          <span className="text-muted">
                            {formatMoney(b.used, currency)} / {formatMoney(b.limit, currency)}
                          </span>
                        </div>
                        <Progress className="mt-1" value={b.percent} tone={b.over ? 'danger' : b.percent > 80 ? 'warning' : 'success'} />
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <p className="mb-3 text-[12px] font-semibold uppercase tracking-wider text-muted">Upcoming bills</p>
                {bills.length === 0 ? (
                  <p className="text-[14px] text-muted">Nothing scheduled — add bills to get reminders.</p>
                ) : (
                  <ul className="space-y-2.5">
                    {bills.slice(0, 5).map((b) => (
                      <li key={b.id} className="flex items-center justify-between text-[14px]">
                        <span className="truncate text-ink">{b.name}</span>
                        <span className="flex items-center gap-2">
                          <span className="font-semibold text-ink">{formatMoney(b.amount, currency)}</span>
                          <span className={`text-[12px] ${b.state === 'overdue' ? 'text-danger' : b.state === 'soon' ? 'text-warning' : 'text-muted'}`}>
                            {b.days < 0 ? `${Math.abs(b.days)}d over` : b.days === 0 ? 'today' : `${b.days}d`}
                          </span>
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {tab === 'transactions' && <TransactionsPanel rows={txRows} categories={categoryOptions} currency={currency} />}
      {tab === 'budgets' && <BudgetsPanel budgets={budgets} categories={categoryOptions} currency={currency} />}
      {tab === 'bills' && (
        <BillsPanel
          bills={bills.map((b) => ({
            id: b.id,
            name: b.name,
            amount: b.amount,
            frequency: b.frequency,
            nextDue: b.nextDueDate.toISOString(),
            days: b.days,
            state: b.state,
          }))}
          currency={currency}
        />
      )}
      {tab === 'savings' && (
        <SavingsPanel
          goals={(
            await db.savingsGoal.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'asc' } })
          ).map((g) => ({
            id: g.id,
            name: g.name,
            target: toDecimalNumber(g.targetAmount),
            saved: toDecimalNumber(g.savedAmount),
            deadline: g.deadline?.toISOString() ?? null,
            color: g.color,
          }))}
          currency={currency}
        />
      )}
    </>
  )
}
