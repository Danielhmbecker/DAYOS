import { PageSkeleton } from '@/components/shell/page-skeleton'

export default function Loading() {
  return <PageSkeleton cards={4} rows={3} />
}
