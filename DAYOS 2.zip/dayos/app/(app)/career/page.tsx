import { requireUser } from '@/lib/auth/session'
import { db } from '@/lib/db/client'
import { PageHeader } from '@/components/shell/page-header'
import { CareerView } from '@/components/career/career-view'

export const metadata = { title: 'Career' }
export const dynamic = 'force-dynamic'

export default async function CareerPage() {
  const user = await requireUser()
  const [stages, applications, courses, certificates, skills] = await Promise.all([
    db.careerStage.findMany({ where: { userId: user.id }, orderBy: { order: 'asc' } }),
    db.careerApplication.findMany({ where: { userId: user.id }, orderBy: { updatedAt: 'desc' } }),
    db.course.findMany({ where: { userId: user.id }, orderBy: { title: 'asc' } }),
    db.certificate.findMany({ where: { userId: user.id }, orderBy: { issuedAt: 'desc' } }),
    db.skill.findMany({ where: { userId: user.id }, orderBy: { level: 'desc' } }),
  ])

  return (
    <>
      <PageHeader title="Career" subtitle="Your path, applications and growth — in one view" />
      <CareerView
        stages={stages.map((s) => ({ id: s.id, title: s.title, subtitle: s.subtitle, order: s.order, isCurrent: s.isCurrent }))}
        applications={applications.map((a) => ({
          id: a.id,
          company: a.company,
          role: a.role,
          salary: a.salary,
          location: a.location,
          workMode: a.workMode,
          status: a.status,
          appliedDate: a.appliedDate?.toISOString() ?? null,
          interviewDate: a.interviewDate?.toISOString() ?? null,
          cvVersion: a.cvVersion,
          notes: a.notes,
        }))}
        courses={courses.map((c) => ({ id: c.id, title: c.title, provider: c.provider, status: c.status }))}
        certificates={certificates.map((c) => ({
          id: c.id,
          title: c.title,
          issuer: c.issuer,
          issuedAt: c.issuedAt?.toISOString() ?? null,
          expiresAt: c.expiresAt?.toISOString() ?? null,
        }))}
        skills={skills.map((s) => ({ id: s.id, name: s.name, level: s.level }))}
      />
    </>
  )
}
