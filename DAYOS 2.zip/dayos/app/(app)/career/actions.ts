'use server'

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db/client'
import { requireUserId, type ActionResult } from '@/lib/actions/guard'
import {
  applicationSchema,
  careerStageSchema,
  certificateSchema,
  courseSchema,
  skillSchema,
} from '@/lib/validation/schemas'

function field(form: FormData, key: string): string | undefined {
  const v = form.get(key)
  return v === null || v === '' ? undefined : String(v)
}

async function owns(model: 'careerStage' | 'careerApplication' | 'course' | 'certificate' | 'skill', id: string, userId: string) {
  const map = { careerStage: db.careerStage, careerApplication: db.careerApplication, course: db.course, certificate: db.certificate, skill: db.skill } as const
  return (map[model] as unknown as { findFirst: (a: object) => Promise<{ id: string } | null> }).findFirst({
    where: { id, userId },
  })
}

export async function saveStageAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = careerStageSchema.safeParse({ title: form.get('title'), subtitle: field(form, 'subtitle') ?? null })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const count = await db.careerStage.count({ where: { userId } })
  await db.careerStage.create({
    data: { userId, title: parsed.data.title, subtitle: parsed.data.subtitle, order: count + 1, isCurrent: count === 0 },
  })
  revalidatePath('/career')
  return { ok: true }
}

export async function setCurrentStageAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await owns('careerStage', id, userId))) return { ok: false, error: 'Stage not found' }
  await db.$transaction([
    db.careerStage.updateMany({ where: { userId }, data: { isCurrent: false } }),
    db.careerStage.update({ where: { id }, data: { isCurrent: true } }),
  ])
  revalidatePath('/career')
  revalidatePath('/')
  return { ok: true }
}

export async function moveStageAction(id: string, dir: -1 | 1): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const stage = await db.careerStage.findFirst({ where: { id, userId } })
  if (!stage) return { ok: false, error: 'Stage not found' }
  const swap = await db.careerStage.findFirst({ where: { userId, order: stage.order + dir } })
  if (!swap) return { ok: true }
  await db.$transaction([
    db.careerStage.update({ where: { id: stage.id }, data: { order: swap.order } }),
    db.careerStage.update({ where: { id: swap.id }, data: { order: stage.order } }),
  ])
  revalidatePath('/career')
  return { ok: true }
}

export async function deleteStageAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await owns('careerStage', id, userId))) return { ok: false, error: 'Stage not found' }
  await db.careerStage.delete({ where: { id } })
  revalidatePath('/career')
  return { ok: true }
}

export async function saveApplicationAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = applicationSchema.safeParse({
    company: form.get('company'),
    role: form.get('role'),
    salary: field(form, 'salary') ?? null,
    location: field(form, 'location') ?? null,
    workMode: field(form, 'workMode') ?? 'ONSITE',
    status: field(form, 'status') ?? 'SAVED',
    appliedDate: field(form, 'appliedDate') ?? null,
    interviewDate: field(form, 'interviewDate') ?? null,
    cvVersion: field(form, 'cvVersion') ?? null,
    notes: field(form, 'notes') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const id = field(form, 'id')
  if (id) {
    if (!(await owns('careerApplication', id, userId))) return { ok: false, error: 'Application not found' }
    await db.careerApplication.update({ where: { id }, data: parsed.data })
  } else {
    await db.careerApplication.create({ data: { ...parsed.data, userId } })
  }
  revalidatePath('/career')
  return { ok: true }
}

export async function setApplicationStatusAction(id: string, status: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await owns('careerApplication', id, userId))) return { ok: false, error: 'Application not found' }
  await db.careerApplication.update({ where: { id }, data: { status: status as never } })
  revalidatePath('/career')
  return { ok: true }
}

export async function deleteApplicationAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await owns('careerApplication', id, userId))) return { ok: false, error: 'Application not found' }
  await db.careerApplication.delete({ where: { id } })
  revalidatePath('/career')
  return { ok: true }
}

export async function saveCourseAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = courseSchema.safeParse({
    title: form.get('title'),
    provider: field(form, 'provider') ?? null,
    status: field(form, 'status') ?? 'PLANNED',
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const id = field(form, 'id')
  const completedAt = parsed.data.status === 'COMPLETED' ? new Date() : null
  if (id) {
    if (!(await owns('course', id, userId))) return { ok: false, error: 'Course not found' }
    await db.course.update({ where: { id }, data: { ...parsed.data, completedAt } })
  } else {
    await db.course.create({ data: { ...parsed.data, completedAt, userId } })
  }
  revalidatePath('/career')
  return { ok: true }
}

export async function deleteCourseAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await owns('course', id, userId))) return { ok: false, error: 'Course not found' }
  await db.course.delete({ where: { id } })
  revalidatePath('/career')
  return { ok: true }
}

export async function saveCertificateAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = certificateSchema.safeParse({
    title: form.get('title'),
    issuer: field(form, 'issuer') ?? null,
    issuedAt: field(form, 'issuedAt') ?? null,
    expiresAt: field(form, 'expiresAt') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await db.certificate.create({ data: { ...parsed.data, userId } })
  revalidatePath('/career')
  return { ok: true }
}

export async function deleteCertificateAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await owns('certificate', id, userId))) return { ok: false, error: 'Certificate not found' }
  await db.certificate.delete({ where: { id } })
  revalidatePath('/career')
  return { ok: true }
}

export async function saveSkillAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = skillSchema.safeParse({ name: form.get('name'), level: form.get('level') ?? '3' })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await db.skill.create({ data: { ...parsed.data, userId } })
  revalidatePath('/career')
  return { ok: true }
}

export async function deleteSkillAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  if (!(await owns('skill', id, userId))) return { ok: false, error: 'Skill not found' }
  await db.skill.delete({ where: { id } })
  revalidatePath('/career')
  return { ok: true }
}
