import { PageSkeleton } from '@/components/shell/page-skeleton'

export default function Loading() {
  return <PageSkeleton cards={3} rows={4} />
}
