'use server'

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db/client'
import { requireUserId, type ActionResult } from '@/lib/actions/guard'
import { taskSchema } from '@/lib/validation/schemas'

function field(form: FormData, key: string): string | undefined {
  const v = form.get(key)
  return v === null || v === '' ? undefined : String(v)
}

export async function saveTaskAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = taskSchema.safeParse({
    title: form.get('title'),
    description: field(form, 'description') ?? null,
    dueDate: field(form, 'dueDate') ?? null,
    priority: field(form, 'priority') ?? 'MEDIUM',
    status: field(form, 'status') ?? 'TODO',
    category: field(form, 'category') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const id = field(form, 'id')
  if (id) {
    const existing = await db.task.findFirst({ where: { id, userId } })
    if (!existing) return { ok: false, error: 'Task not found' }
    await db.task.update({ where: { id }, data: parsed.data })
  } else {
    await db.task.create({ data: { ...parsed.data, userId } })
  }
  revalidatePath('/tasks')
  revalidatePath('/')
  return { ok: true }
}

export async function setTaskStatusAction(id: string, status: 'TODO' | 'IN_PROGRESS' | 'DONE'): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const existing = await db.task.findFirst({ where: { id, userId } })
  if (!existing) return { ok: false, error: 'Task not found' }
  await db.task.update({ where: { id }, data: { status } })
  revalidatePath('/tasks')
  revalidatePath('/')
  return { ok: true }
}

export async function deleteTaskAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const existing = await db.task.findFirst({ where: { id, userId } })
  if (!existing) return { ok: false, error: 'Task not found' }
  await db.task.delete({ where: { id } })
  revalidatePath('/tasks')
  revalidatePath('/')
  return { ok: true }
}
