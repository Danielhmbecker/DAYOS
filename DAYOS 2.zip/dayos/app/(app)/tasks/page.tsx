import { requireUser } from '@/lib/auth/session'
import { db } from '@/lib/db/client'
import { PageHeader } from '@/components/shell/page-header'
import { TasksView } from '@/components/tasks/tasks-view'

export const metadata = { title: 'Tasks' }
export const dynamic = 'force-dynamic'

export default async function TasksPage() {
  const user = await requireUser()
  const tasks = await db.task.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } })
  const open = tasks.filter((t) => t.status !== 'DONE').length

  return (
    <>
      <PageHeader title="Tasks" subtitle={`${open} open · unified across your life`} />
      <TasksView
        tasks={tasks.map((t) => ({
          id: t.id,
          title: t.title,
          description: t.description,
          dueDate: t.dueDate?.toISOString() ?? null,
          priority: t.priority,
          status: t.status,
          category: t.category,
        }))}
      />
    </>
  )
}
