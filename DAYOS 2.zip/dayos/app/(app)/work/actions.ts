'use server'

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db/client'
import { requireUserId, type ActionResult } from '@/lib/actions/guard'
import { shiftSchema, workLocationSchema, workTaskSchema } from '@/lib/validation/schemas'
import { resolveShiftEnd, combineShiftTimes } from '@/lib/services/work'

function field(form: FormData, key: string): string | undefined {
  const v = form.get(key)
  return v === null || v === '' ? undefined : String(v)
}

export async function saveShiftAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = shiftSchema.safeParse({
    locationId: field(form, 'locationId') ?? null,
    role: field(form, 'role') ?? null,
    date: form.get('date'),
    startTime: form.get('startTime'),
    endTime: form.get('endTime'),
    breakMinutes: form.get('breakMinutes') ?? '0',
    notes: field(form, 'notes') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const start = combineShiftTimes(parsed.data.date, parsed.data.startTime)
  const end = resolveShiftEnd(parsed.data.date, parsed.data.startTime, parsed.data.endTime)
  const id = field(form, 'id')
  const data = {
    locationId: parsed.data.locationId ?? null,
    role: parsed.data.role ?? null,
    date: parsed.data.date,
    start,
    end,
    breakMinutes: parsed.data.breakMinutes,
    notes: parsed.data.notes ?? null,
  }
  if (id) {
    const existing = await db.workShift.findFirst({ where: { id, userId } })
    if (!existing) return { ok: false, error: 'Shift not found' }
    await db.workShift.update({ where: { id }, data })
  } else {
    await db.workShift.create({ data: { ...data, userId } })
  }
  revalidatePath('/work')
  revalidatePath('/')
  return { ok: true }
}

export async function deleteShiftAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const existing = await db.workShift.findFirst({ where: { id, userId } })
  if (!existing) return { ok: false, error: 'Shift not found' }
  await db.workShift.delete({ where: { id } })
  revalidatePath('/work')
  return { ok: true }
}

export async function saveWorkTaskAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = workTaskSchema.safeParse({
    title: form.get('title'),
    locationId: field(form, 'locationId') ?? null,
    dueDate: field(form, 'dueDate') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await db.workTask.create({ data: { ...parsed.data, userId } })
  revalidatePath('/work')
  return { ok: true }
}

export async function toggleWorkTaskAction(id: string, done: boolean): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const existing = await db.workTask.findFirst({ where: { id, userId } })
  if (!existing) return { ok: false, error: 'Task not found' }
  await db.workTask.update({ where: { id }, data: { done } })
  revalidatePath('/work')
  return { ok: true }
}

export async function deleteWorkTaskAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const existing = await db.workTask.findFirst({ where: { id, userId } })
  if (!existing) return { ok: false, error: 'Task not found' }
  await db.workTask.delete({ where: { id } })
  revalidatePath('/work')
  return { ok: true }
}

export async function saveLocationAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = workLocationSchema.safeParse({
    name: form.get('name'),
    role: field(form, 'role') ?? null,
    hourlyRate: field(form, 'hourlyRate') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await db.workLocation.create({ data: { ...parsed.data, userId } })
  revalidatePath('/work')
  revalidatePath('/settings')
  return { ok: true }
}
