import { Clock, Gauge, Wallet, CalendarDays } from 'lucide-react'
import { requireUser } from '@/lib/auth/session'
import { db } from '@/lib/db/client'
import { monthSummary, shiftsInRange, shiftLabel } from '@/lib/services/work'
import { getSettings } from '@/lib/services/work'
import { endOfMonth, startOfDay, endOfDay, startOfMonth, formatMoney, toDecimalNumber } from '@/lib/utils'
import { hoursLabel } from '@/lib/calc/schedule'
import { Card, CardContent } from '@/components/ui/card'
import { PageHeader } from '@/components/shell/page-header'
import { ShiftsPanel } from '@/components/work/shifts-panel'
import { WorkTasksPanel } from '@/components/work/tasks-panel'

export const metadata = { title: 'Work' }
export const dynamic = 'force-dynamic'

export default async function WorkPage() {
  const user = await requireUser()
  const now = new Date()
  const [summary, todayShifts, monthShifts, tasks, locations, settings] = await Promise.all([
    monthSummary(user.id, now),
    shiftsInRange(user.id, startOfDay(now), endOfDay(now)),
    shiftsInRange(user.id, startOfMonth(now), endOfMonth(now)),
    db.workTask.findMany({ where: { userId: user.id }, include: { location: true }, orderBy: [{ done: 'asc' }, { createdAt: 'desc' }] }),
    db.workLocation.findMany({ where: { userId: user.id, active: true }, orderBy: { name: 'asc' } }),
    getSettings(user.id),
  ])
  const currency = settings.currency

  return (
    <>
      <PageHeader
        title="Work"
        subtitle={now.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
      />

      <Card className="border-accent/25">
        <CardContent className="pt-4">
          <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Today</p>
          {todayShifts[0] ? (
            <>
              <p className="mt-1 text-[24px] font-bold text-ink">{shiftLabel(todayShifts[0])}</p>
              <p className="mt-0.5 text-[13px] text-muted">
                {todayShifts[0].locationName ?? 'Shift'}
                {todayShifts[0].role ? ` · ${todayShifts[0].role}` : ''} · est.{' '}
                {formatMoney(todayShifts[0].pay.pay, currency)}
              </p>
            </>
          ) : (
            <p className="mt-1 text-[17px] text-muted">No shift scheduled today.</p>
          )}
        </CardContent>
      </Card>

      <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card>
          <CardContent className="pt-4">
            <CalendarDays className="h-4 w-4 text-accent" />
            <p className="mt-2 text-[12px] font-semibold uppercase tracking-wider text-muted">Shifts</p>
            <p className="text-[20px] font-bold text-ink">{summary.shiftCount}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <Clock className="h-4 w-4 text-mint" />
            <p className="mt-2 text-[12px] font-semibold uppercase tracking-wider text-muted">Hours</p>
            <p className="text-[20px] font-bold text-ink">{hoursLabel(summary.hoursMinutes)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <Gauge className="h-4 w-4 text-warning" />
            <p className="mt-2 text-[12px] font-semibold uppercase tracking-wider text-muted">Overtime</p>
            <p className="text-[20px] font-bold text-ink">{hoursLabel(summary.overtimeMinutes)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <Wallet className="h-4 w-4 text-success" />
            <p className="mt-2 text-[12px] font-semibold uppercase tracking-wider text-muted">Est. pay</p>
            <p className="text-[20px] font-bold text-ink">{formatMoney(summary.estimatedPay, currency)}</p>
          </CardContent>
        </Card>
      </div>

      <p className="mb-2 mt-6 text-[12px] font-semibold uppercase tracking-wider text-muted">
        This month's shifts
      </p>
      <ShiftsPanel
        currency={currency}
        locations={locations.map((l) => ({ id: l.id, name: l.name, role: l.role }))}
        shifts={monthShifts.map((s) => ({
          id: s.id,
          date: s.date.toISOString(),
          start: s.start.toISOString(),
          end: s.end.toISOString(),
          breakMinutes: s.breakMinutes,
          locationName: s.locationName,
          role: s.role,
          notes: s.notes,
          workedMinutes: s.pay.workedMinutes,
          overtimeMinutes: s.pay.overtimeMinutes,
          pay: s.pay.pay,
          isToday: s.date.toDateString() === now.toDateString(),
        }))}
      />

      <p className="mb-2 mt-6 text-[12px] font-semibold uppercase tracking-wider text-muted">Work tasks</p>
      <WorkTasksPanel
        tasks={tasks.map((t) => ({ id: t.id, title: t.title, done: t.done, locationName: t.location?.name ?? null }))}
      />

      <p className="mt-6 text-[12px] text-faint">
        Hourly rate {formatMoney(toDecimalNumber(settings.workHourlyRate), currency)} · overtime after{' '}
        {hoursLabel(settings.workOvertimeThresholdMin)} at ×{toDecimalNumber(settings.workOvertimeMultiplier)} — change
        in Settings → Work rates.
      </p>
    </>
  )
}
