import type { ReactNode } from 'react'
import { requireUser } from '@/lib/auth/session'
import { db } from '@/lib/db/client'
import { AppHeader } from '@/components/navigation/app-header'
import { BottomNav } from '@/components/navigation/bottom-nav'
import { Sidebar } from '@/components/navigation/sidebar'
import { QuickCapture } from '@/components/shell/quick-capture'

export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await requireUser()
  const categories = await db.category.findMany({
    where: { userId: user.id, archived: false },
    select: { id: true, name: true, type: true },
    orderBy: { name: 'asc' },
  })

  return (
    <div className="min-h-dvh bg-bg">
      <Sidebar />
      <div className="md:pl-60">
        <AppHeader user={user} />
        <main className="mx-auto max-w-6xl px-4 pb-32 pt-5 md:pb-16 safe-bottom">{children}</main>
      </div>
      <BottomNav />
      <QuickCapture categories={categories} />
    </div>
  )
}
