'use server'

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db/client'
import { requireUserId, type ActionResult } from '@/lib/actions/guard'
import { eventSchema } from '@/lib/validation/schemas'
import { combineShiftTimes } from '@/lib/services/work'

function field(form: FormData, key: string): string | undefined {
  const v = form.get(key)
  return v === null || v === '' ? undefined : String(v)
}

export async function saveEventAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const dateValue = form.get('date')
  const parsed = eventSchema.safeParse({
    title: form.get('title'),
    start: dateValue,
    endTime: field(form, 'endTime') ?? null,
    allDay: form.get('allDay') === 'on' || form.get('allDay') === 'true',
    location: field(form, 'location') ?? null,
    notes: field(form, 'notes') ?? null,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const start = parsed.data.allDay
    ? new Date(new Date(parsed.data.start).setHours(0, 0, 0, 0))
    : combineShiftTimes(parsed.data.start, (form.get('startTime') as string) ?? '09:00')
  const end =
    !parsed.data.allDay && parsed.data.endTime
      ? combineShiftTimes(parsed.data.start, parsed.data.endTime)
      : null
  const id = field(form, 'id')
  const data = {
    title: parsed.data.title,
    start,
    end: end && end > start ? end : null,
    allDay: parsed.data.allDay,
    location: parsed.data.location ?? null,
    notes: parsed.data.notes ?? null,
  }
  if (id) {
    const existing = await db.calendarEvent.findFirst({ where: { id, userId } })
    if (!existing) return { ok: false, error: 'Event not found' }
    await db.calendarEvent.update({ where: { id }, data })
  } else {
    await db.calendarEvent.create({ data: { ...data, userId } })
  }
  revalidatePath('/calendar')
  revalidatePath('/')
  return { ok: true }
}

export async function deleteEventAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const existing = await db.calendarEvent.findFirst({ where: { id, userId } })
  if (!existing) return { ok: false, error: 'Event not found' }
  await db.calendarEvent.delete({ where: { id } })
  revalidatePath('/calendar')
  return { ok: true }
}
