import { requireUser } from '@/lib/auth/session'
import { db } from '@/lib/db/client'
import { PageHeader } from '@/components/shell/page-header'
import { CalendarView } from '@/components/calendar/calendar-view'

export const metadata = { title: 'Calendar' }
export const dynamic = 'force-dynamic'

export default async function CalendarPage() {
  const user = await requireUser()
  const events = await db.calendarEvent.findMany({
    where: { userId: user.id },
    orderBy: { start: 'asc' },
    take: 500,
  })
  return (
    <>
      <PageHeader title="Calendar" subtitle="Day, week and month — integrated with your dashboard" />
      <CalendarView
        events={events.map((e) => ({
          id: e.id,
          title: e.title,
          start: e.start.toISOString(),
          end: e.end?.toISOString() ?? null,
          allDay: e.allDay,
          location: e.location,
        }))}
      />
    </>
  )
}
