'use server'

import { revalidatePath } from 'next/cache'
import { requireUserId, type ActionResult } from '@/lib/actions/guard'
import { deleteNote, saveNote, setNoteFlags } from '@/lib/services/notes'
import { noteSchema } from '@/lib/validation/schemas'

export async function saveNoteAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const tagsRaw = String(form.get('tags') ?? '')
  const parsed = noteSchema.safeParse({
    title: form.get('title'),
    content: form.get('content') ?? '',
    tags: tagsRaw
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean),
    favourite: form.get('favourite') === 'true',
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const id = form.get('id') ? String(form.get('id')) : null
  try {
    await saveNote(userId, id, parsed.data)
  } catch {
    return { ok: false, error: 'Note not found' }
  }
  revalidatePath('/notes')
  revalidatePath('/')
  return { ok: true }
}

export async function toggleNoteFlagAction(id: string, flag: 'favourite' | 'archived', value: boolean): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  try {
    await setNoteFlags(userId, id, { [flag]: value })
  } catch {
    return { ok: false, error: 'Note not found' }
  }
  revalidatePath('/notes')
  return { ok: true }
}

export async function deleteNoteAction(id: string): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  try {
    await deleteNote(userId, id)
  } catch {
    return { ok: false, error: 'Note not found' }
  }
  revalidatePath('/notes')
  return { ok: true }
}
