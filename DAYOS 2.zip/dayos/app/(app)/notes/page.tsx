import { requireUser } from '@/lib/auth/session'
import { listNotes } from '@/lib/services/notes'
import { PageHeader } from '@/components/shell/page-header'
import { NotesView } from '@/components/notes/notes-view'

export const metadata = { title: 'Notes' }
export const dynamic = 'force-dynamic'

export default async function NotesPage() {
  const user = await requireUser()
  const notes = await listNotes(user.id, { archived: false })
  const archived = await listNotes(user.id, { archived: true })

  return (
    <>
      <PageHeader title="Notes" subtitle="Fast capture, tags, favourites and archive" />
      <NotesView
        notes={[...notes, ...archived].map((n) => ({
          id: n.id,
          title: n.title,
          content: n.content,
          favourite: n.favourite,
          archived: n.archived,
          updatedAt: n.updatedAt.toISOString(),
          tags: n.tags.map((t) => t.tag.name),
        }))}
      />
    </>
  )
}
