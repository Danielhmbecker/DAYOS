import { WifiOff } from 'lucide-react'

export const metadata = { title: 'Offline' }

export default function OfflinePage() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center bg-bg px-6 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-elevate">
        <WifiOff className="h-8 w-8 text-accent" />
      </div>
      <h1 className="mt-5 text-xl font-bold text-ink">You're offline</h1>
      <p className="mt-2 max-w-xs text-[14px] text-muted">
        DAYOS cached the app shell, but this page needs a connection. Reconnect and it will sync right
        back.
      </p>
    </div>
  )
}
