import type { Metadata, Viewport } from 'next'
import './globals.css'
import { ToastProvider } from '@/components/ui/toast'
import { SwRegistrar } from '@/components/shell/sw-registrar'
import { OfflineBanner } from '@/components/shell/offline-banner'

export const metadata: Metadata = {
  title: {
    default: 'DAYOS — Your Life. In One Place.',
    template: '%s · DAYOS',
  },
  description:
    'DAYOS is a private, mobile-first personal operating system: money, work, career, tasks, calendar, notes and documents in one place.',
  applicationName: 'DAYOS',
  manifest: '/manifest.webmanifest',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'DAYOS',
  },
  formatDetection: { telephone: false },
  icons: {
    icon: [
      { url: '/icons/dayos-64.png', sizes: '64x64', type: 'image/png' },
      { url: '/icons/dayos-120.png', sizes: '120x120', type: 'image/png' },
      { url: '/icons/dayos-512.png', sizes: '512x512', type: 'image/png' },
    ],
    apple: '/apple-touch-icon.png',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  viewportFit: 'cover',
  themeColor: '#05070D',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-bg font-sans text-ink no-horizontal-scroll">
        <ToastProvider>
          <OfflineBanner />
          {children}
        </ToastProvider>
        <SwRegistrar />
      </body>
    </html>
  )
}
