'use client'

import { useActionState, useState } from 'react'
import { loginAction, setupAction } from '@/lib/actions/auth'
import type { ActionResult } from '@/lib/actions/guard'
import { Button } from '@/components/ui/button'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Segmented } from '@/components/ui/segmented'

export function LoginCard({ setupMode }: { setupMode: boolean }) {
  const [mode, setMode] = useState<'login' | 'setup'>(setupMode ? 'setup' : 'login')
  const [loginState, loginFormAction, loginPending] = useActionState<ActionResult, FormData>(loginAction, {
    ok: true,
  })
  const [setupState, setupFormAction, setupPending] = useActionState<ActionResult, FormData>(setupAction, {
    ok: true,
  })
  const pending = loginPending || setupPending

  return (
    <div className="flex min-h-dvh flex-col items-center justify-center bg-bg px-4 safe-top safe-bottom">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/dayos-180.png" alt="DAYOS logo" className="h-16 w-16 rounded-2xl shadow-glow" />
          <div className="text-center">
            <h1 className="text-3xl font-bold tracking-tight">
              DAY<span className="text-accent">OS</span>
            </h1>
            <p className="mt-1 text-[13px] uppercase tracking-[0.2em] text-muted">Your life. One place.</p>
          </div>
        </div>

        <div className="rounded-card border border-line/70 bg-card p-5 shadow-card">
          {setupMode && (
            <Segmented
              className="mb-5"
              value={mode}
              onChange={setMode}
              options={[
                { value: 'login', label: 'Sign in' },
                { value: 'setup', label: 'Create account' },
              ]}
            />
          )}

          {mode === 'login' ? (
            <form action={loginFormAction} className="space-y-4">
              <div>
                <InputLabel htmlFor="email">Email or username</InputLabel>
                <Input
                  id="email"
                  name="email"
                  type="text"
                  autoCapitalize="none"
                  spellCheck={false}
                  autoComplete="username"
                  placeholder="you@example.com or root"
                  required
                  autoFocus
                />
              </div>
              <div>
                <InputLabel htmlFor="password">Password</InputLabel>
                <Input id="password" name="password" type="password" autoComplete="current-password" placeholder="••••••••••" required />
              </div>
              <FieldError message={loginState.ok ? undefined : loginState.error} />
              <Button type="submit" className="w-full" size="lg" disabled={pending}>
                {loginPending ? 'Signing in…' : 'Sign in'}
              </Button>
            </form>
          ) : (
            <form action={setupFormAction} className="space-y-4">
              <p className="text-[13px] text-muted">
                First run: create the owner account for this DAYOS instance.
              </p>
              <div>
                <InputLabel htmlFor="name">Your name</InputLabel>
                <Input id="name" name="name" autoComplete="name" placeholder="Dan" required autoFocus />
              </div>
              <div>
                <InputLabel htmlFor="email">Email</InputLabel>
                <Input id="email" name="email" type="email" autoComplete="email" placeholder="you@example.com" required />
              </div>
              <div>
                <InputLabel htmlFor="password">Password</InputLabel>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="new-password"
                  placeholder="Min. 10 chars, upper, lower, number"
                  required
                />
              </div>
              <FieldError message={setupState.ok ? undefined : setupState.error} />
              <Button type="submit" className="w-full" size="lg" disabled={pending}>
                {setupPending ? 'Creating…' : 'Create account'}
              </Button>
            </form>
          )}
        </div>

        <p className="mt-6 text-center text-[12px] text-faint">
          Private by design — your data lives on your server.
        </p>
      </div>
    </div>
  )
}
