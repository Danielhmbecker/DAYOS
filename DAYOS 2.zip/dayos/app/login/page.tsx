import { redirect } from 'next/navigation'
import { getCurrentSession } from '@/lib/auth/session'
import { canSetup } from '@/lib/services/auth'
import { LoginCard } from './login-card'

export const metadata = { title: 'Sign in' }
export const dynamic = 'force-dynamic'

export default async function LoginPage() {
  const session = await getCurrentSession()
  if (session) redirect('/')
  const setup = await canSetup()
  return <LoginCard setupMode={setup} />
}
