/* DAYOS service worker — offline app shell.
 * Strategy:
 *  - precache the shell (navigate fallback, login, manifest, icons)
 *  - navigations: network-first, fall back to cached shell, then /offline
 *  - same-origin GET assets: stale-while-revalidate
 *  - document data requests are never cached (privacy: always fresh when online)
 */
const VERSION = 'dayos-v1'
const SHELL = [
  '/offline',
  '/login',
  '/manifest.webmanifest',
  '/icons/dayos-64.png',
  '/icons/dayos-120.png',
  '/icons/dayos-180.png',
  '/icons/dayos-512.png',
  '/icons/dayos-1024.png',
  '/apple-touch-icon.png',
]

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(VERSION)
      .then((cache) => cache.addAll(SHELL))
      .then(() => self.skipWaiting()),
  )
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  )
})

self.addEventListener('fetch', (event) => {
  const req = event.request
  if (req.method !== 'GET') return
  const url = new URL(req.url)
  if (url.origin !== self.location.origin) return

  // HTML navigations: network-first with offline fallback.
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone()
          caches.open(VERSION).then((cache) => cache.put('/offline-nav', copy))
          return res
        })
        .catch(async () => {
          const cached = await caches.match(req)
          if (cached) return cached
          const lastNav = await caches.match('/offline-nav')
          if (lastNav && url.pathname !== '/login') return lastNav
          return caches.match('/offline')
        }),
    )
    return
  }

  // Static assets: stale-while-revalidate.
  if (url.pathname.startsWith('/_next/static/') || url.pathname.startsWith('/icons/') || url.pathname.endsWith('.png') || url.pathname.endsWith('.svg') || url.pathname.endsWith('.webmanifest')) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const fetched = fetch(req)
          .then((res) => {
            const copy = res.clone()
            caches.open(VERSION).then((cache) => cache.put(req, copy))
            return res
          })
          .catch(() => cached)
        return cached || fetched
      }),
    )
  }
})
