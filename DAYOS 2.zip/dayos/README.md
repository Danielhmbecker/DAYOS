# DAYOS — Your Life. In One Place.

A private, mobile-first **personal operating system** you host yourself:
money, work, career, tasks, calendar, notes, documents and stockroom in one
dark, fast, installable PWA — designed for an iPhone Home Screen first,
desktop second.

> **DOWNLOAD ZIP → EXTRACT → CONFIGURE ENV → DEPLOY TO OPENSHIFT → OPEN HTTPS URL → ADD TO HOME SCREEN → USE DAILY**

---

## 1. What DAYOS is

DAYOS is a self-hosted web application (Next.js + PostgreSQL) that replaces
the scatter of banking apps, shift rotas, job trackers, note apps and file
folders with one private system. It is single-owner by design: one account,
your data, your infrastructure.

## 2. Features

- **Dashboard** — balance, savings, today's shift, next event, tasks, career
  goal, bills due, quick actions; optional weather; cards hideable in Settings
- **Money** — transactions, income/expenses, budgets, bills (pay-now logs and
  reschedules), savings goals, recurring transactions, 6-month charts, search
- **Work** — shifts with automatic hours/overtime/estimated pay (midnight
  crossing supported), month summary, work tasks, locations
- **Career** — visual roadmap, applications with statuses & interviews,
  courses, certificates, skills
- **Notes** — tags, favourites, archive, search
- **Vault** — document storage with folders, tags, validated uploads,
  authenticated downloads
- **Tasks & Calendar** — unified tasks; month/week/day calendar
- **Stockroom** — stock items with thresholds and count history, cleaning
  schedules with due/overdue states (generic — any domain, not just bars)
- **PWA** — installable to the iPhone Home Screen, offline shell, standalone
- Future modules (BetLab, Turbo, AI assistant, habits…) are documented in
  `docs/MODULES.md` and clearly marked "Soon" in the app.

## 3. Requirements

- Node.js ≥ 20.9
- PostgreSQL 14+ (or the bundled embedded demo Postgres — zero install)
- Docker (only for container builds) / an OpenShift 4.x cluster for production
- ~512 MB RAM for the app container

## 4. Local setup (fastest path)

```bash
unzip DAYOS.zip && cd dayos
npm install
cp .env.example .env          # edit AUTH_SECRET at minimum

# Terminal 1 — embedded zero-install Postgres (migrations + demo seed):
DEMO_SEED=1 npm run db:demo

# Terminal 2 — the app:
npm run dev                   # http://localhost:3000
```

First boot with an **empty** database shows the owner-setup screen. The seeded
demo login is `dan@dayos.app` / `DemoPass123!` (change or delete it in
Settings, or skip seeding with `npm run db:demo`). Sign-in also accepts a bare
username as shorthand for `<name>@dayos.local` — e.g. a local account created
as `root@dayos.local` can sign in with just `root`.

### Local setup with real PostgreSQL (docker-compose)

```bash
docker compose up -d db
cp .env.example .env   # DATABASE_URL="postgresql://dayos:dayos@localhost:5432/dayos?schema=public"
npx prisma migrate deploy
npm run db:seed        # optional demo data
npm run dev
```

## 5. Environment variables

See `.env.example` — every variable is documented there. The essentials:

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection (or embedded demo via `npm run db:demo`) |
| `AUTH_SECRET` | Session signing secret — `openssl rand -base64 32` |
| `AUTH_SESSION_DAYS` | Sliding session lifetime (default 30) |
| `DATA_DIR` | Document storage root (PVC mount in production) |
| `STORAGE_DRIVER` | `local` today; S3 driver is a documented future addition |
| `NEXT_PUBLIC_APP_URL` | Public HTTPS URL (manifest/metadata) |

## 6. Database setup

PostgreSQL 14+ with a dedicated role/database:

```sql
CREATE ROLE dayos LOGIN PASSWORD '…';
CREATE DATABASE dayos OWNER dayos;
```

Set `DATABASE_URL` accordingly (`?schema=public`). The embedded demo mode
(`npm run db:demo`) runs real Postgres (PGlite, WASM) over the wire protocol
for zero-infrastructure trials and CI; it expects one client process at a time
— use real PostgreSQL for anything concurrent.

## 7. Prisma migrations

```bash
npx prisma migrate deploy     # apply committed migrations (prod/CI)
npx prisma migrate dev        # create a new migration while developing
npx prisma generate           # regenerate the client (build does this too)
```

Migrations live in `prisma/migrations/`. Never edit applied migrations.

## 8. Seed data

```bash
npm run db:seed
```

Creates `dan@dayos.app` / `DemoPass123!` plus six months of representative
data for every module. Idempotent: re-running skips when the owner exists.

## 9. Running locally

```bash
npm run dev         # development with hot reload
npm run build       # production build (runs prisma generate first)
npm run start       # serve the production build
```

Health check: `curl localhost:3000/api/health` → `{"status":"ok"}`
(add `?deep=1` to include database status).

## 10. Running tests

```bash
npm test            # 42 unit + integration tests (in-memory PGlite, no setup)
npm run test:e2e    # Playwright E2E (needs a built+running app & seeded DB)
```

E2E prerequisites: `npx playwright install chromium` (add `--with-deps` on
Linux), app running on :3000 (`reuseExistingServer` handles it), then:

```bash
npm run build && npm run start &
npm run test:e2e    # 4 profiles: 375×812, 390×844, 430×932, desktop
```

Also available: `npm run lint` (zero warnings), `npm run typecheck`,
`npm run format:check`.

## 11. Building production

```bash
npm run build
```

Outputs a standalone server (`.next/standalone`) used by the Docker image.
All pages are dynamic, so the build never needs a live database.

## 12. Building the Docker image

```bash
docker build -t dayos:latest .
docker run --rm -p 3000:3000 \
  -e DATABASE_URL="postgresql://…" \
  -e AUTH_SECRET="…" \
  -v dayos-data:/data dayos:latest
```

The image runs as UID 1001 (non-root), exposes port 3000 and includes a
HEALTHCHECK against `/api/health`. Run migrations before serving:
`docker run … dayos:latest node node_modules/prisma/build/index.js migrate deploy`
(docker-compose does this automatically).

## 13. OpenShift deployment

Full runbook with exact commands in **`openshift/README.md`**:

```bash
oc login … && oc project YOUR_PROJECT
oc apply -f openshift/postgres/…        # in-cluster Postgres (or use managed)
oc apply -f openshift/secret.yaml       # from secret.example.yaml
oc apply -f openshift/configmap.yaml openshift/pvc.yaml
oc new-build / start-build or docker push   # image
oc apply -f openshift/service.yaml openshift/deployment.yaml
oc apply -f openshift/migrate-job.yaml  # prisma migrate deploy as a Job
oc apply -f openshift/route.yaml        # HTTPS edge-terminated route
curl -f https://$(oc get route dayos -o jsonpath='{.spec.host}')/api/health
```

Deployment probes: startup/readiness/liveness all hit `/api/health`.

## 14. PostgreSQL configuration (production)

- Use the in-cluster deployment (`openshift/postgres/`) or a managed instance
- Connection pooler optional (single replica app; Prisma pools internally)
- Backups: `pg_dump` CronJob or volume snapshots — see openshift/README.md §Backups
- TLS to the database: add `sslmode=require` to `DATABASE_URL` if enforced

## 15. HTTPS configuration

- OpenShift route terminates TLS (edge) and redirects HTTP→HTTPS
- The app sets HSTS + secure cookies automatically in production
- Local dev over plain HTTP is supported (loopback is treated as trustworthy
  by browsers for secure cookies)

## 16. PWA installation

- Manifest with standalone display, theme/background colours, maskable icons
- Service worker precaches the shell; navigations fall back to cache/offline
- Offline banner tells you when you're on cached content

## 17. iPhone setup

1. Deploy and open the HTTPS route in **Safari**
2. Accept/trust the certificate if your cluster uses an internal CA
   (Settings → General → VPN & Device Management)
3. Share → **Add to Home Screen** → "DAYOS"
4. Launch from the Home Screen: standalone, dark, safe-area aware, with the
   bottom tab bar — no browser chrome

## 18. Backup strategy

- **Database**: nightly `pg_dump` (CronJob) or PVC snapshots; test restores
- **Documents**: the `dayos-data` PVC (`/data/documents`) — snapshot or
  `oc rsync` off-cluster
- **Secrets**: keep `secret.yaml` in your password manager, never in git
- **Config**: `.env` / ConfigMap values are reconstructable from `.env.example`

## 19. Updating the application

```bash
git pull && npm install
npx prisma migrate deploy     # schema changes ship as migrations
npm run build && npm run start
# OpenShift: rebuild/push image → rollout → re-apply migrate-job.yaml
```

Migrations are idempotent; the app refuses nothing but logs applied versions
in `_prisma_migrations`.

## 20. Troubleshooting

| Symptom | Fix |
| --- | --- |
| `AUTH_SECRET is not set` | copy `.env.example` → `.env` and fill it |
| Prisma "environment variable not found" | Prisma CLI skips `.env` when `prisma.config.ts` exists — the config loads it; ensure `.env` is in the project root |
| Embedded demo: "prepared statement already exists" | demo mode allows one client at a time; restart `npm run db:demo`, or use real Postgres for concurrent CLI+app |
| Login loop after deploy | route not HTTPS → secure cookies dropped; fix TLS or test on loopback |
| Uploads 410 | file missing from PVC — restore backup or re-upload; metadata row can be deleted |
| PWA won't install | manifest requires HTTPS + served icons; check `/manifest.webmanifest` returns 200 |
| Health 503 `database: down` | check `DATABASE_URL`, postgres pod/PVC, migration job logs |

---

**Docs**: `docs/BUILD_PROGRESS.md` (stage record) · `docs/SECURITY.md` ·
`docs/MODULES.md` (extending + future modules) · `docs/AI_ASSISTANT.md` ·
`openshift/README.md` (deployment runbook)

Productive today. A better tomorrow.
