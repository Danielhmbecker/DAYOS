'use client'

import { useState, useActionState, useEffect, useRef } from 'react'
import { ListTodo, Pencil, Plus, Trash2 } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { Segmented } from '@/components/ui/segmented'
import { Textarea } from '@/components/ui/textarea'
import { useToast } from '@/components/ui/toast'
import { deleteTaskAction, saveTaskAction, setTaskStatusAction } from '@/app/(app)/tasks/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatDate, relativeDays } from '@/lib/utils'

export type TaskRow = {
  id: string
  title: string
  description: string | null
  dueDate: string | null
  priority: 'LOW' | 'MEDIUM' | 'HIGH'
  status: 'TODO' | 'IN_PROGRESS' | 'DONE'
  category: string | null
}

const PRIORITY_TONE = { LOW: 'neutral', MEDIUM: 'accent', HIGH: 'danger' } as const

export function TasksView({ tasks }: { tasks: TaskRow[] }) {
  const [filter, setFilter] = useState<'OPEN' | 'DONE' | 'ALL'>('OPEN')
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<TaskRow | null>(null)
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const { push } = useToast()

  const filtered = tasks
    .filter((t) => (filter === 'ALL' ? true : filter === 'DONE' ? t.status === 'DONE' : t.status !== 'DONE'))
    .sort((a, b) => {
      if (a.status === 'DONE' && b.status !== 'DONE') return 1
      if (b.status === 'DONE' && a.status !== 'DONE') return -1
      return (a.dueDate ?? '9999').localeCompare(b.dueDate ?? '9999')
    })

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Segmented
          className="flex-1"
          value={filter}
          onChange={setFilter}
          options={[
            { value: 'OPEN', label: 'Open' },
            { value: 'DONE', label: 'Done' },
            { value: 'ALL', label: 'All' },
          ]}
        />
        <Button onClick={() => { setEditing(null); setOpen(true) }}>
          <Plus className="h-4 w-4" /> New
        </Button>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={ListTodo}
          title={filter === 'DONE' ? 'Nothing completed yet' : 'All clear'}
          description="Tasks from quick capture land here too."
          action={<Button onClick={() => { setEditing(null); setOpen(true) }}>Add a task</Button>}
        />
      ) : (
        <Card>
          <CardContent className="pt-2">
            <ul className="divide-y divide-line/50">
              {filtered.map((t) => (
                <li key={t.id} className="flex items-start gap-3 py-3">
                  <button
                    aria-label={`Mark ${t.title} ${t.status === 'DONE' ? 'open' : 'done'}`}
                    onClick={async () => {
                      const res = await setTaskStatusAction(t.id, t.status === 'DONE' ? 'TODO' : 'DONE')
                      if (!res.ok) push(res.error, 'error')
                    }}
                    className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md border transition-colors ${
                      t.status === 'DONE' ? 'border-success bg-success text-black' : 'border-line bg-surface hover:border-accent'
                    }`}
                  >
                    {t.status === 'DONE' && <svg viewBox="0 0 12 12" className="h-3.5 w-3.5"><path d="M2 6l3 3 5-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>}
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className={`truncate text-[14px] font-medium ${t.status === 'DONE' ? 'text-faint line-through' : 'text-ink'}`}>
                      {t.title}
                    </p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-2 text-[12px] text-muted">
                      {t.dueDate && (
                        <span className={new Date(t.dueDate) < new Date() && t.status !== 'DONE' ? 'text-danger' : ''}>
                          {relativeDays(t.dueDate)} · {formatDate(t.dueDate, 'short')}
                        </span>
                      )}
                      {t.category && <span>· {t.category}</span>}
                      {t.status === 'IN_PROGRESS' && <Badge tone="violet">in progress</Badge>}
                    </p>
                  </div>
                  <Badge tone={PRIORITY_TONE[t.priority]}>{t.priority.toLowerCase()}</Badge>
                  <button aria-label="Edit task" onClick={() => { setEditing(t); setOpen(true) }} className="p-1.5 text-faint hover:text-ink">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button aria-label="Delete task" onClick={() => setConfirmId(t.id)} className="p-1.5 text-faint hover:text-danger">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {open && <TaskDialog key={editing?.id ?? 'new'} initial={editing} onClose={() => setOpen(false)} />}

      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteTaskAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Task deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete task"
        message="This permanently deletes the task."
      />
    </div>
  )
}

function TaskDialog({ initial, onClose }: { initial: TaskRow | null; onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveTaskAction, { ok: true })
  const submitted = useRef(false)
  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push(initial ? 'Task updated' : 'Task added')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose, initial])

  return (
    <Dialog open onClose={onClose} title={initial ? 'Edit task' : 'New task'}>
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        {initial && <input type="hidden" name="id" value={initial.id} />}
        <div>
          <InputLabel htmlFor="t-title">Title</InputLabel>
          <Input id="t-title" name="title" defaultValue={initial?.title} required autoFocus />
        </div>
        <div>
          <InputLabel htmlFor="t-desc">Description</InputLabel>
          <Textarea id="t-desc" name="description" rows={3} defaultValue={initial?.description ?? ''} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="t-due">Due</InputLabel>
            <Input id="t-due" name="dueDate" type="date" defaultValue={initial?.dueDate?.slice(0, 10) ?? ''} />
          </div>
          <div>
            <InputLabel htmlFor="t-cat">Category</InputLabel>
            <Input id="t-cat" name="category" defaultValue={initial?.category ?? ''} placeholder="Home, Work…" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="t-priority">Priority</InputLabel>
            <Select id="t-priority" name="priority" defaultValue={initial?.priority ?? 'MEDIUM'}>
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
            </Select>
          </div>
          <div>
            <InputLabel htmlFor="t-status">Status</InputLabel>
            <Select id="t-status" name="status" defaultValue={initial?.status ?? 'TODO'}>
              <option value="TODO">To do</option>
              <option value="IN_PROGRESS">In progress</option>
              <option value="DONE">Done</option>
            </Select>
          </div>
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          {initial ? 'Save changes' : 'Add task'}
        </Button>
      </form>
    </Dialog>
  )
}
