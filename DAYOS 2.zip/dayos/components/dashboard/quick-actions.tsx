'use client'

import { useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import { ArrowUpRight, ArrowDownLeft, ListTodo, StickyNote, CalendarPlus } from 'lucide-react'

const actions = [
  { mode: 'expense', label: 'Expense', icon: ArrowUpRight },
  { mode: 'income', label: 'Income', icon: ArrowDownLeft },
  { mode: 'task', label: 'Task', icon: ListTodo },
  { mode: 'note', label: 'Note', icon: StickyNote },
  { mode: 'event', label: 'Event', icon: CalendarPlus },
]

/** Dashboard quick actions — open the global Quick Capture sheet in the right mode. */
export function QuickActions() {
  const params = useSearchParams()

  useEffect(() => {
    const capture = params.get('capture')
    if (capture) {
      window.dispatchEvent(new CustomEvent('dayos:quick-capture', { detail: capture }))
    }
  }, [params])

  return (
    <div className="grid grid-cols-5 gap-2">
      {actions.map((a) => (
        <button
          key={a.mode}
          onClick={() => window.dispatchEvent(new CustomEvent('dayos:quick-capture', { detail: a.mode }))}
          className="flex min-h-[64px] flex-col items-center justify-center gap-1.5 rounded-tile border border-line/60 bg-surface text-muted transition-colors hover:border-accent/40 hover:text-ink active:scale-[0.97]"
        >
          <a.icon className="h-[18px] w-[18px]" />
          <span className="text-[11px] font-medium">{a.label}</span>
        </button>
      ))}
    </div>
  )
}
