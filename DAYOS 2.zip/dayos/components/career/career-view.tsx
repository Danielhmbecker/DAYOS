'use client'

import { useState, useActionState, useEffect, useRef } from 'react'
import {
  ArrowDown,
  Award,
  BookOpen,
  Building2,
  ChevronDown,
  ChevronUp,
  GraduationCap,
  Pencil,
  Plus,
  Sparkles,
  Trash2,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { useToast } from '@/components/ui/toast'
import {
  deleteApplicationAction,
  deleteCertificateAction,
  deleteCourseAction,
  deleteSkillAction,
  deleteStageAction,
  moveStageAction,
  saveApplicationAction,
  saveCertificateAction,
  saveCourseAction,
  saveSkillAction,
  saveStageAction,
  setApplicationStatusAction,
  setCurrentStageAction,
} from '@/app/(app)/career/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatDate } from '@/lib/utils'

export type StageRow = { id: string; title: string; subtitle: string | null; order: number; isCurrent: boolean }
export type ApplicationRow = {
  id: string
  company: string
  role: string
  salary: string | null
  location: string | null
  workMode: string
  status: string
  appliedDate: string | null
  interviewDate: string | null
  cvVersion: string | null
  notes: string | null
}
export type CourseRow = { id: string; title: string; provider: string | null; status: string }
export type CertificateRow = { id: string; title: string; issuer: string | null; issuedAt: string | null; expiresAt: string | null }
export type SkillRow = { id: string; name: string; level: number }

const STATUS_TONE: Record<string, 'neutral' | 'accent' | 'success' | 'warning' | 'danger' | 'violet'> = {
  SAVED: 'neutral',
  APPLIED: 'accent',
  INTERVIEW: 'violet',
  OFFER: 'success',
  REJECTED: 'danger',
  CLOSED: 'neutral',
}

export function CareerView({
  stages,
  applications,
  courses,
  certificates,
  skills,
}: {
  stages: StageRow[]
  applications: ApplicationRow[]
  courses: CourseRow[]
  certificates: CertificateRow[]
  skills: SkillRow[]
}) {
  return (
    <div className="space-y-6">
      <Roadmap stages={stages} />
      <Applications applications={applications} />
      <Learning courses={courses} certificates={certificates} skills={skills} />
    </div>
  )
}

function Roadmap({ stages }: { stages: StageRow[] }) {
  const [open, setOpen] = useState(false)
  const { push } = useToast()
  const [confirmId, setConfirmId] = useState<string | null>(null)

  return (
    <section aria-label="Career path">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Your path</p>
        <Button size="sm" variant="secondary" onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" /> Stage
        </Button>
      </div>
      {stages.length === 0 ? (
        <EmptyState
          icon={Sparkles}
          title="Map your career"
          description="Current role → target → future → long-term goal. Add the first stage to start the roadmap."
          action={<Button onClick={() => setOpen(true)}>Add stage</Button>}
        />
      ) : (
        <ol className="relative space-y-3 pl-6 before:absolute before:bottom-4 before:left-[9px] before:top-4 before:w-px before:bg-line">
          {stages.map((s, i) => (
            <li key={s.id} className="relative">
              <span
                className={`absolute -left-6 top-4 h-[18px] w-[18px] rounded-full border-2 ${
                  s.isCurrent ? 'border-accent bg-accent/30 shadow-glow' : 'border-line bg-surface'
                }`}
              />
              <Card className={s.isCurrent ? 'border-accent/40' : undefined}>
                <CardContent className="flex items-center gap-3 py-3.5">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[15px] font-semibold text-ink">{s.title}</p>
                    <p className="truncate text-[12px] text-muted">
                      {s.isCurrent ? 'Current role' : s.subtitle || `Stage ${i + 1}`}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center">
                    <button aria-label="Move up" disabled={i === 0} onClick={async () => moveStageAction(s.id, -1)} className="p-1.5 text-faint hover:text-ink disabled:opacity-30">
                      <ChevronUp className="h-4 w-4" />
                    </button>
                    <button aria-label="Move down" disabled={i === stages.length - 1} onClick={async () => moveStageAction(s.id, 1)} className="p-1.5 text-faint hover:text-ink disabled:opacity-30">
                      <ChevronDown className="h-4 w-4" />
                    </button>
                    {!s.isCurrent && (
                      <button
                        onClick={async () => {
                          const res = await setCurrentStageAction(s.id)
                          push(res.ok ? 'Current role updated' : res.error, res.ok ? 'success' : 'error')
                        }}
                        className="ml-1 rounded-lg px-2 py-1 text-[12px] font-medium text-accent hover:bg-accent/10"
                      >
                        Make current
                      </button>
                    )}
                    <button aria-label="Delete stage" onClick={() => setConfirmId(s.id)} className="p-1.5 text-faint hover:text-danger">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </CardContent>
              </Card>
              {i < stages.length - 1 && <ArrowDown className="mx-auto my-1 h-3.5 w-3.5 text-faint" />}
            </li>
          ))}
        </ol>
      )}
      {open && <StageDialog onClose={() => setOpen(false)} />}
      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteStageAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Stage deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete stage"
        message="This removes the stage from your roadmap."
      />
    </section>
  )
}

function StageDialog({ onClose }: { onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveStageAction, { ok: true })
  const submitted = useRef(false)
  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push('Stage added')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose])
  return (
    <Dialog open onClose={onClose} title="New career stage">
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        <div>
          <InputLabel htmlFor="st-title">Role title</InputLabel>
          <Input id="st-title" name="title" placeholder="Assistant Manager" required autoFocus />
        </div>
        <div>
          <InputLabel htmlFor="st-sub">Subtitle (optional)</InputLabel>
          <Input id="st-sub" name="subtitle" placeholder="Target · next 12 months" />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          Add stage
        </Button>
      </form>
    </Dialog>
  )
}

function Applications({ applications }: { applications: ApplicationRow[] }) {
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<ApplicationRow | null>(null)
  const [filter, setFilter] = useState('ALL')
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const { push } = useToast()
  const filtered = applications.filter((a) => filter === 'ALL' || a.status === filter)

  return (
    <section aria-label="Job applications">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Applications</p>
        <Button size="sm" onClick={() => { setEditing(null); setOpen(true) }}>
          <Plus className="h-4 w-4" /> Add
        </Button>
      </div>
      <Select aria-label="Filter by status" value={filter} onChange={(e) => setFilter(e.target.value)} className="mb-3">
        <option value="ALL">All statuses</option>
        {['SAVED', 'APPLIED', 'INTERVIEW', 'OFFER', 'REJECTED', 'CLOSED'].map((s) => (
          <option key={s} value={s}>
            {s.charAt(0) + s.slice(1).toLowerCase()}
          </option>
        ))}
      </Select>
      {filtered.length === 0 ? (
        <EmptyState icon={Building2} title="No applications" description="Track every application from saved to offer." />
      ) : (
        <div className="space-y-2">
          {filtered.map((a) => (
            <Card key={a.id}>
              <CardContent className="py-3.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-[15px] font-semibold text-ink">
                      {a.role} <span className="text-muted">· {a.company}</span>
                    </p>
                    <p className="mt-0.5 truncate text-[12px] text-muted">
                      {a.workMode.toLowerCase()}
                      {a.location ? ` · ${a.location}` : ''}
                      {a.salary ? ` · ${a.salary}` : ''}
                      {a.interviewDate ? ` · interview ${formatDate(a.interviewDate, 'short')}` : ''}
                    </p>
                  </div>
                  <Badge tone={STATUS_TONE[a.status] ?? 'neutral'}>{a.status.toLowerCase()}</Badge>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <Select
                    aria-label={`Status for ${a.role} at ${a.company}`}
                    defaultValue={a.status}
                    className="h-9 flex-1 text-[13px]"
                    onChange={async (e) => {
                      const res = await setApplicationStatusAction(a.id, e.target.value)
                      if (!res.ok) push(res.error, 'error')
                    }}
                  >
                    {['SAVED', 'APPLIED', 'INTERVIEW', 'OFFER', 'REJECTED', 'CLOSED'].map((s) => (
                      <option key={s} value={s}>
                        {s.charAt(0) + s.slice(1).toLowerCase()}
                      </option>
                    ))}
                  </Select>
                  <Button size="sm" variant="ghost" aria-label="Edit application" onClick={() => { setEditing(a); setOpen(true) }}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="ghost" aria-label="Delete application" onClick={() => setConfirmId(a.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      {open && <ApplicationDialog key={editing?.id ?? 'new'} initial={editing} onClose={() => setOpen(false)} />}
      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteApplicationAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Application deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete application"
        message="This permanently removes the application."
      />
    </section>
  )
}

function ApplicationDialog({ initial, onClose }: { initial: ApplicationRow | null; onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveApplicationAction, { ok: true })
  const submitted = useRef(false)
  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push(initial ? 'Application updated' : 'Application added')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose, initial])
  return (
    <Dialog open onClose={onClose} title={initial ? 'Edit application' : 'New application'} wide>
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        {initial && <input type="hidden" name="id" value={initial.id} />}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="a-company">Company</InputLabel>
            <Input id="a-company" name="company" defaultValue={initial?.company} required />
          </div>
          <div>
            <InputLabel htmlFor="a-role">Role</InputLabel>
            <Input id="a-role" name="role" defaultValue={initial?.role} required />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="a-salary">Salary</InputLabel>
            <Input id="a-salary" name="salary" defaultValue={initial?.salary ?? ''} placeholder="£38k" />
          </div>
          <div>
            <InputLabel htmlFor="a-location">Location</InputLabel>
            <Input id="a-location" name="location" defaultValue={initial?.location ?? ''} placeholder="London" />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <InputLabel htmlFor="a-mode">Mode</InputLabel>
            <Select id="a-mode" name="workMode" defaultValue={initial?.workMode ?? 'ONSITE'}>
              <option value="ONSITE">On-site</option>
              <option value="HYBRID">Hybrid</option>
              <option value="REMOTE">Remote</option>
            </Select>
          </div>
          <div>
            <InputLabel htmlFor="a-status">Status</InputLabel>
            <Select id="a-status" name="status" defaultValue={initial?.status ?? 'SAVED'}>
              {['SAVED', 'APPLIED', 'INTERVIEW', 'OFFER', 'REJECTED', 'CLOSED'].map((s) => (
                <option key={s} value={s}>
                  {s.charAt(0) + s.slice(1).toLowerCase()}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <InputLabel htmlFor="a-cv">CV version</InputLabel>
            <Input id="a-cv" name="cvVersion" defaultValue={initial?.cvVersion ?? ''} placeholder="v4" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="a-applied">Applied on</InputLabel>
            <Input id="a-applied" name="appliedDate" type="date" defaultValue={initial?.appliedDate?.slice(0, 10) ?? ''} />
          </div>
          <div>
            <InputLabel htmlFor="a-interview">Interview</InputLabel>
            <Input id="a-interview" name="interviewDate" type="date" defaultValue={initial?.interviewDate?.slice(0, 10) ?? ''} />
          </div>
        </div>
        <div>
          <InputLabel htmlFor="a-notes">Notes</InputLabel>
          <Textarea id="a-notes" name="notes" defaultValue={initial?.notes ?? ''} rows={3} placeholder="Contacts, next steps, feedback…" />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          {initial ? 'Save changes' : 'Add application'}
        </Button>
      </form>
    </Dialog>
  )
}

function Learning({
  courses,
  certificates,
  skills,
}: {
  courses: CourseRow[]
  certificates: CertificateRow[]
  skills: SkillRow[]
}) {
  const [dialog, setDialog] = useState<null | 'course' | 'certificate' | 'skill'>(null)
  const { push } = useToast()

  return (
    <section aria-label="Learning and skills">
      <p className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-muted">Learning & skills</p>
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <BookOpen className="h-4 w-4 text-accent" />
              <Button size="sm" variant="ghost" aria-label="Add course" onClick={() => setDialog('course')}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <p className="mt-2 text-[13px] font-semibold uppercase tracking-wider text-muted">Courses</p>
            <ul className="mt-2 space-y-2">
              {courses.length === 0 && <li className="text-[13px] text-faint">Nothing yet.</li>}
              {courses.map((c) => (
                <li key={c.id} className="flex items-center justify-between gap-2">
                  <span className="min-w-0 flex-1 truncate text-[14px] text-ink">{c.title}</span>
                  <Badge tone={c.status === 'COMPLETED' ? 'success' : c.status === 'IN_PROGRESS' ? 'accent' : 'neutral'}>
                    {c.status.replaceAll('_', ' ').toLowerCase()}
                  </Badge>
                  <button aria-label={`Delete ${c.title}`} onClick={async () => push((await deleteCourseAction(c.id)).ok ? 'Deleted' : 'Failed', 'success')} className="p-1 text-faint hover:text-danger">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <Award className="h-4 w-4 text-amber" />
              <Button size="sm" variant="ghost" aria-label="Add certificate" onClick={() => setDialog('certificate')}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <p className="mt-2 text-[13px] font-semibold uppercase tracking-wider text-muted">Certificates</p>
            <ul className="mt-2 space-y-2">
              {certificates.length === 0 && <li className="text-[13px] text-faint">Nothing yet.</li>}
              {certificates.map((c) => (
                <li key={c.id} className="flex items-center justify-between gap-2">
                  <span className="min-w-0 flex-1 truncate text-[14px] text-ink">{c.title}</span>
                  <button aria-label={`Delete ${c.title}`} onClick={async () => push((await deleteCertificateAction(c.id)).ok ? 'Deleted' : 'Failed', 'success')} className="p-1 text-faint hover:text-danger">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <GraduationCap className="h-4 w-4 text-mint" />
              <Button size="sm" variant="ghost" aria-label="Add skill" onClick={() => setDialog('skill')}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <p className="mt-2 text-[13px] font-semibold uppercase tracking-wider text-muted">Skills</p>
            <ul className="mt-2 space-y-2">
              {skills.length === 0 && <li className="text-[13px] text-faint">Nothing yet.</li>}
              {skills.map((s) => (
                <li key={s.id} className="flex items-center justify-between gap-2">
                  <span className="min-w-0 flex-1 truncate text-[14px] text-ink">{s.name}</span>
                  <span className="text-[11px] text-muted">{'●'.repeat(s.level)}{'○'.repeat(5 - s.level)}</span>
                  <button aria-label={`Delete ${s.name}`} onClick={async () => push((await deleteSkillAction(s.id)).ok ? 'Deleted' : 'Failed', 'success')} className="p-1 text-faint hover:text-danger">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
      {dialog === 'course' && <SimpleFormDialog kind="course" onClose={() => setDialog(null)} />}
      {dialog === 'certificate' && <SimpleFormDialog kind="certificate" onClose={() => setDialog(null)} />}
      {dialog === 'skill' && <SimpleFormDialog kind="skill" onClose={() => setDialog(null)} />}
    </section>
  )
}

function SimpleFormDialog({ kind, onClose }: { kind: 'course' | 'certificate' | 'skill'; onClose: () => void }) {
  const { push } = useToast()
  const action = kind === 'course' ? saveCourseAction : kind === 'certificate' ? saveCertificateAction : saveSkillAction
  const [state, formAction, saving] = useActionState<ActionResult, FormData>(action, { ok: true })
  const submitted = useRef(false)
  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push('Saved')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose])

  const titles = { course: 'New course', certificate: 'New certificate', skill: 'New skill' } as const

  return (
    <Dialog open onClose={onClose} title={titles[kind]}>
      <form
        action={(fd) => {
          submitted.current = true
          formAction(fd)
        }}
        className="space-y-4"
      >
        <div>
          <InputLabel htmlFor="sf-title">Title</InputLabel>
          <Input id="sf-title" name={kind === 'skill' ? 'name' : 'title'} required autoFocus />
        </div>
        {kind === 'course' && (
          <>
            <div>
              <InputLabel htmlFor="sf-provider">Provider</InputLabel>
              <Input id="sf-provider" name="provider" placeholder="Coursera, internal training…" />
            </div>
            <div>
              <InputLabel htmlFor="sf-status">Status</InputLabel>
              <Select id="sf-status" name="status" defaultValue="PLANNED">
                <option value="PLANNED">Planned</option>
                <option value="IN_PROGRESS">In progress</option>
                <option value="COMPLETED">Completed</option>
              </Select>
            </div>
          </>
        )}
        {kind === 'certificate' && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <InputLabel htmlFor="sf-issuer">Issuer</InputLabel>
              <Input id="sf-issuer" name="issuer" />
            </div>
            <div>
              <InputLabel htmlFor="sf-issued">Issued</InputLabel>
              <Input id="sf-issued" name="issuedAt" type="date" />
            </div>
          </div>
        )}
        {kind === 'skill' && (
          <div>
            <InputLabel htmlFor="sf-level">Level (1–5)</InputLabel>
            <Select id="sf-level" name="level" defaultValue="3">
              {[1, 2, 3, 4, 5].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </Select>
          </div>
        )}
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          Save
        </Button>
      </form>
    </Dialog>
  )
}
