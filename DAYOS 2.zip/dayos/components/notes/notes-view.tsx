'use client'

import { useMemo, useState, useActionState, useEffect, useRef } from 'react'
import { Archive, ArchiveRestore, Pencil, Plus, Star, StickyNote, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { useToast } from '@/components/ui/toast'
import { deleteNoteAction, saveNoteAction, toggleNoteFlagAction } from '@/app/(app)/notes/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatDate } from '@/lib/utils'

export type NoteRow = {
  id: string
  title: string
  content: string
  favourite: boolean
  archived: boolean
  updatedAt: string
  tags: string[]
}

export function NotesView({ notes: initialNotes }: { notes: NoteRow[] }) {
  const [notes, setNotes] = useState(initialNotes)
  const [search, setSearch] = useState('')
  const [showArchived, setShowArchived] = useState(false)
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<NoteRow | null>(null)
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const { push } = useToast()

  const filtered = useMemo(
    () =>
      notes.filter(
        (n) =>
          n.archived === showArchived &&
          (search.trim() === '' ||
            n.title.toLowerCase().includes(search.toLowerCase()) ||
            n.content.toLowerCase().includes(search.toLowerCase()) ||
            n.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()))),
      ),
    [notes, search, showArchived],
  )

  const refresh = () => setNotes([...notes].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)))

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Input placeholder="Search notes and #tags…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search notes" />
        <Button onClick={() => { setEditing(null); setOpen(true) }}>
          <Plus className="h-4 w-4" /> New
        </Button>
      </div>
      <div className="flex items-center justify-between rounded-xl border border-line/60 bg-surface px-3 py-2">
        <span className="text-[13px] text-muted">Show archived</span>
        <Switch checked={showArchived} onChange={setShowArchived} label="Show archived" />
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={StickyNote}
          title={showArchived ? 'Archive is empty' : 'No notes yet'}
          description="Quick capture from anywhere, or write a full note here."
          action={<Button onClick={() => { setEditing(null); setOpen(true) }}><Plus className="h-4 w-4" /> Write a note</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {filtered.map((n) => (
            <Card key={n.id} className={n.favourite ? 'border-amber/40' : undefined}>
              <CardContent className="pt-4">
                <div className="flex items-start justify-between gap-2">
                  <button
                    className="min-w-0 flex-1 text-left"
                    onClick={() => { setEditing(n); setOpen(true) }}
                  >
                    <p className="truncate text-[15px] font-semibold text-ink">{n.title}</p>
                    <p className="mt-1 line-clamp-3 whitespace-pre-wrap text-[13px] text-muted">{n.content || 'Empty note'}</p>
                  </button>
                </div>
                {n.tags.length > 0 && (
                  <p className="mt-2 truncate text-[12px] text-accent">{n.tags.map((t) => `#${t}`).join(' ')}</p>
                )}
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-[11px] text-faint">{formatDate(n.updatedAt, 'short')}</span>
                  <div className="flex">
                    <button
                      aria-label={n.favourite ? 'Unfavourite' : 'Favourite'}
                      onClick={async () => {
                        const res = await toggleNoteFlagAction(n.id, 'favourite', !n.favourite)
                        if (res.ok) {
                          setNotes((ns) => ns.map((x) => (x.id === n.id ? { ...x, favourite: !n.favourite } : x)))
                        } else push(res.error, 'error')
                      }}
                      className={`p-1.5 ${n.favourite ? 'text-amber' : 'text-faint hover:text-amber'}`}
                    >
                      <Star className="h-4 w-4" fill={n.favourite ? 'currentColor' : 'none'} />
                    </button>
                    <button
                      aria-label={n.archived ? 'Unarchive' : 'Archive'}
                      onClick={async () => {
                        const res = await toggleNoteFlagAction(n.id, 'archived', !n.archived)
                        if (res.ok) {
                          setNotes((ns) => ns.map((x) => (x.id === n.id ? { ...x, archived: !n.archived } : x)))
                        } else push(res.error, 'error')
                      }}
                      className="p-1.5 text-faint hover:text-ink"
                    >
                      {n.archived ? <ArchiveRestore className="h-4 w-4" /> : <Archive className="h-4 w-4" />}
                    </button>
                    <button aria-label="Edit note" onClick={() => { setEditing(n); setOpen(true) }} className="p-1.5 text-faint hover:text-ink">
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button aria-label="Delete note" onClick={() => setConfirmId(n.id)} className="p-1.5 text-faint hover:text-danger">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {open && <NoteDialog key={editing?.id ?? 'new'} initial={editing} onClose={() => setOpen(false)} onSaved={refresh} />}

      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteNoteAction(confirmId)
          setConfirmId(null)
          if (res.ok) setNotes((ns) => ns.filter((n) => n.id !== confirmId))
          push(res.ok ? 'Note deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete note"
        message="This permanently deletes the note and its tags."
      />
    </div>
  )
}

function NoteDialog({ initial, onClose, onSaved }: { initial: NoteRow | null; onClose: () => void; onSaved: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveNoteAction, { ok: true })
  const submitted = useRef(false)
  const [favourite, setFavourite] = useState(initial?.favourite ?? false)

  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push(initial ? 'Note updated' : 'Note saved')
      onSaved()
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose, initial, onSaved])

  return (
    <Dialog open onClose={onClose} title={initial ? 'Edit note' : 'New note'} wide>
      <form
        action={(fd) => {
          fd.set('favourite', String(favourite))
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        {initial && <input type="hidden" name="id" value={initial.id} />}
        <div>
          <InputLabel htmlFor="n-title">Title</InputLabel>
          <Input id="n-title" name="title" defaultValue={initial?.title} required autoFocus />
        </div>
        <div>
          <InputLabel htmlFor="n-content">Content</InputLabel>
          <Textarea id="n-content" name="content" rows={8} defaultValue={initial?.content} placeholder="Write it down…" />
        </div>
        <div>
          <InputLabel htmlFor="n-tags">Tags (comma separated)</InputLabel>
          <Input id="n-tags" name="tags" defaultValue={initial?.tags.join(', ')} placeholder="ideas, home" />
        </div>
        <div className="flex items-center justify-between rounded-xl border border-line/60 bg-surface px-3 py-2.5">
          <span className="text-[14px] text-ink">Favourite</span>
          <Switch checked={favourite} onChange={setFavourite} label="Favourite" />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" size="lg" disabled={saving}>
          {saving ? 'Saving…' : initial ? 'Save changes' : 'Save note'}
        </Button>
      </form>
    </Dialog>
  )
}
