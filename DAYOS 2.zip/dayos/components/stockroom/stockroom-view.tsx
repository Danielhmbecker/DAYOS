'use client'

import { useState, useActionState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { ClipboardCheck, Minus, Package, Plus, Sparkles, Trash2 } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Select } from '@/components/ui/select'
import { useToast } from '@/components/ui/toast'
import {
  adjustStockAction,
  completeCleaningAction,
  deleteCleaningTaskAction,
  deleteStockItemAction,
  recordCountAction,
  saveCleaningTaskAction,
  saveStockItemAction,
} from '@/app/(app)/stockroom/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatNumber } from '@/lib/utils'

export type StockRow = {
  id: string
  name: string
  category: string
  unit: string
  quantity: number
  threshold: number
  location: string | null
  low: boolean
}
export type HealthRow = { category: string; total: number; ok: number; percent: number }
export type CleaningRow = {
  id: string
  title: string
  area: string | null
  frequency: string
  status: 'ok' | 'due' | 'overdue'
  lastCompletedAt: string | null
}

export function StockroomView({
  items,
  health,
  cleaning,
}: {
  items: StockRow[]
  health: HealthRow[]
  cleaning: CleaningRow[]
}) {
  const [itemOpen, setItemOpen] = useState(false)
  const [editing, setEditing] = useState<StockRow | null>(null)
  const [countItem, setCountItem] = useState<StockRow | null>(null)
  const [confirmItem, setConfirmItem] = useState<string | null>(null)
  const [cleanOpen, setCleanOpen] = useState(false)
  const [confirmClean, setConfirmClean] = useState<string | null>(null)
  const { push } = useToast()

  const cleaningCounts = {
    ok: cleaning.filter((c) => c.status === 'ok').length,
    due: cleaning.filter((c) => c.status === 'due').length,
    overdue: cleaning.filter((c) => c.status === 'overdue').length,
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {health.slice(0, 3).map((h) => (
          <Card key={h.category}>
            <CardContent className="pt-4">
              <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">{h.category}</p>
              <p className="mt-1 text-[20px] font-bold text-ink">
                {h.ok} / {h.total} <span className="text-[13px] font-medium text-success">OK</span>
              </p>
              <Progress className="mt-2" value={h.percent} tone={h.percent < 50 ? 'danger' : h.percent < 80 ? 'warning' : 'success'} />
            </CardContent>
          </Card>
        ))}
      </div>

      <section aria-label="Stock">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">Stock</p>
          <Button size="sm" onClick={() => { setEditing(null); setItemOpen(true) }}>
            <Plus className="h-4 w-4" /> Item
          </Button>
        </div>
        {items.length === 0 ? (
          <EmptyState
            icon={Package}
            title="No stock tracked"
            description="Kegs, lines, consumables — any category you like, with thresholds and count history."
            action={<Button onClick={() => setItemOpen(true)}>Add your first item</Button>}
          />
        ) : (
          <Card>
            <CardContent className="pt-2">
              <ul className="divide-y divide-line/50">
                {items.map((i) => (
                  <li key={i.id} className="flex items-center gap-2 py-3">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-medium text-ink">
                        {i.name}
                        {i.low && <Badge tone="danger" className="ml-2">low</Badge>}
                      </p>
                      <p className="truncate text-[12px] text-muted">
                        {i.category}
                        {i.location ? ` · ${i.location}` : ''} · min {formatNumber(i.threshold)} {i.unit}
                      </p>
                    </div>
                    <button
                      aria-label={`Decrease ${i.name}`}
                      onClick={async () => {
                        const res = await adjustStockAction(i.id, -1)
                        if (!res.ok) push(res.error, 'error')
                      }}
                      className="flex h-9 w-9 items-center justify-center rounded-xl bg-elevate text-muted hover:text-ink"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-16 text-center text-[15px] font-bold text-ink">
                      {formatNumber(i.quantity)}
                      <span className="block text-[10px] font-medium text-faint">{i.unit}</span>
                    </span>
                    <button
                      aria-label={`Increase ${i.name}`}
                      onClick={async () => {
                        const res = await adjustStockAction(i.id, 1)
                        if (!res.ok) push(res.error, 'error')
                      }}
                      className="flex h-9 w-9 items-center justify-center rounded-xl bg-elevate text-muted hover:text-ink"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                    <button aria-label={`Stock count for ${i.name}`} onClick={() => setCountItem(i)} className="p-2 text-faint hover:text-accent">
                      <ClipboardCheck className="h-4 w-4" />
                    </button>
                    <button aria-label={`Edit ${i.name}`} onClick={() => { setEditing(i); setItemOpen(true) }} className="p-2 text-faint hover:text-ink">
                      <Package className="h-4 w-4" />
                    </button>
                    <button aria-label={`Delete ${i.name}`} onClick={() => setConfirmItem(i.id)} className="p-2 text-faint hover:text-danger">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </section>

      <section aria-label="Cleaning schedule">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-[12px] font-semibold uppercase tracking-wider text-muted">
            Cleaning ·{' '}
            <span className="text-success">{cleaningCounts.ok} ok</span>{' '}
            <span className="text-warning">{cleaningCounts.due} due</span>{' '}
            <span className="text-danger">{cleaningCounts.overdue} overdue</span>
          </p>
          <Button size="sm" variant="secondary" onClick={() => setCleanOpen(true)}>
            <Plus className="h-4 w-4" /> Schedule
          </Button>
        </div>
        {cleaning.length === 0 ? (
          <EmptyState icon={Sparkles} title="No cleaning schedule" description="Recurring checks with due/overdue status, computed from completion history." />
        ) : (
          <Card>
            <CardContent className="pt-2">
              <ul className="divide-y divide-line/50">
                {cleaning.map((c) => (
                  <li key={c.id} className="flex items-center gap-3 py-3">
                    <span
                      className={`h-2.5 w-2.5 shrink-0 rounded-full ${
                        c.status === 'ok' ? 'bg-success' : c.status === 'due' ? 'bg-warning' : 'bg-danger'
                      }`}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[14px] font-medium text-ink">{c.title}</span>
                      <span className="block text-[12px] text-muted">
                        {c.frequency.toLowerCase()}
                        {c.area ? ` · ${c.area}` : ''}
                      </span>
                    </span>
                    <Badge tone={c.status === 'ok' ? 'success' : c.status === 'due' ? 'warning' : 'danger'}>{c.status}</Badge>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={async () => {
                        const res = await completeCleaningAction(c.id)
                        push(res.ok ? 'Marked complete' : res.error, res.ok ? 'success' : 'error')
                      }}
                    >
                      Done
                    </Button>
                    <button aria-label={`Delete ${c.title}`} onClick={() => setConfirmClean(c.id)} className="p-2 text-faint hover:text-danger">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </section>

      <p className="text-[12px] text-faint">
        Stockroom is generic — categories are yours. Demo data uses a bar setup; rename or delete anything.
        Future modules like BetLab and Turbo appear in <Link href="/more" className="text-accent">More</Link>.
      </p>

      {itemOpen && <ItemDialog key={editing?.id ?? 'new'} initial={editing} onClose={() => setItemOpen(false)} />}
      {countItem && <CountDialog item={countItem} onClose={() => setCountItem(null)} />}
      {cleanOpen && <CleaningDialog onClose={() => setCleanOpen(false)} />}

      <ConfirmDialog
        open={confirmItem !== null}
        onClose={() => setConfirmItem(null)}
        onConfirm={async () => {
          if (!confirmItem) return
          const res = await deleteStockItemAction(confirmItem)
          setConfirmItem(null)
          push(res.ok ? 'Item deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete stock item"
        message="Count history for this item is also removed."
      />
      <ConfirmDialog
        open={confirmClean !== null}
        onClose={() => setConfirmClean(null)}
        onConfirm={async () => {
          if (!confirmClean) return
          const res = await deleteCleaningTaskAction(confirmClean)
          setConfirmClean(null)
          push(res.ok ? 'Schedule deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete cleaning schedule"
        message="This removes the recurring cleaning task."
      />
    </div>
  )
}

function ItemDialog({ initial, onClose }: { initial: StockRow | null; onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveStockItemAction, { ok: true })
  const submitted = useRef(false)
  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push(initial ? 'Item updated' : 'Item added')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose, initial])
  return (
    <Dialog open onClose={onClose} title={initial ? 'Edit item' : 'New stock item'}>
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        {initial && <input type="hidden" name="id" value={initial.id} />}
        <div>
          <InputLabel htmlFor="si-name">Name</InputLabel>
          <Input id="si-name" name="name" defaultValue={initial?.name} required autoFocus />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="si-cat">Category</InputLabel>
            <Input id="si-cat" name="category" defaultValue={initial?.category ?? 'General'} placeholder="Kegs, Lines…" />
          </div>
          <div>
            <InputLabel htmlFor="si-unit">Unit</InputLabel>
            <Input id="si-unit" name="unit" defaultValue={initial?.unit ?? 'unit'} placeholder="keg, pint, box" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="si-qty">Quantity</InputLabel>
            <Input id="si-qty" name="quantity" type="number" step="0.01" min="0" defaultValue={initial?.quantity ?? 0} />
          </div>
          <div>
            <InputLabel htmlFor="si-thr">Low threshold</InputLabel>
            <Input id="si-thr" name="threshold" type="number" step="0.01" min="0" defaultValue={initial?.threshold ?? 0} />
          </div>
        </div>
        <div>
          <InputLabel htmlFor="si-loc">Location</InputLabel>
          <Input id="si-loc" name="location" defaultValue={initial?.location ?? ''} placeholder="Cellar" />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          {initial ? 'Save changes' : 'Add item'}
        </Button>
      </form>
    </Dialog>
  )
}

function CountDialog({ item, onClose }: { item: StockRow; onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(recordCountAction, { ok: true })
  const submitted = useRef(false)
  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push('Count recorded')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose])
  return (
    <Dialog open onClose={onClose} title={`Stock count · ${item.name}`}>
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        <input type="hidden" name="itemId" value={item.id} />
        <div>
          <InputLabel htmlFor="sc-qty">Counted quantity ({item.unit})</InputLabel>
          <Input id="sc-qty" name="countedQuantity" type="number" step="0.01" min="0" defaultValue={item.quantity} autoFocus required />
        </div>
        <div>
          <InputLabel htmlFor="sc-note">Note</InputLabel>
          <Input id="sc-note" name="note" placeholder="Weekly count" />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          Record count
        </Button>
      </form>
    </Dialog>
  )
}

function CleaningDialog({ onClose }: { onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveCleaningTaskAction, { ok: true })
  const submitted = useRef(false)
  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push('Schedule added')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose])
  return (
    <Dialog open onClose={onClose} title="New cleaning schedule">
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        <div>
          <InputLabel htmlFor="cl-title">Task</InputLabel>
          <Input id="cl-title" name="title" placeholder="Line clean" required autoFocus />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="cl-area">Area</InputLabel>
            <Input id="cl-area" name="area" placeholder="Bar" />
          </div>
          <div>
            <InputLabel htmlFor="cl-freq">Frequency</InputLabel>
            <Select id="cl-freq" name="frequency" defaultValue="WEEKLY">
              <option value="DAILY">Daily</option>
              <option value="WEEKLY">Weekly</option>
              <option value="MONTHLY">Monthly</option>
              <option value="YEARLY">Yearly</option>
            </Select>
          </div>
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          Add schedule
        </Button>
      </form>
    </Dialog>
  )
}
