'use client'

import { useMemo, useState, useActionState, useEffect, useRef } from 'react'
import { CalendarDays, ChevronLeft, ChevronRight, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Segmented } from '@/components/ui/segmented'
import { Switch } from '@/components/ui/switch'
import { useToast } from '@/components/ui/toast'
import { deleteEventAction, saveEventAction } from '@/app/(app)/calendar/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { cn, formatTime } from '@/lib/utils'

export type EventRow = {
  id: string
  title: string
  start: string
  end: string | null
  allDay: boolean
  location: string | null
}

type ViewMode = 'month' | 'week' | 'day'

function isoDay(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export function CalendarView({ events }: { events: EventRow[] }) {
  const [mode, setMode] = useState<ViewMode>('month')
  const [cursor, setCursor] = useState(() => new Date())
  const [selected, setSelected] = useState(() => isoDay(new Date()))
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<EventRow | null>(null)
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const { push } = useToast()

  const byDay = useMemo(() => {
    const map = new Map<string, EventRow[]>()
    for (const e of events) {
      const key = e.start.slice(0, 10)
      map.set(key, [...(map.get(key) ?? []), e].sort((a, b) => a.start.localeCompare(b.start)))
    }
    return map
  }, [events])

  const monthGrid = useMemo(() => {
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1)
    const startOffset = (first.getDay() + 6) % 7 // Monday first
    const daysInMonth = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate()
    const cells: (string | null)[] = []
    for (let i = 0; i < startOffset; i++) cells.push(null)
    for (let d = 1; d <= daysInMonth; d++) {
      cells.push(isoDay(new Date(cursor.getFullYear(), cursor.getMonth(), d)))
    }
    while (cells.length % 7 !== 0) cells.push(null)
    return cells
  }, [cursor])

  const weekDays = useMemo(() => {
    const sel = new Date(`${selected}T12:00:00`)
    const offset = (sel.getDay() + 6) % 7
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(sel)
      d.setDate(sel.getDate() - offset + i)
      return isoDay(d)
    })
  }, [selected])

  const daysToShow = mode === 'day' ? [selected] : mode === 'week' ? weekDays : []
  const todayIso = isoDay(new Date())

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Segmented
          className="flex-1"
          value={mode}
          onChange={setMode}
          options={[
            { value: 'month', label: 'Month' },
            { value: 'week', label: 'Week' },
            { value: 'day', label: 'Day' },
          ]}
        />
        <Button onClick={() => { setEditing(null); setOpen(true) }} aria-label="Add event">
          <Plus className="h-4 w-4" /> Event
        </Button>
      </div>

      {mode === 'month' && (
        <Card>
          <CardContent className="pt-4">
            <div className="mb-3 flex items-center justify-between">
              <Button size="icon" variant="ghost" aria-label="Previous month" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}>
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <p className="text-[15px] font-semibold text-ink">
                {cursor.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}
              </p>
              <Button size="icon" variant="ghost" aria-label="Next month" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}>
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-semibold uppercase text-faint">
              {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => (
                <span key={i} className="py-1">{d}</span>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {monthGrid.map((day, i) => (
                <button
                  key={i}
                  disabled={!day}
                  onClick={() => {
                    if (day) {
                      setSelected(day)
                      setMode('day')
                    }
                  }}
                  className={cn(
                    'relative flex h-11 flex-col items-center justify-center rounded-xl text-[13px] transition-colors',
                    !day && 'opacity-0',
                    day === todayIso && 'bg-accent/15 font-bold text-accent',
                    day === selected && day !== todayIso && 'bg-elevate text-ink',
                    day && day !== todayIso && day !== selected && 'text-muted hover:bg-elevate/60',
                  )}
                >
                  {day ? Number(day.slice(8)) : ''}
                  {day && (byDay.get(day)?.length ?? 0) > 0 && (
                    <span className="absolute bottom-1.5 flex gap-0.5">
                      {byDay.get(day)!.slice(0, 3).map((e) => (
                        <span key={e.id} className="h-1 w-1 rounded-full bg-accent" />
                      ))}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {mode !== 'month' && (
        <div className="space-y-3">
          {mode === 'week' && (
            <div className="grid grid-cols-7 gap-1">
              {weekDays.map((day) => (
                <button
                  key={day}
                  onClick={() => setSelected(day)}
                  className={cn(
                    'flex h-14 flex-col items-center justify-center rounded-xl text-[12px]',
                    day === selected ? 'bg-accent/15 text-accent' : 'bg-surface text-muted',
                  )}
                >
                  <span className="font-semibold uppercase">{new Date(`${day}T12:00:00`).toLocaleDateString('en-GB', { weekday: 'short' })}</span>
                  <span className="text-[15px] font-bold">{Number(day.slice(8))}</span>
                </button>
              ))}
            </div>
          )}
          {daysToShow.map((day) => {
            const dayEvents = byDay.get(day) ?? []
            return (
              <Card key={day}>
                <CardContent className="pt-4">
                  <p className="text-[13px] font-semibold uppercase tracking-wider text-muted">
                    {new Date(`${day}T12:00:00`).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}
                  </p>
                  {dayEvents.length === 0 ? (
                    <p className="mt-3 text-[14px] text-muted">Nothing scheduled.</p>
                  ) : (
                    <ul className="mt-2 divide-y divide-line/50">
                      {dayEvents.map((e) => (
                        <li key={e.id} className="flex items-center gap-3 py-2.5">
                          <span className="w-14 shrink-0 text-[13px] font-semibold text-accent">
                            {e.allDay ? 'All day' : formatTime(e.start)}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[14px] text-ink">{e.title}</span>
                            {e.location && <span className="block truncate text-[12px] text-muted">{e.location}</span>}
                          </span>
                          <button
                            aria-label={`Delete ${e.title}`}
                            onClick={() => setConfirmId(e.id)}
                            className="p-1.5 text-faint hover:text-danger"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      {events.length === 0 && (
        <EmptyState
          icon={CalendarDays}
          title="No events yet"
          description="Shifts live in Work — personal events and appointments live here."
        />
      )}

      {open && (
        <EventDialog
          key={editing?.id ?? 'new'}
          initial={editing}
          defaultDate={selected}
          onClose={() => setOpen(false)}
        />
      )}

      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteEventAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Event deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete event"
        message="This permanently deletes the event."
      />
    </div>
  )
}

function EventDialog({
  initial,
  defaultDate,
  onClose,
}: {
  initial: EventRow | null
  defaultDate: string
  onClose: () => void
}) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveEventAction, { ok: true })
  const submitted = useRef(false)
  const [allDay, setAllDay] = useState(initial?.allDay ?? false)

  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push(initial ? 'Event updated' : 'Event added')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose, initial])

  return (
    <Dialog open onClose={onClose} title={initial ? 'Edit event' : 'New event'}>
      <form
        action={(fd) => {
          fd.set('allDay', String(allDay))
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        {initial && <input type="hidden" name="id" value={initial.id} />}
        <div>
          <InputLabel htmlFor="e-title">Title</InputLabel>
          <Input id="e-title" name="title" defaultValue={initial?.title} required autoFocus />
        </div>
        <div>
          <InputLabel htmlFor="e-date">Date</InputLabel>
          <Input id="e-date" name="date" type="date" defaultValue={initial ? initial.start.slice(0, 10) : defaultDate} required />
        </div>
        <div className="flex items-center justify-between rounded-xl border border-line/60 bg-surface px-3 py-2.5">
          <span className="text-[14px] text-ink">All day</span>
          <Switch checked={allDay} onChange={setAllDay} label="All day" />
        </div>
        {!allDay && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <InputLabel htmlFor="e-start">Starts</InputLabel>
              <Input id="e-start" name="startTime" type="time" defaultValue={initial ? initial.start.slice(11, 16) : '09:00'} required />
            </div>
            <div>
              <InputLabel htmlFor="e-end">Ends</InputLabel>
              <Input id="e-end" name="endTime" type="time" defaultValue={initial?.end ? initial.end.slice(11, 16) : '10:00'} />
            </div>
          </div>
        )}
        <div>
          <InputLabel htmlFor="e-loc">Location</InputLabel>
          <Input id="e-loc" name="location" defaultValue={initial?.location ?? ''} />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          {initial ? 'Save changes' : 'Add event'}
        </Button>
      </form>
    </Dialog>
  )
}
