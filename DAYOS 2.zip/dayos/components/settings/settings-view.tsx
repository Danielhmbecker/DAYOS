'use client'

import { useState, useActionState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { KeyRound, LogOut, MonitorSmartphone, User as UserIcon, Wallet } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { useToast } from '@/components/ui/toast'
import {
  changePasswordAction,
  signOutEverywhereAction,
  updateDashboardConfigAction,
  updatePreferencesAction,
  updateProfileAction,
  updateWorkRatesAction,
} from '@/app/(app)/settings/actions'
import { logoutAction } from '@/lib/actions/auth'
import type { ActionResult } from '@/lib/actions/guard'

export type SettingsData = {
  name: string
  email: string
  currency: string
  weatherEnabled: boolean
  weatherLatitude: number | null
  weatherLongitude: number | null
  weatherLabel: string | null
  workHourlyRate: number
  workOvertimeThresholdMin: number
  workOvertimeMultiplier: number
  dashboardHidden: string[]
}

export const DASHBOARD_CARDS = [
  { key: 'balance', label: 'Available balance' },
  { key: 'savings', label: 'Savings' },
  { key: 'tasks', label: 'Tasks remaining' },
  { key: 'work', label: 'Work today' },
  { key: 'event', label: 'Next event' },
  { key: 'career', label: 'Career goal' },
  { key: 'bills', label: 'Bills due soon' },
  { key: 'quick', label: 'Quick actions' },
]

export function SettingsView({ data }: { data: SettingsData }) {
  const { push } = useToast()
  const router = useRouter()
  const [weather, setWeather] = useState(data.weatherEnabled)
  const [hidden, setHidden] = useState<string[]>(data.dashboardHidden)

  const [profileState, profileAction, profilePending] = useActionState<ActionResult, FormData>(updateProfileAction, { ok: true })
  const [prefsState, prefsAction, prefsPending] = useActionState<ActionResult, FormData>(updatePreferencesAction, { ok: true })
  const [ratesState, ratesAction, ratesPending] = useActionState<ActionResult, FormData>(updateWorkRatesAction, { ok: true })
  const [pwState, pwAction, pwPending] = useActionState<ActionResult, FormData>(changePasswordAction, { ok: true })

  const pSub = useRef(false)
  const fSub = useRef(false)
  const rSub = useRef(false)
  const wSub = useRef(false)

  useEffect(() => {
    if (pSub.current && !profilePending) {
      pSub.current = false
      push(profileState.ok ? 'Profile saved' : profileState.error, profileState.ok ? 'success' : 'error')
    }
    if (fSub.current && !prefsPending) {
      fSub.current = false
      push(prefsState.ok ? 'Preferences saved' : prefsState.error, prefsState.ok ? 'success' : 'error')
    }
    if (rSub.current && !ratesPending) {
      rSub.current = false
      push(ratesState.ok ? 'Work rates saved' : ratesState.error, ratesState.ok ? 'success' : 'error')
    }
    if (wSub.current && !pwPending) {
      wSub.current = false
      push(pwState.ok ? 'Password changed' : pwState.error, pwState.ok ? 'success' : 'error')
    }
  }, [profileState, prefsState, ratesState, pwState, profilePending, prefsPending, ratesPending, pwPending, push])

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="pt-4">
          <div className="flex items-center gap-2">
            <UserIcon className="h-4 w-4 text-accent" />
            <p className="text-[13px] font-semibold uppercase tracking-wider text-muted">Profile</p>
          </div>
          <form
            action={(fd) => {
              pSub.current = true
              profileAction(fd)
            }}
            className="mt-4 space-y-4"
          >
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <InputLabel htmlFor="set-name">Name</InputLabel>
                <Input id="set-name" name="name" defaultValue={data.name} required />
              </div>
              <div>
                <InputLabel htmlFor="set-email">Email</InputLabel>
                <Input id="set-email" name="email" type="email" defaultValue={data.email} required />
              </div>
            </div>
            <FieldError message={profileState.ok ? undefined : profileState.error} />
            <Button type="submit" disabled={profilePending}>Save profile</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-4">
          <div className="flex items-center gap-2">
            <MonitorSmartphone className="h-4 w-4 text-mint" />
            <p className="text-[13px] font-semibold uppercase tracking-wider text-muted">Dashboard & weather</p>
          </div>
          <p className="mt-3 text-[13px] text-muted">Show or hide dashboard cards:</p>
          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
            {DASHBOARD_CARDS.map((c) => (
              <div key={c.key} className="flex items-center gap-3 rounded-xl border border-line/60 bg-surface px-3 py-2.5">
                <Checkbox
                  checked={!hidden.includes(c.key)}
                  label={c.label}
                  onChange={async (checked) => {
                    const next = checked ? hidden.filter((h) => h !== c.key) : [...hidden, c.key]
                    const res = await updateDashboardConfigAction(next)
                    if (res.ok) setHidden(next)
                    else push(res.error, 'error')
                  }}
                />
                <span className="text-[14px] text-ink">{c.label}</span>
              </div>
            ))}
          </div>
          <form
            action={(fd) => {
              fd.set('weatherEnabled', String(weather))
              fSub.current = true
              prefsAction(fd)
            }}
            className="mt-4 space-y-4"
          >
            <div className="flex items-center justify-between rounded-xl border border-line/60 bg-surface px-3 py-2.5">
              <div>
                <p className="text-[14px] text-ink">Weather on dashboard</p>
                <p className="text-[12px] text-faint">Uses Open-Meteo (no API key). Only fetched when enabled.</p>
              </div>
              <Switch checked={weather} onChange={setWeather} label="Weather enabled" />
            </div>
            {weather && (
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <InputLabel htmlFor="w-lat">Latitude</InputLabel>
                  <Input id="w-lat" name="weatherLatitude" type="number" step="0.0001" defaultValue={data.weatherLatitude ?? 51.5074} />
                </div>
                <div>
                  <InputLabel htmlFor="w-lon">Longitude</InputLabel>
                  <Input id="w-lon" name="weatherLongitude" type="number" step="0.0001" defaultValue={data.weatherLongitude ?? -0.1278} />
                </div>
                <div>
                  <InputLabel htmlFor="w-label">Label</InputLabel>
                  <Input id="w-label" name="weatherLabel" defaultValue={data.weatherLabel ?? 'London'} />
                </div>
              </div>
            )}
            <div>
              <InputLabel htmlFor="set-currency">Currency (ISO code)</InputLabel>
              <Select id="set-currency" name="currency" defaultValue={data.currency} className="max-w-32">
                {['GBP', 'EUR', 'USD'].map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </Select>
            </div>
            <FieldError message={prefsState.ok ? undefined : prefsState.error} />
            <Button type="submit" disabled={prefsPending}>Save preferences</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-4">
          <div className="flex items-center gap-2">
            <Wallet className="h-4 w-4 text-success" />
            <p className="text-[13px] font-semibold uppercase tracking-wider text-muted">Work rates</p>
          </div>
          <form
            action={(fd) => {
              rSub.current = true
              ratesAction(fd)
            }}
            className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3"
          >
            <div>
              <InputLabel htmlFor="wr-rate">Hourly rate (£)</InputLabel>
              <Input id="wr-rate" name="workHourlyRate" type="number" step="0.01" min="0" defaultValue={data.workHourlyRate} />
            </div>
            <div>
              <InputLabel htmlFor="wr-thr">Overtime after (min/shift)</InputLabel>
              <Input id="wr-thr" name="workOvertimeThresholdMin" type="number" min="0" max="1440" defaultValue={data.workOvertimeThresholdMin} />
            </div>
            <div>
              <InputLabel htmlFor="wr-mult">Overtime multiplier</InputLabel>
              <Input id="wr-mult" name="workOvertimeMultiplier" type="number" step="0.1" min="1" max="5" defaultValue={data.workOvertimeMultiplier} />
            </div>
            <div className="sm:col-span-3">
              <FieldError message={ratesState.ok ? undefined : ratesState.error} />
              <Button type="submit" disabled={ratesPending}>Save rates</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-4">
          <div className="flex items-center gap-2">
            <KeyRound className="h-4 w-4 text-warning" />
            <p className="text-[13px] font-semibold uppercase tracking-wider text-muted">Security</p>
          </div>
          <form
            action={(fd) => {
              wSub.current = true
              pwAction(fd)
            }}
            className="mt-4 space-y-4"
          >
            <div>
              <InputLabel htmlFor="pw-current">Current password</InputLabel>
              <Input id="pw-current" name="currentPassword" type="password" autoComplete="current-password" required />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <InputLabel htmlFor="pw-new">New password</InputLabel>
                <Input id="pw-new" name="newPassword" type="password" autoComplete="new-password" required />
              </div>
              <div>
                <InputLabel htmlFor="pw-confirm">Confirm new password</InputLabel>
                <Input id="pw-confirm" name="confirm" type="password" autoComplete="new-password" required />
              </div>
            </div>
            <FieldError message={pwState.ok ? undefined : pwState.error} />
            <div className="flex flex-wrap gap-3">
              <Button type="submit" disabled={pwPending}>Change password</Button>
              <Button
                type="button"
                variant="secondary"
                onClick={async () => {
                  const res = await signOutEverywhereAction()
                  push(res.ok ? 'Other sessions signed out' : res.error, res.ok ? 'success' : 'error')
                }}
              >
                Sign out other sessions
              </Button>
              <form action={logoutAction}>
                <Button type="submit" variant="danger">
                  <LogOut className="h-4 w-4" /> Sign out
                </Button>
              </form>
            </div>
          </form>
        </CardContent>
      </Card>

      <p className="pb-2 text-center text-[12px] text-faint">
        DAYOS v1.0 · your data stays on your infrastructure ·{' '}
        <button className="text-accent" onClick={() => router.push('/more')}>Explore modules</button>
      </p>
    </div>
  )
}
