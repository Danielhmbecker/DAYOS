'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { PRIMARY_NAV, MORE_NAV, isActive } from '@/lib/nav'
import { cn } from '@/lib/utils'

export function Sidebar() {
  const pathname = usePathname()
  const inMore = MORE_NAV.some((m) => isActive(pathname, m.href))
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-line/70 bg-surface/60 md:flex safe-top">
      <Link href="/" className="flex items-center gap-2.5 px-5 py-5">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/dayos-64.png" alt="" className="h-8 w-8 rounded-lg" />
        <span className="text-lg font-bold tracking-tight">
          DAY<span className="text-accent">OS</span>
        </span>
      </Link>
      <nav aria-label="Primary" className="flex-1 space-y-1 px-3">
        {[...PRIMARY_NAV.slice(0, 4), ...MORE_NAV].map((item) => {
          const active = isActive(pathname, item.href)
          return (
            <Link
              key={item.href}
              href={item.href}
              aria-current={active ? 'page' : undefined}
              className={cn(
                'flex h-11 items-center gap-3 rounded-xl px-3 text-[15px] font-medium transition-colors',
                active ? 'bg-elevate text-ink' : 'text-muted hover:bg-elevate/60 hover:text-ink',
              )}
            >
              <item.icon className={cn('h-5 w-5', active && 'text-accent')} />
              {item.label}
            </Link>
          )
        })}
        <div className={cn('mt-2 rounded-xl px-3 py-2 text-[11px] uppercase tracking-wider', inMore ? 'text-accent' : 'text-faint')}>
          Your life. One place.
        </div>
      </nav>
    </aside>
  )
}
