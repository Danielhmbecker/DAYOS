import type { User } from '@prisma/client'
import { GlobalSearch } from '@/components/shell/global-search'
import { NotificationsMenu } from '@/components/shell/notifications-menu'
import { UserMenu } from '@/components/shell/user-menu'
import { getAlerts } from '@/lib/services/notifications'

export async function AppHeader({ user }: { user: User }) {
  const alerts = await getAlerts(user.id).catch(() => [])
  return (
    <header className="sticky top-0 z-40 border-b border-line/60 bg-bg/85 backdrop-blur-xl safe-top">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4">
        <div className="flex min-w-0 items-center gap-2 md:hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/dayos-64.png" alt="" className="h-7 w-7 rounded-lg" />
          <span className="text-[17px] font-bold tracking-tight">
            DAY<span className="text-accent">OS</span>
          </span>
        </div>
        <div className="hidden md:block" />
        <div className="flex items-center gap-2">
          <GlobalSearch />
          <NotificationsMenu alerts={alerts} />
          <UserMenu name={user.name} email={user.email} />
        </div>
      </div>
    </header>
  )
}
