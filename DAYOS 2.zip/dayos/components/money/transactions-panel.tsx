'use client'

import { useMemo, useState, useActionState, useEffect, useRef } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { ArrowDownLeft, ArrowUpRight, Pencil, Plus, ReceiptText, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog } from '@/components/ui/dialog'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { Segmented } from '@/components/ui/segmented'
import { useToast } from '@/components/ui/toast'
import { deleteTransactionAction, saveTransactionAction } from '@/app/(app)/money/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatMoney, formatDate } from '@/lib/utils'

export type TxRow = {
  id: string
  type: 'INCOME' | 'EXPENSE'
  amount: number
  note: string | null
  date: string
  categoryName: string | null
  categoryColor: string | null
  recurrence: string | null
}

export type CategoryOption = { id: string; name: string; type: 'INCOME' | 'EXPENSE'; color: string }

const formSchema = z.object({
  type: z.enum(['INCOME', 'EXPENSE']),
  amount: z.coerce.number().positive('Amount must be greater than 0'),
  categoryId: z.string().optional(),
  note: z.string().max(200).optional(),
  date: z.string().min(1, 'Date is required'),
  recurrence: z.string().optional(),
})
type FormValues = z.infer<typeof formSchema>

export function TransactionsPanel({
  rows,
  categories,
  currency,
}: {
  rows: TxRow[]
  categories: CategoryOption[]
  currency: string
}) {
  const [filter, setFilter] = useState<'ALL' | 'INCOME' | 'EXPENSE'>('ALL')
  const [search, setSearch] = useState('')
  const [editing, setEditing] = useState<TxRow | null>(null)
  const [open, setOpen] = useState(false)
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const { push } = useToast()

  const filtered = useMemo(
    () =>
      rows.filter(
        (r) =>
          (filter === 'ALL' || r.type === filter) &&
          (search.trim() === '' ||
            (r.note ?? '').toLowerCase().includes(search.toLowerCase()) ||
            (r.categoryName ?? '').toLowerCase().includes(search.toLowerCase())),
      ),
    [rows, filter, search],
  )

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Segmented
          className="flex-1"
          value={filter}
          onChange={setFilter}
          options={[
            { value: 'ALL', label: 'All' },
            { value: 'INCOME', label: 'Income' },
            { value: 'EXPENSE', label: 'Expenses' },
          ]}
        />
        <Button size="md" onClick={() => { setEditing(null); setOpen(true) }}>
          <Plus className="h-4 w-4" /> Add
        </Button>
      </div>
      <Input placeholder="Search notes and categories…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search transactions" />

      {filtered.length === 0 ? (
        <EmptyState
          icon={ReceiptText}
          title="No transactions"
          description="Log income or an expense and it will show up here instantly."
          action={<Button onClick={() => setOpen(true)}><Plus className="h-4 w-4" /> Add transaction</Button>}
        />
      ) : (
        <Card>
          <CardContent className="pt-2">
            <ul className="divide-y divide-line/50">
              {filtered.map((r) => (
                <li key={r.id} className="flex items-center gap-3 py-3">
                  <span
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                    style={{ background: `${r.categoryColor ?? (r.type === 'INCOME' ? '#34D399' : '#FB7185')}22` }}
                  >
                    {r.type === 'INCOME' ? (
                      <ArrowDownLeft className="h-4 w-4 text-success" />
                    ) : (
                      <ArrowUpRight className="h-4 w-4 text-danger" />
                    )}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-medium text-ink">
                      {r.note || r.categoryName || (r.type === 'INCOME' ? 'Income' : 'Expense')}
                    </span>
                    <span className="block text-[12px] text-muted">
                      {formatDate(r.date, 'short')}
                      {r.categoryName ? ` · ${r.categoryName}` : ''}
                      {r.recurrence ? ` · repeats ${r.recurrence.toLowerCase()}` : ''}
                    </span>
                  </span>
                  <span className={`text-[15px] font-semibold ${r.type === 'INCOME' ? 'text-success' : 'text-ink'}`}>
                    {r.type === 'INCOME' ? '+' : '−'}
                    {formatMoney(r.amount, currency)}
                  </span>
                  <button
                    aria-label="Edit transaction"
                    onClick={() => { setEditing(r); setOpen(true) }}
                    className="p-2 text-faint hover:text-ink"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    aria-label="Delete transaction"
                    onClick={() => setConfirmId(r.id)}
                    className="p-2 text-faint hover:text-danger"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {open && (
        <TransactionDialog
          key={editing?.id ?? 'new'}
          initial={editing}
          categories={categories}
          onClose={() => setOpen(false)}
        />
      )}

      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteTransactionAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Transaction deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete transaction"
        message="This permanently removes the transaction. Recurring templates stop generating from it."
      />
    </div>
  )
}

function TransactionDialog({
  initial,
  categories,
  onClose,
}: {
  initial: TxRow | null
  categories: CategoryOption[]
  onClose: () => void
}) {
  const { push } = useToast()
  const [saveState, saveAction, saving] = useActionState<ActionResult, FormData>(saveTransactionAction, { ok: true })
  const submitted = useRef(false)

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: initial?.type ?? 'EXPENSE',
      amount: initial?.amount ?? undefined,
      categoryId: initial?.categoryName ? categories.find((c) => c.name === initial.categoryName)?.id ?? '' : '',
      note: initial?.note ?? '',
      date: initial ? initial.date.slice(0, 10) : new Date().toISOString().slice(0, 10),
      recurrence: initial?.recurrence ?? '',
    },
  })

  const type = watch('type')
  const options = categories.filter((c) => c.type === type)

  useEffect(() => {
    if (!submitted.current) return
    if (saving) return
    if (saveState.ok) {
      push(initial ? 'Transaction updated' : 'Transaction added')
      onClose()
    } else {
      push(saveState.error, 'error')
    }
    submitted.current = false
  }, [saveState, saving, push, onClose, initial])

  const onSubmit = handleSubmit((values) => {
    submitted.current = true
    const fd = new FormData()
    if (initial) fd.set('id', initial.id)
    fd.set('type', values.type)
    fd.set('amount', String(values.amount))
    fd.set('categoryId', values.categoryId || '')
    fd.set('note', values.note || '')
    fd.set('date', new Date(`${values.date}T12:00:00`).toISOString())
    fd.set('recurrence', values.recurrence || '')
    saveAction(fd)
  })

  return (
    <Dialog open onClose={onClose} title={initial ? 'Edit transaction' : 'New transaction'}>
      <form onSubmit={onSubmit} className="space-y-4">
        <TypeSwitch register={register} value={type} />
        <div>
          <InputLabel htmlFor="tx-amount">Amount (£)</InputLabel>
          <Input id="tx-amount" type="number" step="0.01" inputMode="decimal" placeholder="0.00" {...register('amount')} />
          <FieldError message={errors.amount?.message} />
        </div>
        <div>
          <InputLabel htmlFor="tx-cat">Category</InputLabel>
          <Select id="tx-cat" {...register('categoryId')}>
            <option value="">No category</option>
            {options.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="tx-date">Date</InputLabel>
            <Input id="tx-date" type="date" {...register('date')} />
            <FieldError message={errors.date?.message} />
          </div>
          <div>
            <InputLabel htmlFor="tx-rec">Repeats</InputLabel>
            <Select id="tx-rec" {...register('recurrence')}>
              <option value="">Never</option>
              <option value="DAILY">Daily</option>
              <option value="WEEKLY">Weekly</option>
              <option value="MONTHLY">Monthly</option>
              <option value="YEARLY">Yearly</option>
            </Select>
          </div>
        </div>
        <div>
          <InputLabel htmlFor="tx-note">Note</InputLabel>
          <Input id="tx-note" placeholder="Optional note" {...register('note')} />
          <FieldError message={errors.note?.message} />
        </div>
        <FieldError message={saveState.ok ? undefined : saveState.error} />
        <Button type="submit" className="w-full" size="lg" disabled={saving}>
          {saving ? 'Saving…' : initial ? 'Save changes' : 'Add transaction'}
        </Button>
      </form>
    </Dialog>
  )
}

function TypeSwitch({ register, value }: { register: ReturnType<typeof useForm<FormValues>>['register']; value: 'INCOME' | 'EXPENSE' }) {
  return (
    <div className="grid grid-cols-2 gap-2">
      {(['EXPENSE', 'INCOME'] as const).map((t) => (
        <label
          key={t}
          className={`flex min-h-[44px] cursor-pointer items-center justify-center gap-2 rounded-xl border text-[14px] font-medium transition-colors ${
            value === t ? 'border-accent/50 bg-accent/10 text-accent' : 'border-line/60 bg-surface text-muted'
          }`}
        >
          <input type="radio" value={t} className="sr-only" {...register('type')} />
          {t === 'EXPENSE' ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownLeft className="h-4 w-4" />}
          {t === 'EXPENSE' ? 'Expense' : 'Income'}
        </label>
      ))}
    </div>
  )
}
