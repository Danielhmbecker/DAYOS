'use client'

import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'

export type SeriesPoint = { month: string; income: number; expense: number }

export function MoneyChart({ data, currency }: { data: SeriesPoint[]; currency: string }) {
  return (
    <div className="h-52 w-full" aria-label="Income and spending by month">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} barGap={2} margin={{ top: 8, right: 0, left: -18, bottom: 0 }}>
          <CartesianGrid stroke="#1C2740" strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="month"
            tick={{ fill: '#8A97B1', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: '#5A6784', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v: number) => `£${v >= 1000 ? `${Math.round(v / 100) / 10}k` : v}`}
          />
          <Tooltip
            cursor={{ fill: 'rgba(56,189,248,0.06)' }}
            contentStyle={{
              background: '#0D1526',
              border: '1px solid #1C2740',
              borderRadius: 12,
              fontSize: 12,
              color: '#E8EEF9',
            }}
            labelStyle={{ color: '#8A97B1' }}
            formatter={(value) => [
              new Intl.NumberFormat('en-GB', { style: 'currency', currency }).format(Number(value)),
              undefined,
            ]}
          />
          <Legend wrapperStyle={{ fontSize: 11, color: '#8A97B1' }} />
          <Bar dataKey="income" name="Income" fill="#34D399" radius={[4, 4, 0, 0]} maxBarSize={18} />
          <Bar dataKey="expense" name="Spending" fill="#FB7185" radius={[4, 4, 0, 0]} maxBarSize={18} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
