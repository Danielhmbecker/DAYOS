'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'
import type { SeriesPoint } from './charts'

/**
 * Recharts is heavy (~130KB gzipped), so the chart is code-split and only
 * fetched in the browser when the Money overview tab actually renders it.
 */
const MoneyChartInner = dynamic(() => import('./charts').then((m) => m.MoneyChart), {
  ssr: false,
  loading: () => <Skeleton className="h-52 w-full" />,
})

export function MoneyChart({ data, currency }: { data: SeriesPoint[]; currency: string }) {
  return <MoneyChartInner data={data} currency={currency} />
}
