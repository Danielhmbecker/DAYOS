'use client'

import { useState, useActionState, useEffect, useRef } from 'react'
import { CheckCircle2, Pencil, Plus, ReceiptText, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { useToast } from '@/components/ui/toast'
import { deleteBillAction, payBillAction, saveBillAction } from '@/app/(app)/money/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatMoney, formatDate } from '@/lib/utils'

export type BillRow = {
  id: string
  name: string
  amount: number
  frequency: string
  nextDue: string
  days: number
  state: 'overdue' | 'soon' | 'scheduled'
}

export function BillsPanel({ bills, currency }: { bills: BillRow[]; currency: string }) {
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<BillRow | null>(null)
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const [payingId, setPayingId] = useState<string | null>(null)
  const { push } = useToast()

  return (
    <div className="space-y-3">
      <Button className="w-full" onClick={() => { setEditing(null); setOpen(true) }}>
        <Plus className="h-4 w-4" /> Add bill
      </Button>

      {bills.length === 0 ? (
        <EmptyState
          icon={ReceiptText}
          title="No bills tracked"
          description="Add rent, council tax, utilities and subscriptions — DAYOS tells you before they're due."
          action={<Button onClick={() => setOpen(true)}>Add a bill</Button>}
        />
      ) : (
        <Card>
          <CardContent className="pt-2">
            <ul className="divide-y divide-line/50">
              {bills.map((b) => (
                <li key={b.id} className="flex items-center gap-3 py-3">
                  <span
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                      b.state === 'overdue' ? 'bg-danger/15' : b.state === 'soon' ? 'bg-warning/15' : 'bg-elevate'
                    }`}
                  >
                    <ReceiptText className={`h-4 w-4 ${b.state === 'overdue' ? 'text-danger' : b.state === 'soon' ? 'text-warning' : 'text-muted'}`} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-medium text-ink">{b.name}</span>
                    <span className="block text-[12px] text-muted">
                      Due {formatDate(b.nextDue, 'short')} · {b.frequency.toLowerCase()}
                    </span>
                  </span>
                  <span className="text-[15px] font-semibold text-ink">{formatMoney(b.amount, currency)}</span>
                  <button
                    aria-label={`Mark ${b.name} paid`}
                    title="Mark paid (logs an expense)"
                    onClick={() => setPayingId(b.id)}
                    className="p-2 text-faint hover:text-success"
                  >
                    <CheckCircle2 className="h-4 w-4" />
                  </button>
                  <button aria-label={`Edit ${b.name}`} onClick={() => { setEditing(b); setOpen(true) }} className="p-2 text-faint hover:text-ink">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button aria-label={`Delete ${b.name}`} onClick={() => setConfirmId(b.id)} className="p-2 text-faint hover:text-danger">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {open && <BillDialog key={editing?.id ?? 'new'} initial={editing} onClose={() => setOpen(false)} />}

      <ConfirmDialog
        open={payingId !== null}
        onClose={() => setPayingId(null)}
        onConfirm={async () => {
          if (!payingId) return
          const res = await payBillAction(payingId)
          setPayingId(null)
          push(res.ok ? 'Marked paid — expense logged' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Mark bill paid"
        message="This logs an expense for the bill amount today and schedules the next occurrence."
        confirmLabel="Mark paid"
      />
      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteBillAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Bill deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete bill"
        message="Past expenses logged from this bill are kept."
      />
    </div>
  )
}

function BillDialog({ initial, onClose }: { initial: BillRow | null; onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveBillAction, { ok: true })
  const submitted = useRef(false)

  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push(initial ? 'Bill updated' : 'Bill added')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose, initial])

  return (
    <Dialog open onClose={onClose} title={initial ? 'Edit bill' : 'New bill'}>
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        {initial && <input type="hidden" name="id" value={initial.id} />}
        <div>
          <InputLabel htmlFor="bill-name">Name</InputLabel>
          <Input id="bill-name" name="name" defaultValue={initial?.name} placeholder="Rent" required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="bill-amount">Amount (£)</InputLabel>
            <Input id="bill-amount" name="amount" type="number" step="0.01" min="0.01" inputMode="decimal" defaultValue={initial?.amount} required />
          </div>
          <div>
            <InputLabel htmlFor="bill-freq">Repeats</InputLabel>
            <Select id="bill-freq" name="frequency" defaultValue={initial?.frequency ?? 'MONTHLY'}>
              <option value="MONTHLY">Monthly</option>
              <option value="WEEKLY">Weekly</option>
              <option value="YEARLY">Yearly</option>
              <option value="DAILY">Daily</option>
            </Select>
          </div>
        </div>
        <div>
          <InputLabel htmlFor="bill-due">Next due</InputLabel>
          <Input
            id="bill-due"
            name="nextDueDate"
            type="date"
            defaultValue={initial ? initial.nextDue.slice(0, 10) : new Date().toISOString().slice(0, 10)}
            required
          />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          {saving ? 'Saving…' : initial ? 'Save changes' : 'Add bill'}
        </Button>
      </form>
    </Dialog>
  )
}
