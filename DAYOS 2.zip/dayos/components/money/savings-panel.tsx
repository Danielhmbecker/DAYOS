'use client'

import { useState, useActionState, useEffect, useRef } from 'react'
import { Pencil, PiggyBank, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/components/ui/toast'
import { addToGoalAction, deleteGoalAction, saveGoalAction } from '@/app/(app)/money/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatDate, formatMoney } from '@/lib/utils'

export type GoalRow = {
  id: string
  name: string
  target: number
  saved: number
  deadline: string | null
  color: string
}

export function SavingsPanel({ goals, currency }: { goals: GoalRow[]; currency: string }) {
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<GoalRow | null>(null)
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const [topUp, setTopUp] = useState<GoalRow | null>(null)
  const { push } = useToast()

  return (
    <div className="space-y-3">
      <Button className="w-full" onClick={() => { setEditing(null); setOpen(true) }}>
        <Plus className="h-4 w-4" /> New savings goal
      </Button>

      {goals.length === 0 ? (
        <EmptyState
          icon={PiggyBank}
          title="No savings goals"
          description="Emergency fund, holiday, new gear — give every pound a mission."
          action={<Button onClick={() => setOpen(true)}>Create a goal</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {goals.map((g) => {
            const percent = g.target > 0 ? Math.min(100, Math.round((g.saved / g.target) * 100)) : 0
            return (
              <Card key={g.id}>
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between">
                    <div className="min-w-0">
                      <p className="truncate text-[15px] font-semibold text-ink">{g.name}</p>
                      <p className="text-[12px] text-muted">
                        {g.deadline ? `Target ${formatDate(g.deadline, 'short')}` : 'No deadline'}
                      </p>
                    </div>
                    <div className="flex shrink-0">
                      <button aria-label={`Edit ${g.name}`} onClick={() => { setEditing(g); setOpen(true) }} className="p-1.5 text-faint hover:text-ink">
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button aria-label={`Delete ${g.name}`} onClick={() => setConfirmId(g.id)} className="p-1.5 text-faint hover:text-danger">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  <p className="mt-3 text-[20px] font-bold" style={{ color: g.color }}>
                    {formatMoney(g.saved, currency)}
                    <span className="ml-1 text-[13px] font-medium text-muted">of {formatMoney(g.target, currency)}</span>
                  </p>
                  <Progress className="mt-2" value={percent} tone="success" />
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-[12px] font-semibold text-muted">{percent}%</span>
                    <Button size="sm" variant="secondary" onClick={() => setTopUp(g)}>
                      Add money
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      {open && <GoalDialog key={editing?.id ?? 'new'} initial={editing} onClose={() => setOpen(false)} />}
      {topUp && <TopUpDialog goal={topUp} onClose={() => setTopUp(null)} />}

      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteGoalAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Goal deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete savings goal"
        message="The goal and its progress are removed. Transactions are untouched."
      />
    </div>
  )
}

function GoalDialog({ initial, onClose }: { initial: GoalRow | null; onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveGoalAction, { ok: true })
  const submitted = useRef(false)

  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push(initial ? 'Goal updated' : 'Goal created')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose, initial])

  return (
    <Dialog open onClose={onClose} title={initial ? 'Edit goal' : 'New savings goal'}>
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        {initial && <input type="hidden" name="id" value={initial.id} />}
        <div>
          <InputLabel htmlFor="g-name">Name</InputLabel>
          <Input id="g-name" name="name" defaultValue={initial?.name} placeholder="Emergency fund" required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="g-target">Target (£)</InputLabel>
            <Input id="g-target" name="targetAmount" type="number" step="0.01" min="0.01" defaultValue={initial?.target} required />
          </div>
          <div>
            <InputLabel htmlFor="g-saved">Saved so far (£)</InputLabel>
            <Input id="g-saved" name="savedAmount" type="number" step="0.01" min="0" defaultValue={initial?.saved ?? 0} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="g-deadline">Deadline (optional)</InputLabel>
            <Input id="g-deadline" name="deadline" type="date" defaultValue={initial?.deadline?.slice(0, 10) ?? ''} />
          </div>
          <div>
            <InputLabel htmlFor="g-color">Colour</InputLabel>
            <Input id="g-color" name="color" type="color" defaultValue={initial?.color ?? '#34D399'} className="h-11 p-1.5" />
          </div>
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          {saving ? 'Saving…' : initial ? 'Save changes' : 'Create goal'}
        </Button>
      </form>
    </Dialog>
  )
}

function TopUpDialog({ goal, onClose }: { goal: GoalRow; onClose: () => void }) {
  const { push } = useToast()
  const [amount, setAmount] = useState('')
  const [busy, setBusy] = useState(false)

  return (
    <Dialog open onClose={onClose} title={`Add to ${goal.name}`}>
      <form
        onSubmit={async (e) => {
          e.preventDefault()
          setBusy(true)
          const res = await addToGoalAction(goal.id, parseFloat(amount))
          setBusy(false)
          if (res.ok) {
            push('Savings updated')
            onClose()
          } else push(res.error, 'error')
        }}
        className="space-y-4"
      >
        <div>
          <InputLabel htmlFor="topup">Amount (£)</InputLabel>
          <Input id="topup" type="number" step="0.01" min="0.01" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="50" required autoFocus />
        </div>
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? 'Saving…' : 'Add to goal'}
        </Button>
      </form>
    </Dialog>
  )
}
