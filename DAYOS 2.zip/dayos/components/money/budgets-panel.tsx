'use client'

import { useState, useActionState, useEffect, useRef } from 'react'
import { PieChart, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/components/ui/toast'
import { deleteBudgetAction, saveBudgetAction, saveCategoryAction } from '@/app/(app)/money/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatMoney } from '@/lib/utils'
import type { CategoryOption } from './transactions-panel'

export type BudgetRow = {
  id: string
  categoryId: string
  category: string
  color: string
  limit: number
  used: number
  percent: number
  over: boolean
}

export function BudgetsPanel({
  budgets,
  categories,
  currency,
}: {
  budgets: BudgetRow[]
  categories: CategoryOption[]
  currency: string
}) {
  const [open, setOpen] = useState(false)
  const [catOpen, setCatOpen] = useState(false)
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const { push } = useToast()
  const expenseCategories = categories.filter((c) => c.type === 'EXPENSE')

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Button className="flex-1" onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" /> Add budget
        </Button>
        <Button variant="secondary" onClick={() => setCatOpen(true)}>
          <Plus className="h-4 w-4" /> Category
        </Button>
      </div>

      {budgets.length === 0 ? (
        <EmptyState
          icon={PieChart}
          title="No budgets yet"
          description="Give each spending category a monthly limit and watch progress as you go."
          action={<Button onClick={() => setOpen(true)}>Create your first budget</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {budgets.map((b) => (
            <Card key={b.id}>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <p className="text-[15px] font-semibold text-ink">{b.category}</p>
                  <button aria-label={`Delete ${b.category} budget`} onClick={() => setConfirmId(b.id)} className="p-1.5 text-faint hover:text-danger">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <p className="mt-1 text-[13px] text-muted">
                  <span className={b.over ? 'font-semibold text-danger' : 'font-semibold text-ink'}>
                    {formatMoney(b.used, currency)}
                  </span>{' '}
                  of {formatMoney(b.limit, currency)}
                </p>
                <Progress className="mt-3" value={b.percent} tone={b.over ? 'danger' : b.percent > 80 ? 'warning' : 'success'} />
                <p className="mt-2 text-right text-[12px] text-muted">
                  {b.over ? `${formatMoney(b.used - b.limit, currency)} over` : `${formatMoney(b.limit - b.used, currency)} left`}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {open && <BudgetDialog categories={expenseCategories} budgetedIds={budgets.map((b) => b.categoryId)} onClose={() => setOpen(false)} />}
      {catOpen && <CategoryDialog onClose={() => setCatOpen(false)} />}

      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteBudgetAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Budget deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete budget"
        message="Transactions are kept — only the monthly limit is removed."
      />
    </div>
  )
}

function BudgetDialog({
  categories,
  budgetedIds,
  onClose,
}: {
  categories: CategoryOption[]
  budgetedIds: string[]
  onClose: () => void
}) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveBudgetAction, { ok: true })
  const submitted = useRef(false)
  const available = categories.filter((c) => !budgetedIds.includes(c.id))

  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push('Budget saved')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose])

  return (
    <Dialog open onClose={onClose} title="New monthly budget">
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        <div>
          <InputLabel htmlFor="b-cat">Category</InputLabel>
          <Select id="b-cat" name="categoryId" required defaultValue="">
            <option value="" disabled>
              Choose a category
            </option>
            {available.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
          {available.length === 0 && <p className="mt-1 text-[13px] text-muted">All expense categories already have budgets.</p>}
        </div>
        <div>
          <InputLabel htmlFor="b-limit">Monthly limit (£)</InputLabel>
          <Input id="b-limit" name="monthlyLimit" type="number" step="0.01" min="0.01" inputMode="decimal" placeholder="250" required />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving || available.length === 0}>
          {saving ? 'Saving…' : 'Save budget'}
        </Button>
      </form>
    </Dialog>
  )
}

function CategoryDialog({ onClose }: { onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveCategoryAction, { ok: true })
  const submitted = useRef(false)

  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push('Category created')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose])

  return (
    <Dialog open onClose={onClose} title="New category">
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        <div>
          <InputLabel htmlFor="c-name">Name</InputLabel>
          <Input id="c-name" name="name" placeholder="e.g. Subscriptions" required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="c-type">Type</InputLabel>
            <Select id="c-type" name="type" defaultValue="EXPENSE">
              <option value="EXPENSE">Expense</option>
              <option value="INCOME">Income</option>
            </Select>
          </div>
          <div>
            <InputLabel htmlFor="c-color">Colour</InputLabel>
            <Input id="c-color" name="color" type="color" defaultValue="#38BDF8" className="h-11 p-1.5" />
          </div>
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          {saving ? 'Saving…' : 'Create category'}
        </Button>
      </form>
    </Dialog>
  )
}
