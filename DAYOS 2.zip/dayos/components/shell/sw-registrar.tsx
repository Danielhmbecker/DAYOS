'use client'

import { useEffect } from 'react'

export function SwRegistrar() {
  useEffect(() => {
    if (!('serviceWorker' in navigator)) return
    if (process.env.NODE_ENV !== 'production') return // dev server + SW conflict
    navigator.serviceWorker.register('/sw.js').catch(() => {
      // offline support unavailable — app still works online
    })
  }, [])
  return null
}
