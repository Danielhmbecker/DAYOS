'use client'

import { useRef, useState, useActionState, useEffect } from 'react'
import { Plus, StickyNote, ListTodo, ArrowDownLeft, ArrowUpRight, CalendarPlus } from 'lucide-react'
import { Dialog } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { useToast } from '@/components/ui/toast'
import {
  quickNoteAction,
  quickTaskAction,
  quickMoneyAction,
  quickEventAction,
} from '@/lib/actions/quick'
import type { ActionResult } from '@/lib/actions/guard'

type Mode = 'expense' | 'income' | 'task' | 'note' | 'event'

const modes: { value: Mode; label: string; icon: typeof Plus }[] = [
  { value: 'expense', label: 'Expense', icon: ArrowUpRight },
  { value: 'income', label: 'Income', icon: ArrowDownLeft },
  { value: 'task', label: 'Task', icon: ListTodo },
  { value: 'note', label: 'Note', icon: StickyNote },
  { value: 'event', label: 'Event', icon: CalendarPlus },
]

function todayISO() {
  return new Date().toISOString().slice(0, 10)
}

export function QuickCapture({ categories }: { categories: { id: string; name: string; type: string }[] }) {
  const [open, setOpen] = useState(false)
  const [mode, setMode] = useState<Mode>('expense')
  const { push } = useToast()
  const submitted = useRef<Mode | null>(null)

  const [noteState, noteFormAction, notePending] = useActionState<ActionResult, FormData>(quickNoteAction, { ok: true })
  const [taskState, taskFormAction, taskPending] = useActionState<ActionResult, FormData>(quickTaskAction, { ok: true })
  const [moneyState, moneyFormAction, moneyPending] = useActionState<ActionResult, FormData>(quickMoneyAction, { ok: true })
  const [eventState, eventFormAction, eventPending] = useActionState<ActionResult, FormData>(quickEventAction, { ok: true })

  const stateFor: Record<Mode, [ActionResult, boolean]> = {
    note: [noteState, notePending],
    task: [taskState, taskPending],
    expense: [moneyState, moneyPending],
    income: [moneyState, moneyPending],
    event: [eventState, eventPending],
  }

  // After a submit settles: close on success, surface errors as toasts.
  useEffect(() => {
    if (!submitted.current) return
    const [state, pending] = stateFor[submitted.current]
    if (pending) return
    if (state.ok) {
      push('Saved', 'success')
      setOpen(false)
      submitted.current = null
    } else {
      push(state.error, 'error')
      submitted.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [noteState, taskState, moneyState, eventState, notePending, taskPending, moneyPending, eventPending])

  // Allow other components (dashboard quick actions) to open the sheet in a mode.
  useEffect(() => {
    const onOpen = (e: Event) => {
      const detail = (e as CustomEvent<string>).detail
      if (modes.some((m) => m.value === detail)) {
        setMode(detail as Mode)
        setOpen(true)
      }
    }
    window.addEventListener('dayos:quick-capture', onOpen)
    return () => window.removeEventListener('dayos:quick-capture', onOpen)
  }, [])

  const pending = notePending || taskPending || moneyPending || eventPending
  const expenseCategories = categories.filter((c) => c.type === 'EXPENSE')
  const incomeCategories = categories.filter((c) => c.type === 'INCOME')

  const submit = (m: Mode, action: (fd: FormData) => void) => (fd: FormData) => {
    submitted.current = m
    action(fd)
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label="Quick capture"
        className="fixed bottom-20 right-4 z-40 flex h-14 w-14 items-center justify-center rounded-2xl bg-accent-deep text-white shadow-glow transition-transform active:scale-95 md:bottom-8 md:right-8"
      >
        <Plus className="h-6 w-6" strokeWidth={2.5} />
      </button>
      <Dialog open={open} onClose={() => setOpen(false)} title="Quick capture">
        <div className="grid grid-cols-5 gap-1.5">
          {modes.map((m) => (
            <button
              key={m.value}
              onClick={() => setMode(m.value)}
              className={`flex min-h-[56px] flex-col items-center justify-center gap-1 rounded-xl border text-[11px] font-medium transition-colors ${
                mode === m.value
                  ? 'border-accent/50 bg-accent/10 text-accent'
                  : 'border-line/60 bg-surface text-muted hover:text-ink'
              }`}
            >
              <m.icon className="h-4 w-4" />
              {m.label}
            </button>
          ))}
        </div>

        <div className="mt-5">
          {mode === 'note' && (
            <form action={submit('note', noteFormAction)} className="space-y-4">
              <div>
                <InputLabel htmlFor="qc-note">Note</InputLabel>
                <Input id="qc-note" name="title" placeholder="Capture it before it escapes…" autoFocus required />
                <FieldError message={noteState.ok ? undefined : noteState.error} />
              </div>
              <Button type="submit" className="w-full" disabled={pending}>
                Save note
              </Button>
            </form>
          )}

          {mode === 'task' && (
            <form action={submit('task', taskFormAction)} className="space-y-4">
              <div>
                <InputLabel htmlFor="qc-task">Task</InputLabel>
                <Input id="qc-task" name="title" placeholder="What needs doing?" autoFocus required />
                <FieldError message={taskState.ok ? undefined : taskState.error} />
              </div>
              <div>
                <InputLabel htmlFor="qc-task-due">Due (optional)</InputLabel>
                <Input id="qc-task-due" name="dueDate" type="date" defaultValue={todayISO()} />
              </div>
              <Button type="submit" className="w-full" disabled={pending}>
                Add task
              </Button>
            </form>
          )}

          {(mode === 'expense' || mode === 'income') && (
            <form action={submit(mode, moneyFormAction)} className="space-y-4">
              <input type="hidden" name="type" value={mode === 'expense' ? 'EXPENSE' : 'INCOME'} />
              <div>
                <InputLabel htmlFor="qc-amount">Amount (£)</InputLabel>
                <Input
                  id="qc-amount"
                  name="amount"
                  type="number"
                  step="0.01"
                  min="0.01"
                  inputMode="decimal"
                  placeholder="0.00"
                  autoFocus
                  required
                />
              </div>
              <div>
                <InputLabel htmlFor="qc-cat">Category</InputLabel>
                <Select id="qc-cat" name="categoryId" defaultValue="">
                  <option value="">No category</option>
                  {(mode === 'expense' ? expenseCategories : incomeCategories).map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <InputLabel htmlFor="qc-money-note">Note (optional)</InputLabel>
                <Input id="qc-money-note" name="note" placeholder="e.g. Lunch with team" />
                <FieldError message={moneyState.ok ? undefined : moneyState.error} />
              </div>
              <Button type="submit" className="w-full" disabled={pending}>
                {mode === 'expense' ? 'Log expense' : 'Log income'}
              </Button>
            </form>
          )}

          {mode === 'event' && (
            <form action={submit('event', eventFormAction)} className="space-y-4">
              <div>
                <InputLabel htmlFor="qc-event">Event</InputLabel>
                <Input id="qc-event" name="title" placeholder="What's happening?" autoFocus required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <InputLabel htmlFor="qc-event-date">Date</InputLabel>
                  <Input id="qc-event-date" name="date" type="date" defaultValue={todayISO()} required />
                </div>
                <div>
                  <InputLabel htmlFor="qc-event-time">Time</InputLabel>
                  <Input id="qc-event-time" name="startTime" type="time" defaultValue="09:00" required />
                </div>
              </div>
              <FieldError message={eventState.ok ? undefined : eventState.error} />
              <Button type="submit" className="w-full" disabled={pending}>
                Add event
              </Button>
            </form>
          )}
        </div>
        <p className="mt-4 text-center text-[12px] text-faint">
          Quick capture saves in one tap — full editors live in each module.
        </p>
      </Dialog>
    </>
  )
}
