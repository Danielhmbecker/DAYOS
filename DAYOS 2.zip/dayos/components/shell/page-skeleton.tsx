import { CardSkeleton, ListSkeleton, Skeleton } from '@/components/ui/skeleton'

/**
 * Route-level loading fallback shown instantly while a page's server data
 * streams in. Having a loading boundary also lets the App Router prefetch
 * the shell of dynamic routes, so navigations feel immediate.
 */
export function PageSkeleton({ cards = 0, rows = 0 }: { cards?: number; rows?: number }) {
  return (
    <div aria-busy="true">
      <div className="mb-5 flex items-end justify-between gap-3">
        <div>
          <Skeleton className="h-7 w-44" />
          <Skeleton className="mt-2 h-3 w-28" />
        </div>
        <Skeleton className="h-9 w-9" />
      </div>
      {cards > 0 && (
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {Array.from({ length: cards }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}
      {rows > 0 && (
        <div className={cards > 0 ? 'mt-4' : undefined}>
          <ListSkeleton rows={rows} />
        </div>
      )}
      <span className="sr-only">Loading…</span>
    </div>
  )
}
