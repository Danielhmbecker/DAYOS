'use client'

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { Bell, ReceiptText, ListTodo, Package, Sparkles, CalendarClock } from 'lucide-react'
import type { Alert } from '@/lib/services/notifications'

const kindIcon = {
  bill: ReceiptText,
  task: ListTodo,
  stock: Package,
  cleaning: Sparkles,
  event: CalendarClock,
} as const

export function NotificationsMenu({ alerts }: { alerts: Alert[] }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [])

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label={`Notifications (${alerts.length})`}
        aria-expanded={open}
        className="relative flex h-9 w-9 items-center justify-center rounded-xl text-muted hover:bg-elevate hover:text-ink"
      >
        <Bell className="h-5 w-5" />
        {alerts.length > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-pill bg-danger px-1 text-[10px] font-bold text-white">
            {alerts.length}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute right-0 top-11 z-50 w-80 overflow-hidden rounded-2xl border border-line bg-card shadow-sheet animate-scale-in">
          <div className="border-b border-line/60 px-4 py-3 text-[13px] font-semibold uppercase tracking-wider text-muted">
            Needs attention
          </div>
          {alerts.length === 0 ? (
            <p className="px-4 py-6 text-center text-[14px] text-muted">All clear. Nothing needs you right now.</p>
          ) : (
            <ul className="max-h-80 overflow-y-auto">
              {alerts.map((a) => {
                const Icon = kindIcon[a.kind]
                return (
                  <li key={a.id}>
                    <Link
                      href={a.href}
                      onClick={() => setOpen(false)}
                      className="flex items-start gap-3 px-4 py-3 hover:bg-elevate/60"
                    >
                      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                      <span className="min-w-0">
                        <span className="block truncate text-[14px] font-medium text-ink">{a.title}</span>
                        <span className="block truncate text-[12px] text-muted">{a.detail}</span>
                      </span>
                    </Link>
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}
