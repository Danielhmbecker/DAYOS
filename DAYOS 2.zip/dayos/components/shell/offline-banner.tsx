'use client'

import { useEffect, useState } from 'react'
import { WifiOff } from 'lucide-react'

export function OfflineBanner() {
  const [offline, setOffline] = useState(false)

  useEffect(() => {
    const update = () => setOffline(!navigator.onLine)
    update()
    window.addEventListener('online', update)
    window.addEventListener('offline', update)
    return () => {
      window.removeEventListener('online', update)
      window.removeEventListener('offline', update)
    }
  }, [])

  if (!offline) return null
  return (
    <div
      role="status"
      className="safe-top fixed inset-x-0 top-0 z-[70] flex items-center justify-center gap-2 bg-warning/90 px-4 py-1.5 text-[13px] font-semibold text-black"
    >
      <WifiOff className="h-3.5 w-3.5" /> You're offline — showing cached content
    </div>
  )
}
