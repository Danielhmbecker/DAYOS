'use client'

import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { LogOut, Settings, User as UserIcon } from 'lucide-react'
import { logoutAction } from '@/lib/actions/auth'

export function UserMenu({ name, email }: { name: string; email: string }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const router = useRouter()

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [])

  const initials = name
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="Account menu"
        aria-expanded={open}
        className="flex h-9 w-9 items-center justify-center rounded-full bg-accent-deep/25 text-[13px] font-bold text-accent ring-1 ring-accent/30"
      >
        {initials || <UserIcon className="h-4 w-4" />}
      </button>
      {open && (
        <div className="absolute right-0 top-11 z-50 w-56 overflow-hidden rounded-2xl border border-line bg-card shadow-sheet animate-scale-in">
          <div className="border-b border-line/60 px-4 py-3">
            <p className="truncate text-[14px] font-semibold text-ink">{name}</p>
            <p className="truncate text-[12px] text-muted">{email}</p>
          </div>
          <button
            onClick={() => router.push('/settings')}
            className="flex w-full items-center gap-2.5 px-4 py-3 text-left text-[14px] text-ink hover:bg-elevate/60"
          >
            <Settings className="h-4 w-4 text-muted" /> Settings
          </button>
          <form
            action={logoutAction}
            onSubmit={() => setOpen(false)}
          >
            <button
              type="submit"
              className="flex w-full items-center gap-2.5 px-4 py-3 text-left text-[14px] text-danger hover:bg-elevate/60"
            >
              <LogOut className="h-4 w-4" /> Sign out
            </button>
          </form>
        </div>
      )}
    </div>
  )
}
