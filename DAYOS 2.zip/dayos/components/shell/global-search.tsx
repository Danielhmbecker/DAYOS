'use client'

import { useEffect, useRef, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { Search, X } from 'lucide-react'
import { searchAction } from '@/lib/actions/search'
import type { SearchHit } from '@/lib/services/search'

export function GlobalSearch() {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [hits, setHits] = useState<SearchHit[]>([])
  const [pending, startTransition] = useTransition()
  const inputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  useEffect(() => {
    if (!open) return
    inputRef.current?.focus()
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open])

  useEffect(() => {
    if (query.trim().length < 2) {
      setHits([])
      return
    }
    const t = setTimeout(() => {
      startTransition(async () => {
        setHits(await searchAction(query))
      })
    }, 200)
    return () => clearTimeout(t)
  }, [query])

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label="Search DAYOS"
        className="flex h-9 items-center gap-2 rounded-xl border border-line/70 bg-surface px-3 text-[14px] text-faint hover:text-muted"
      >
        <Search className="h-4 w-4" />
        <span className="hidden sm:inline">Search…</span>
      </button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-start justify-center px-4 pt-24" role="dialog" aria-modal="true" aria-label="Global search">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in" onClick={() => setOpen(false)} />
          <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-line bg-card shadow-sheet animate-scale-in">
            <div className="flex items-center gap-2 border-b border-line/60 px-4">
              <Search className="h-4 w-4 shrink-0 text-muted" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search notes, tasks, money, events, documents…"
                className="h-12 w-full bg-transparent text-[15px] text-ink placeholder:text-faint focus:outline-none"
              />
              <button onClick={() => setOpen(false)} aria-label="Close search" className="text-muted hover:text-ink">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="max-h-96 overflow-y-auto">
              {query.trim().length < 2 ? (
                <p className="px-4 py-6 text-center text-[14px] text-muted">Type at least 2 characters.</p>
              ) : pending ? (
                <p className="px-4 py-6 text-center text-[14px] text-muted">Searching…</p>
              ) : hits.length === 0 ? (
                <p className="px-4 py-6 text-center text-[14px] text-muted">No results for "{query}".</p>
              ) : (
                <ul>
                  {hits.map((h, i) => (
                    <li key={i}>
                      <button
                        onClick={() => {
                          setOpen(false)
                          setQuery('')
                          router.push(h.href)
                        }}
                        className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-elevate/60"
                      >
                        <span className="w-20 shrink-0 text-[11px] font-semibold uppercase tracking-wide text-accent">
                          {h.type}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[14px] text-ink">{h.title}</span>
                          {h.subtitle && <span className="block truncate text-[12px] text-muted">{h.subtitle}</span>}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}
