'use client'

import { Check } from 'lucide-react'
import { cn } from '@/lib/utils'

export function Checkbox({
  checked,
  onChange,
  label,
}: {
  checked: boolean
  onChange: (checked: boolean) => void
  label?: string
}) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        'flex h-6 w-6 shrink-0 items-center justify-center rounded-md border transition-colors',
        checked ? 'border-accent-deep bg-accent-deep text-white' : 'border-line bg-surface',
      )}
    >
      {checked && <Check className="h-4 w-4" strokeWidth={3} />}
    </button>
  )
}
