import { forwardRef, type TextareaHTMLAttributes } from 'react'
import { cn } from '@/lib/utils'

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(
  function Textarea({ className, rows = 4, ...props }, ref) {
    return (
      <textarea
        ref={ref}
        rows={rows}
        className={cn(
          'w-full rounded-xl border border-line bg-surface px-3.5 py-3 text-[15px] text-ink',
          'placeholder:text-faint focus:border-accent/60 focus:outline-none focus:ring-2 focus:ring-accent/20',
          'transition-colors disabled:opacity-50 resize-y',
          className,
        )}
        {...props}
      />
    )
  },
)
