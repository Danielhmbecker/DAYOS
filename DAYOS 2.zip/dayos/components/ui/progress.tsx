import { cn } from '@/lib/utils'

export function Progress({
  value,
  tone = 'accent',
  className,
}: {
  value: number
  tone?: 'accent' | 'success' | 'warning' | 'danger'
  className?: string
}) {
  const clamped = Math.max(0, Math.min(100, value))
  const tones = {
    accent: 'bg-accent',
    success: 'bg-success',
    warning: 'bg-warning',
    danger: 'bg-danger',
  } as const
  return (
    <div
      role="progressbar"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
      className={cn('h-1.5 w-full overflow-hidden rounded-pill bg-elevate', className)}
    >
      <div
        className={cn('h-full rounded-pill transition-all duration-500', tones[tone])}
        style={{ width: `${clamped}%` }}
      />
    </div>
  )
}
