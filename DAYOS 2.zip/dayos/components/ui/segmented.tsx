'use client'

import { cn } from '@/lib/utils'

export type SegmentOption<T extends string> = { value: T; label: string }

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className,
}: {
  options: SegmentOption<T>[]
  value: T
  onChange: (value: T) => void
  className?: string
}) {
  return (
    <div
      role="tablist"
      className={cn('flex gap-1 rounded-xl bg-surface border border-line/60 p-1', className)}
    >
      {options.map((opt) => (
        <button
          key={opt.value}
          role="tab"
          aria-selected={opt.value === value}
          onClick={() => onChange(opt.value)}
          className={cn(
            'flex-1 h-9 rounded-lg text-[13px] font-medium transition-colors min-w-0 truncate px-2',
            opt.value === value ? 'bg-elevate text-ink shadow-card' : 'text-muted hover:text-ink',
          )}
        >
          {opt.label}
        </button>
      ))}
    </div>
  )
}
