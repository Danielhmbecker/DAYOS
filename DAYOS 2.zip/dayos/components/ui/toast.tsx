'use client'

import { createContext, useCallback, useContext, useState, type ReactNode } from 'react'
import { CheckCircle2, AlertTriangle, Info } from 'lucide-react'
import { cn } from '@/lib/utils'

type Toast = { id: number; message: string; tone: 'success' | 'error' | 'info' }

const ToastContext = createContext<{ push: (message: string, tone?: Toast['tone']) => void }>({
  push: () => {},
})

export function useToast() {
  return useContext(ToastContext)
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])

  const push = useCallback((message: string, tone: Toast['tone'] = 'success') => {
    const id = Date.now() + Math.random()
    setToasts((t) => [...t, { id, message, tone }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200)
  }, [])

  return (
    <ToastContext.Provider value={{ push }}>
      {children}
      <div
        aria-live="polite"
        className="pointer-events-none fixed inset-x-0 bottom-24 z-[60] flex flex-col items-center gap-2 px-4 pb-[env(safe-area-inset-bottom)]"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            className={cn(
              'pointer-events-auto flex max-w-sm items-center gap-2 rounded-xl border px-4 py-3 text-[14px] shadow-sheet animate-slide-up',
              t.tone === 'success' && 'border-success/30 bg-card text-ink',
              t.tone === 'error' && 'border-danger/40 bg-card text-ink',
              t.tone === 'info' && 'border-line bg-card text-ink',
            )}
          >
            {t.tone === 'success' && <CheckCircle2 className="h-4 w-4 shrink-0 text-success" />}
            {t.tone === 'error' && <AlertTriangle className="h-4 w-4 shrink-0 text-danger" />}
            {t.tone === 'info' && <Info className="h-4 w-4 shrink-0 text-accent" />}
            <span className="truncate">{t.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}
