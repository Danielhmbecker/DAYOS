import { forwardRef, type InputHTMLAttributes } from 'react'
import { cn } from '@/lib/utils'

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...props }, ref) {
    return (
      <input
        ref={ref}
        className={cn(
          'h-11 w-full rounded-xl border border-line bg-surface px-3.5 text-[15px] text-ink',
          'placeholder:text-faint focus:border-accent/60 focus:outline-none focus:ring-2 focus:ring-accent/20',
          'transition-colors disabled:opacity-50',
          className,
        )}
        {...props}
      />
    )
  },
)

export const InputLabel = ({ htmlFor, children }: { htmlFor?: string; children: React.ReactNode }) => (
  <label htmlFor={htmlFor} className="mb-1.5 block text-[13px] font-medium text-muted">
    {children}
  </label>
)

export function FieldError({ message }: { message?: string }) {
  if (!message) return null
  return <p className="mt-1 text-[13px] text-danger">{message}</p>
}
