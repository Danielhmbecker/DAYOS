'use client'

import { useState, useActionState, useEffect, useRef } from 'react'
import { Briefcase, Pencil, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { useToast } from '@/components/ui/toast'
import { deleteShiftAction, saveShiftAction } from '@/app/(app)/work/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatMoney, formatTime } from '@/lib/utils'
import { hoursLabel } from '@/lib/calc/schedule'

export type ShiftRow = {
  id: string
  date: string
  start: string
  end: string
  breakMinutes: number
  locationName: string | null
  role: string | null
  notes: string | null
  workedMinutes: number
  overtimeMinutes: number
  pay: number
  isToday: boolean
}

export type LocationOption = { id: string; name: string; role: string | null }

export function ShiftsPanel({
  shifts,
  locations,
  currency,
}: {
  shifts: ShiftRow[]
  locations: LocationOption[]
  currency: string
}) {
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<ShiftRow | null>(null)
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const { push } = useToast()

  return (
    <div className="space-y-3">
      <Button className="w-full" onClick={() => { setEditing(null); setOpen(true) }}>
        <Plus className="h-4 w-4" /> Add shift
      </Button>

      {shifts.length === 0 ? (
        <EmptyState
          icon={Briefcase}
          title="No shifts this month"
          description="Add a shift and DAYOS works out hours, overtime and estimated pay automatically."
          action={<Button onClick={() => setOpen(true)}>Add a shift</Button>}
        />
      ) : (
        <Card>
          <CardContent className="pt-2">
            <ul className="divide-y divide-line/50">
              {shifts.map((s) => (
                <li key={s.id} className="flex items-center gap-3 py-3">
                  <span className={`flex h-10 w-10 shrink-0 flex-col items-center justify-center rounded-xl text-[10px] font-bold uppercase ${s.isToday ? 'bg-accent/15 text-accent' : 'bg-elevate text-muted'}`}>
                    {new Date(s.date).toLocaleDateString('en-GB', { day: '2-digit' })}
                    {new Date(s.date).toLocaleDateString('en-GB', { month: 'short' })}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-medium text-ink">
                      {formatTime(s.start)} → {new Date(s.end) <= new Date(s.start) ? 'Close' : formatTime(s.end)}
                      {s.locationName ? ` · ${s.locationName}` : ''}
                    </span>
                    <span className="block text-[12px] text-muted">
                      {hoursLabel(s.workedMinutes)}
                      {s.overtimeMinutes > 0 && <span className="text-warning"> +{hoursLabel(s.overtimeMinutes)} OT</span>}
                      {s.breakMinutes > 0 && ` · ${s.breakMinutes}m break`}
                    </span>
                  </span>
                  <span className="text-[14px] font-semibold text-ink">{formatMoney(s.pay, currency)}</span>
                  <button aria-label="Edit shift" onClick={() => { setEditing(s); setOpen(true) }} className="p-2 text-faint hover:text-ink">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button aria-label="Delete shift" onClick={() => setConfirmId(s.id)} className="p-2 text-faint hover:text-danger">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {open && <ShiftDialog key={editing?.id ?? 'new'} initial={editing} locations={locations} onClose={() => setOpen(false)} />}

      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteShiftAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Shift deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete shift"
        message="The shift and its pay estimate are removed."
      />
    </div>
  )
}

function ShiftDialog({
  initial,
  locations,
  onClose,
}: {
  initial: ShiftRow | null
  locations: LocationOption[]
  onClose: () => void
}) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveShiftAction, { ok: true })
  const submitted = useRef(false)

  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push(initial ? 'Shift updated' : 'Shift added')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose, initial])

  return (
    <Dialog open onClose={onClose} title={initial ? 'Edit shift' : 'New shift'}>
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        {initial && <input type="hidden" name="id" value={initial.id} />}
        <div>
          <InputLabel htmlFor="s-date">Date</InputLabel>
          <Input id="s-date" name="date" type="date" defaultValue={initial ? initial.date.slice(0, 10) : new Date().toISOString().slice(0, 10)} required />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <InputLabel htmlFor="s-start">Start</InputLabel>
            <Input id="s-start" name="startTime" type="time" defaultValue={initial ? initial.start.slice(11, 16) : '17:00'} required />
          </div>
          <div>
            <InputLabel htmlFor="s-end">End</InputLabel>
            <Input id="s-end" name="endTime" type="time" defaultValue={initial ? initial.end.slice(11, 16) : '23:00'} required />
          </div>
          <div>
            <InputLabel htmlFor="s-break">Break (min)</InputLabel>
            <Input id="s-break" name="breakMinutes" type="number" min="0" max="720" defaultValue={initial?.breakMinutes ?? 0} />
          </div>
        </div>
        <p className="text-[12px] text-faint">End times at or before the start time mean the shift runs to close (past midnight).</p>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <InputLabel htmlFor="s-loc">Location</InputLabel>
            <Select id="s-loc" name="locationId" defaultValue={locations.find((l) => l.name === initial?.locationName)?.id ?? ''}>
              <option value="">No location</option>
              {locations.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <InputLabel htmlFor="s-role">Role</InputLabel>
            <Input id="s-role" name="role" defaultValue={initial?.role ?? ''} placeholder="Duty Manager" />
          </div>
        </div>
        <div>
          <InputLabel htmlFor="s-notes">Notes</InputLabel>
          <Input id="s-notes" name="notes" defaultValue={initial?.notes ?? ''} placeholder="Optional" />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          {saving ? 'Saving…' : initial ? 'Save changes' : 'Add shift'}
        </Button>
      </form>
    </Dialog>
  )
}
