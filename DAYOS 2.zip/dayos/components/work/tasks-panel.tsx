'use client'

import { useState, useActionState, useEffect, useRef } from 'react'
import { ClipboardList, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { useToast } from '@/components/ui/toast'
import { deleteWorkTaskAction, saveWorkTaskAction, toggleWorkTaskAction } from '@/app/(app)/work/actions'
import type { ActionResult } from '@/lib/actions/guard'

export type WorkTaskRow = { id: string; title: string; done: boolean; locationName: string | null }

export function WorkTasksPanel({ tasks }: { tasks: WorkTaskRow[] }) {
  const [open, setOpen] = useState(false)
  const { push } = useToast()
  const remaining = tasks.filter((t) => !t.done).length

  return (
    <div className="space-y-3">
      <Button variant="secondary" className="w-full" onClick={() => setOpen(true)}>
        <Plus className="h-4 w-4" /> Add work task
      </Button>
      {tasks.length === 0 ? (
        <EmptyState icon={ClipboardList} title="No work tasks" description="Line checks, stock counts, training — keep shift chores here." />
      ) : (
        <Card>
          <CardContent className="pt-2">
            <p className="py-2 text-[12px] font-semibold uppercase tracking-wider text-muted">
              {remaining} remaining
            </p>
            <ul className="divide-y divide-line/50">
              {tasks.map((t) => (
                <li key={t.id} className="flex items-center gap-3 py-3">
                  <Checkbox
                    checked={t.done}
                    label={t.title}
                    onChange={async (done) => {
                      const res = await toggleWorkTaskAction(t.id, done)
                      if (!res.ok) push(res.error, 'error')
                    }}
                  />
                  <span className={`min-w-0 flex-1 truncate text-[14px] ${t.done ? 'text-faint line-through' : 'text-ink'}`}>
                    {t.title}
                    {t.locationName && <span className="ml-2 text-[12px] text-muted">{t.locationName}</span>}
                  </span>
                  <button
                    aria-label={`Delete ${t.title}`}
                    onClick={async () => {
                      const res = await deleteWorkTaskAction(t.id)
                      push(res.ok ? 'Task deleted' : res.error, res.ok ? 'success' : 'error')
                    }}
                    className="p-2 text-faint hover:text-danger"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
      {open && <WorkTaskDialog onClose={() => setOpen(false)} />}
    </div>
  )
}

function WorkTaskDialog({ onClose }: { onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(saveWorkTaskAction, { ok: true })
  const submitted = useRef(false)

  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push('Task added')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose])

  return (
    <Dialog open onClose={onClose} title="New work task">
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        <div>
          <InputLabel htmlFor="wt-title">Task</InputLabel>
          <Input id="wt-title" name="title" placeholder="Complete line checks" required autoFocus />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          {saving ? 'Saving…' : 'Add task'}
        </Button>
      </form>
    </Dialog>
  )
}
