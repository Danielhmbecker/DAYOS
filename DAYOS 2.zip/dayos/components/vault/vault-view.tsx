'use client'

import { useMemo, useState, useActionState, useEffect, useRef } from 'react'
import { Download, FileText, FolderLock, Pencil, Plus, Trash2, Upload } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Dialog } from '@/components/ui/dialog'
import { EmptyState } from '@/components/ui/empty-state'
import { Input, InputLabel, FieldError } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { useToast } from '@/components/ui/toast'
import { deleteDocumentAction, updateDocumentAction, uploadDocumentAction } from '@/app/(app)/vault/actions'
import type { ActionResult } from '@/lib/actions/guard'
import { formatDate } from '@/lib/utils'

export type DocumentRow = {
  id: string
  name: string
  mime: string
  size: string
  category: string
  tags: string[]
  uploadedAt: string
  description: string | null
}

export const CATEGORIES = [
  { id: 'PERSONAL', label: 'Personal' },
  { id: 'FINANCE', label: 'Finance' },
  { id: 'HOUSING', label: 'Housing' },
  { id: 'WORK', label: 'Work' },
  { id: 'EDUCATION', label: 'Education' },
  { id: 'RECEIPTS', label: 'Receipts' },
  { id: 'OTHER', label: 'Other' },
]

export function VaultView({ documents }: { documents: DocumentRow[] }) {
  const [category, setCategory] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [uploadOpen, setUploadOpen] = useState(false)
  const [editing, setEditing] = useState<DocumentRow | null>(null)
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const { push } = useToast()

  const filtered = useMemo(
    () =>
      documents.filter(
        (d) =>
          (!category || d.category === category) &&
          (search.trim() === '' || d.name.toLowerCase().includes(search.toLowerCase())),
      ),
    [documents, category, search],
  )

  const counts = useMemo(() => {
    const map = new Map<string, number>()
    for (const d of documents) map.set(d.category, (map.get(d.category) ?? 0) + 1)
    return map
  }, [documents])

  return (
    <div className="space-y-3">
      <Button className="w-full" onClick={() => setUploadOpen(true)}>
        <Upload className="h-4 w-4" /> Upload document
      </Button>

      <div className="grid grid-cols-4 gap-2 sm:grid-cols-7">
        <button
          onClick={() => setCategory(null)}
          className={`flex min-h-[64px] flex-col items-center justify-center gap-1 rounded-tile border p-2 text-[11px] font-medium ${
            category === null ? 'border-accent/50 bg-accent/10 text-accent' : 'border-line/60 bg-surface text-muted'
          }`}
        >
          <FolderLock className="h-4 w-4" />
          All
        </button>
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setCategory(category === c.id ? null : c.id)}
            className={`flex min-h-[64px] flex-col items-center justify-center gap-1 rounded-tile border p-2 text-[11px] font-medium ${
              category === c.id ? 'border-accent/50 bg-accent/10 text-accent' : 'border-line/60 bg-surface text-muted'
            }`}
          >
            <FolderLock className="h-4 w-4" />
            {c.label}
            <span className="text-[10px] text-faint">{counts.get(c.id) ?? 0}</span>
          </button>
        ))}
      </div>

      <Input placeholder="Search documents…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search documents" />

      {filtered.length === 0 ? (
        <EmptyState
          icon={FolderLock}
          title="Vault is empty"
          description="PDFs, scans and receipts — encrypted-at-rest on your storage, metadata in your database."
          action={<Button onClick={() => setUploadOpen(true)}><Plus className="h-4 w-4" /> Upload your first document</Button>}
        />
      ) : (
        <Card>
          <CardContent className="pt-2">
            <ul className="divide-y divide-line/50">
              {filtered.map((d) => (
                <li key={d.id} className="flex items-center gap-3 py-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-elevate">
                    <FileText className="h-4 w-4 text-accent" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-medium text-ink">{d.name}</span>
                    <span className="block truncate text-[12px] text-muted">
                      {d.size} · {CATEGORIES.find((c) => c.id === d.category)?.label ?? d.category} ·{' '}
                      {formatDate(d.uploadedAt, 'short')}
                      {d.tags.length > 0 && ` · ${d.tags.map((t) => `#${t}`).join(' ')}`}
                    </span>
                  </span>
                  <a
                    href={`/api/documents/${d.id}`}
                    aria-label={`Download ${d.name}`}
                    className="p-2 text-faint hover:text-accent"
                  >
                    <Download className="h-4 w-4" />
                  </a>
                  <button aria-label={`Edit ${d.name}`} onClick={() => setEditing(d)} className="p-2 text-faint hover:text-ink">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button aria-label={`Delete ${d.name}`} onClick={() => setConfirmId(d.id)} className="p-2 text-faint hover:text-danger">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {uploadOpen && <UploadDialog onClose={() => setUploadOpen(false)} />}
      {editing && <MetaDialog key={editing.id} initial={editing} onClose={() => setEditing(null)} />}

      <ConfirmDialog
        open={confirmId !== null}
        onClose={() => setConfirmId(null)}
        onConfirm={async () => {
          if (!confirmId) return
          const res = await deleteDocumentAction(confirmId)
          setConfirmId(null)
          push(res.ok ? 'Document deleted' : res.error, res.ok ? 'success' : 'error')
        }}
        title="Delete document"
        message="The file and its metadata are permanently removed from storage."
      />
    </div>
  )
}

function UploadDialog({ onClose }: { onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(uploadDocumentAction, { ok: true })
  const submitted = useRef(false)
  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push('Document uploaded')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose])

  return (
    <Dialog open onClose={onClose} title="Upload document">
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        <div>
          <InputLabel htmlFor="v-file">File (max 10 MB)</InputLabel>
          <Input id="v-file" name="file" type="file" required className="py-2.5" />
          <p className="mt-1 text-[12px] text-faint">PDF, images, Office documents and plain text are allowed.</p>
        </div>
        <div>
          <InputLabel htmlFor="v-name">Display name</InputLabel>
          <Input id="v-name" name="name" placeholder="Tenancy agreement" />
        </div>
        <div>
          <InputLabel htmlFor="v-cat">Folder</InputLabel>
          <Select id="v-cat" name="category" defaultValue="PERSONAL">
            {CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {c.label}
              </option>
            ))}
          </Select>
        </div>
        <div>
          <InputLabel htmlFor="v-tags">Tags (comma separated)</InputLabel>
          <Input id="v-tags" name="tags" placeholder="flat, 2026" />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" size="lg" disabled={saving}>
          {saving ? 'Uploading…' : 'Upload'}
        </Button>
      </form>
    </Dialog>
  )
}

function MetaDialog({ initial, onClose }: { initial: DocumentRow; onClose: () => void }) {
  const { push } = useToast()
  const [state, action, saving] = useActionState<ActionResult, FormData>(updateDocumentAction, { ok: true })
  const submitted = useRef(false)
  useEffect(() => {
    if (!submitted.current || saving) return
    submitted.current = false
    if (state.ok) {
      push('Document updated')
      onClose()
    } else push(state.error, 'error')
  }, [state, saving, push, onClose])

  return (
    <Dialog open onClose={onClose} title="Edit document">
      <form
        action={(fd) => {
          submitted.current = true
          action(fd)
        }}
        className="space-y-4"
      >
        <input type="hidden" name="id" value={initial.id} />
        <div>
          <InputLabel htmlFor="vd-name">Display name</InputLabel>
          <Input id="vd-name" name="name" defaultValue={initial.name} required />
        </div>
        <div>
          <InputLabel htmlFor="vd-cat">Folder</InputLabel>
          <Select id="vd-cat" name="category" defaultValue={initial.category}>
            {CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {c.label}
              </option>
            ))}
          </Select>
        </div>
        <div>
          <InputLabel htmlFor="vd-tags">Tags</InputLabel>
          <Input id="vd-tags" name="tags" defaultValue={initial.tags.join(', ')} />
        </div>
        <div>
          <InputLabel htmlFor="vd-desc">Description</InputLabel>
          <Input id="vd-desc" name="description" defaultValue={initial.description ?? ''} />
        </div>
        <FieldError message={state.ok ? undefined : state.error} />
        <Button type="submit" className="w-full" disabled={saving}>
          Save changes
        </Button>
      </form>
    </Dialog>
  )
}
