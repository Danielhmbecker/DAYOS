import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises'
import path from 'node:path'
import type { StorageDriver, StoredObject } from './index'

/**
 * Stores documents on the local filesystem (an OpenShift Persistent Volume in
 * production). Keys are relative paths; traversal outside the root is blocked.
 */
export class LocalStorageDriver implements StorageDriver {
  readonly name = 'local'
  private root: string

  constructor(dataDir: string) {
    this.root = path.resolve(dataDir, 'documents')
  }

  private resolve(key: string): string {
    const target = path.resolve(this.root, key)
    if (!target.startsWith(this.root + path.sep)) {
      throw new Error('Invalid storage key')
    }
    return target
  }

  async put(key: string, bytes: Buffer, _mime: string): Promise<void> {
    const target = this.resolve(key)
    await mkdir(path.dirname(target), { recursive: true })
    await writeFile(target, bytes)
  }

  async get(key: string): Promise<StoredObject | null> {
    try {
      const bytes = await readFile(this.resolve(key))
      return { key, bytes, mime: 'application/octet-stream', name: path.basename(key) }
    } catch {
      return null
    }
  }

  async remove(key: string): Promise<void> {
    try {
      await unlink(this.resolve(key))
    } catch {
      // already gone — treat as success
    }
  }
}
