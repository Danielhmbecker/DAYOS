/**
 * Pluggable storage layer for Vault documents.
 *
 * Metadata lives in PostgreSQL; binaries live behind this interface so the
 * driver can change (local persistent volume → S3-compatible object store)
 * without touching application code.
 *
 * Drivers:
 *  - local  (default) — files under $DATA_DIR/documents on a persistent volume
 *  - s3     — future driver; implement StorageDriver and register below
 */
export type StoredObject = {
  key: string
  bytes: Buffer
  mime: string
  name: string
}

export interface StorageDriver {
  readonly name: string
  put(key: string, bytes: Buffer, mime: string): Promise<void>
  get(key: string): Promise<StoredObject | null>
  remove(key: string): Promise<void>
}

import { LocalStorageDriver } from './local'

let driver: StorageDriver | null = null

export function storage(): StorageDriver {
  if (driver) return driver
  const kind = process.env.STORAGE_DRIVER ?? 'local'
  if (kind === 'local') {
    driver = new LocalStorageDriver(process.env.DATA_DIR ?? './data')
    return driver
  }
  throw new Error(
    `Unknown STORAGE_DRIVER "${kind}". Available drivers: local. (S3 is a documented future driver.)`,
  )
}

export function newStorageKey(userId: string, originalName: string): string {
  const safe = originalName.replace(/[^a-zA-Z0-9.-]/g, '_').slice(0, 80)
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  return `${userId}/${stamp}-${Math.random().toString(36).slice(2, 10)}-${safe}`
}
