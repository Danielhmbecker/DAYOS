import { z } from 'zod'

// ── Auth ────────────────────────────────────────────────────────────────────
export const loginSchema = z.object({
  // Full email, or a bare username as shorthand for `<name>@dayos.local`
  // (e.g. `root`). Account creation still requires a real email + strong
  // password; this relaxation applies to sign-in on a private instance only.
  email: z.string().trim().min(1, 'Enter your email or username'),
  password: z.string().min(1, 'Password is required'),
})
export type LoginInput = z.infer<typeof loginSchema>

export const setupSchema = z.object({
  name: z.string().trim().min(2, 'Name is required'),
  email: z.string().trim().email('Enter a valid email address'),
  password: z
    .string()
    .min(10, 'Use at least 10 characters')
    .regex(/[A-Z]/, 'Include an uppercase letter')
    .regex(/[a-z]/, 'Include a lowercase letter')
    .regex(/[0-9]/, 'Include a number'),
})
export type SetupInput = z.infer<typeof setupSchema>

export const profileSchema = z.object({
  name: z.string().trim().min(2, 'Name is required'),
  email: z.string().trim().email('Enter a valid email address'),
})
export type ProfileInput = z.infer<typeof profileSchema>

export const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, 'Current password is required'),
    newPassword: z
      .string()
      .min(10, 'Use at least 10 characters')
      .regex(/[A-Z]/, 'Include an uppercase letter')
      .regex(/[a-z]/, 'Include a lowercase letter')
      .regex(/[0-9]/, 'Include a number'),
    confirm: z.string(),
  })
  .refine((v) => v.newPassword === v.confirm, {
    message: 'Passwords do not match',
    path: ['confirm'],
  })
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>

// ── Money ───────────────────────────────────────────────────────────────────
const amount = z.coerce.number().positive('Amount must be greater than 0').max(10_000_000)

export const transactionSchema = z.object({
  type: z.enum(['INCOME', 'EXPENSE']),
  amount,
  categoryId: z.string().optional().nullable(),
  note: z.string().trim().max(200).optional().nullable(),
  date: z.coerce.date(),
  recurrence: z.enum(['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']).optional().nullable(),
})
export type TransactionInput = z.infer<typeof transactionSchema>

export const categorySchema = z.object({
  name: z.string().trim().min(1).max(40),
  type: z.enum(['INCOME', 'EXPENSE']),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).default('#38BDF8'),
})
export type CategoryInput = z.infer<typeof categorySchema>

export const budgetSchema = z.object({
  categoryId: z.string().min(1),
  monthlyLimit: amount,
})
export type BudgetInput = z.infer<typeof budgetSchema>

export const billSchema = z.object({
  name: z.string().trim().min(1).max(60),
  amount,
  frequency: z.enum(['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']).default('MONTHLY'),
  nextDueDate: z.coerce.date(),
  notes: z.string().trim().max(200).optional().nullable(),
})
export type BillInput = z.infer<typeof billSchema>

export const savingsGoalSchema = z.object({
  name: z.string().trim().min(1).max(60),
  targetAmount: amount,
  savedAmount: z.coerce.number().min(0).default(0),
  deadline: z.coerce.date().optional().nullable(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).default('#34D399'),
})
export type SavingsGoalInput = z.infer<typeof savingsGoalSchema>

// ── Work ────────────────────────────────────────────────────────────────────
export const shiftSchema = z
  .object({
    locationId: z.string().optional().nullable(),
    role: z.string().trim().max(60).optional().nullable(),
    date: z.coerce.date(),
    startTime: z.string().regex(/^\d{2}:\d{2}$/),
    endTime: z.string().regex(/^\d{2}:\d{2}$/),
    breakMinutes: z.coerce.number().int().min(0).max(720).default(0),
    notes: z.string().trim().max(300).optional().nullable(),
  })
  .refine((v) => v.startTime !== v.endTime, {
    message: 'Start and end time must differ',
    path: ['endTime'],
  })
export type ShiftInput = z.infer<typeof shiftSchema>

export const workTaskSchema = z.object({
  title: z.string().trim().min(1).max(120),
  locationId: z.string().optional().nullable(),
  dueDate: z.coerce.date().optional().nullable(),
})
export type WorkTaskInput = z.infer<typeof workTaskSchema>

export const workLocationSchema = z.object({
  name: z.string().trim().min(1).max(60),
  role: z.string().trim().max(60).optional().nullable(),
  hourlyRate: z.coerce.number().min(0).max(10000).optional().nullable(),
})
export type WorkLocationInput = z.infer<typeof workLocationSchema>

// ── Career ──────────────────────────────────────────────────────────────────
export const careerStageSchema = z.object({
  title: z.string().trim().min(1).max(80),
  subtitle: z.string().trim().max(120).optional().nullable(),
})
export type CareerStageInput = z.infer<typeof careerStageSchema>

export const applicationSchema = z.object({
  company: z.string().trim().min(1).max(80),
  role: z.string().trim().min(1).max(80),
  salary: z.string().trim().max(60).optional().nullable(),
  location: z.string().trim().max(80).optional().nullable(),
  workMode: z.enum(['REMOTE', 'HYBRID', 'ONSITE']).default('ONSITE'),
  status: z.enum(['SAVED', 'APPLIED', 'INTERVIEW', 'OFFER', 'REJECTED', 'CLOSED']).default('SAVED'),
  appliedDate: z.coerce.date().optional().nullable(),
  interviewDate: z.coerce.date().optional().nullable(),
  cvVersion: z.string().trim().max(40).optional().nullable(),
  notes: z.string().trim().max(2000).optional().nullable(),
})
export type ApplicationInput = z.infer<typeof applicationSchema>

export const courseSchema = z.object({
  title: z.string().trim().min(1).max(120),
  provider: z.string().trim().max(80).optional().nullable(),
  status: z.enum(['PLANNED', 'IN_PROGRESS', 'COMPLETED']).default('PLANNED'),
})
export type CourseInput = z.infer<typeof courseSchema>

export const certificateSchema = z.object({
  title: z.string().trim().min(1).max(120),
  issuer: z.string().trim().max(80).optional().nullable(),
  issuedAt: z.coerce.date().optional().nullable(),
  expiresAt: z.coerce.date().optional().nullable(),
})
export type CertificateInput = z.infer<typeof certificateSchema>

export const skillSchema = z.object({
  name: z.string().trim().min(1).max(60),
  level: z.coerce.number().int().min(1).max(5).default(3),
})
export type SkillInput = z.infer<typeof skillSchema>

// ── Tasks & calendar ────────────────────────────────────────────────────────
export const taskSchema = z.object({
  title: z.string().trim().min(1).max(140),
  description: z.string().trim().max(2000).optional().nullable(),
  dueDate: z.coerce.date().optional().nullable(),
  priority: z.enum(['LOW', 'MEDIUM', 'HIGH']).default('MEDIUM'),
  status: z.enum(['TODO', 'IN_PROGRESS', 'DONE']).default('TODO'),
  category: z.string().trim().max(40).optional().nullable(),
})
export type TaskInput = z.infer<typeof taskSchema>

export const eventSchema = z
  .object({
    title: z.string().trim().min(1).max(140),
    start: z.coerce.date(),
    endTime: z.string().regex(/^\d{2}:\d{2}$/).optional().nullable(),
    allDay: z.boolean().default(false),
    location: z.string().trim().max(120).optional().nullable(),
    notes: z.string().trim().max(2000).optional().nullable(),
  })
  .refine((v) => v.allDay || !!v.endTime, {
    message: 'End time is required unless the event is all-day',
    path: ['endTime'],
  })
export type EventInput = z.infer<typeof eventSchema>

// ── Notes ───────────────────────────────────────────────────────────────────
export const noteSchema = z.object({
  title: z.string().trim().min(1).max(140),
  content: z.string().max(100_000).default(''),
  tags: z.array(z.string().trim().min(1).max(30)).max(10).default([]),
  favourite: z.boolean().default(false),
})
export type NoteInput = z.infer<typeof noteSchema>

// ── Vault ───────────────────────────────────────────────────────────────────
export const documentMetaSchema = z.object({
  name: z.string().trim().min(1).max(140),
  category: z.enum(['PERSONAL', 'FINANCE', 'HOUSING', 'WORK', 'EDUCATION', 'RECEIPTS', 'OTHER']).default('OTHER'),
  tags: z.array(z.string().trim().min(1).max(30)).max(10).default([]),
  description: z.string().trim().max(500).optional().nullable(),
})
export type DocumentMetaInput = z.infer<typeof documentMetaSchema>

export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024 // 10 MB
export const ALLOWED_MIME = [
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/webp',
  'image/heic',
  'text/plain',
  'text/csv',
  'application/json',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
]

// ── Stockroom ───────────────────────────────────────────────────────────────
export const stockItemSchema = z.object({
  name: z.string().trim().min(1).max(80),
  category: z.string().trim().min(1).max(40).default('General'),
  unit: z.string().trim().min(1).max(20).default('unit'),
  quantity: z.coerce.number().min(0).max(1_000_000).default(0),
  threshold: z.coerce.number().min(0).max(1_000_000).default(0),
  location: z.string().trim().max(60).optional().nullable(),
})
export type StockItemInput = z.infer<typeof stockItemSchema>

export const stockCountSchema = z.object({
  itemId: z.string().min(1),
  countedQuantity: z.coerce.number().min(0).max(1_000_000),
  note: z.string().trim().max(200).optional().nullable(),
})
export type StockCountInput = z.infer<typeof stockCountSchema>

export const cleaningTaskSchema = z.object({
  title: z.string().trim().min(1).max(120),
  area: z.string().trim().max(60).optional().nullable(),
  frequency: z.enum(['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']).default('WEEKLY'),
})
export type CleaningTaskInput = z.infer<typeof cleaningTaskSchema>

// ── Settings ───────────────────────────────────────────────────────────────
export const preferencesSchema = z.object({
  currency: z.string().trim().length(3).default('GBP'),
  weatherEnabled: z.boolean().default(false),
  weatherLatitude: z.coerce.number().min(-90).max(90).optional().nullable(),
  weatherLongitude: z.coerce.number().min(-180).max(180).optional().nullable(),
  weatherLabel: z.string().trim().max(60).optional().nullable(),
})
export type PreferencesInput = z.infer<typeof preferencesSchema>

export const workRatesSchema = z.object({
  workHourlyRate: z.coerce.number().min(0).max(10000).default(0),
  workOvertimeThresholdMin: z.coerce.number().int().min(0).max(1440).default(480),
  workOvertimeMultiplier: z.coerce.number().min(1).max(5).default(1.5),
})
export type WorkRatesInput = z.infer<typeof workRatesSchema>

export const dashboardConfigSchema = z.object({
  hidden: z.array(z.string()).default([]),
})

// ── Quick capture ───────────────────────────────────────────────────────────
export const quickNoteSchema = z.object({ title: z.string().trim().min(1).max(140) })
export const quickTaskSchema = z.object({
  title: z.string().trim().min(1).max(140),
  dueDate: z.coerce.date().optional().nullable(),
})
export const quickMoneySchema = z.object({
  type: z.enum(['INCOME', 'EXPENSE']),
  amount,
  note: z.string().trim().max(120).optional().nullable(),
  categoryId: z.string().optional().nullable(),
})
export const quickEventSchema = z.object({
  title: z.string().trim().min(1).max(140),
  date: z.coerce.date(),
  startTime: z.string().regex(/^\d{2}:\d{2}$/),
})
