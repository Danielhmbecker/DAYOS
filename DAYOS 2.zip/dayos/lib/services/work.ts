import { db } from '@/lib/db/client'
import { shiftPay, workedMinutes, type ShiftPay } from '@/lib/calc/schedule'
import { endOfMonth, startOfMonth, toDecimalNumber } from '@/lib/utils'
import type { WorkShift } from '@prisma/client'

export type ShiftWithPay = WorkShift & { pay: ShiftPay; locationName: string | null }

export async function getSettings(userId: string) {
  const settings = await db.settings.findUnique({ where: { userId } })
  if (settings) return settings
  return db.settings.create({ data: { userId } })
}

export async function shiftsInRange(userId: string, from: Date, to: Date) {
  const settings = await getSettings(userId)
  const rate = toDecimalNumber(settings.workHourlyRate)
  const threshold = settings.workOvertimeThresholdMin
  const multiplier = toDecimalNumber(settings.workOvertimeMultiplier)
  const shifts = await db.workShift.findMany({
    where: { userId, date: { gte: from, lte: to }, cancelled: false },
    include: { location: true },
    orderBy: { date: 'asc' },
  })
  return shifts.map((s) => ({
    ...s,
    locationName: s.location?.name ?? null,
    rate: s.location?.hourlyRate ? toDecimalNumber(s.location.hourlyRate) : rate,
    pay: shiftPay(
      s.start,
      s.end,
      s.breakMinutes,
      s.location?.hourlyRate ? toDecimalNumber(s.location.hourlyRate) : rate,
      threshold,
      multiplier,
    ),
  }))
}

export async function monthSummary(userId: string, month = new Date()) {
  const shifts = await shiftsInRange(userId, startOfMonth(month), endOfMonth(month))
  const hours = shifts.reduce((sum, s) => sum + s.pay.workedMinutes, 0)
  const overtime = shifts.reduce((sum, s) => sum + s.pay.overtimeMinutes, 0)
  const pay = shifts.reduce((sum, s) => sum + s.pay.pay, 0)
  const tips = 0 // tips tracking is a documented future feature
  return {
    shiftCount: shifts.length,
    hoursMinutes: hours,
    overtimeMinutes: overtime,
    estimatedPay: Math.round(pay * 100) / 100,
    tips,
  }
}

export function shiftLabel(shift: { start: Date; end: Date }): string {
  const fmt = (d: Date) => d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
  const endLabel = shift.end.getTime() <= shift.start.getTime() ? 'Close' : fmt(shift.end)
  return `${fmt(shift.start)} → ${endLabel}`
}

export function combineShiftTimes(date: Date, time: string): Date {
  const [h, m] = time.split(':').map((n) => parseInt(n, 10))
  const d = new Date(date)
  d.setHours(h, m, 0, 0)
  return d
}

/** End time "00:00" or any time <= start means the shift closes (next day). */
export function resolveShiftEnd(date: Date, startTime: string, endTime: string): Date {
  const start = combineShiftTimes(date, startTime)
  let end = combineShiftTimes(date, endTime)
  if (end <= start) end = new Date(end.getTime() + 86400000)
  return end
}

export function minutesToHours(minutes: number): number {
  return Math.round((minutes / 60) * 100) / 100
}

export { workedMinutes, shiftPay }
