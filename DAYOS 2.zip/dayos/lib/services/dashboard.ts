import { db } from '@/lib/db/client'
import { availableBalance, materialiseRecurring, monthTotals, savingsTotal, upcomingBills } from './money'
import { shiftsInRange } from './work'
import { endOfDay, startOfDay, toDecimalNumber } from '@/lib/utils'

export type DashboardData = {
  balance: number
  month: { income: number; expense: number; remaining: number }
  savings: number
  todayShift: { id: string; start: Date; end: Date; locationName: string | null; role: string | null } | null
  nextEvent: { id: string; title: string; start: Date; allDay: boolean } | null
  tasksRemaining: number
  careerCurrent: string | null
  billsSoon: { id: string; name: string; amount: number; days: number }[]
}

export async function getDashboard(userId: string, now = new Date()): Promise<DashboardData> {
  await materialiseRecurring(userId, now)
  const [balance, month, savings, bills, tasksRemaining, careerCurrent] = await Promise.all([
    availableBalance(userId, now),
    monthTotals(userId, now),
    savingsTotal(userId),
    upcomingBills(userId, 14, now),
    db.task.count({ where: { userId, status: { not: 'DONE' } } }),
    db.careerStage.findFirst({ where: { userId, isCurrent: true }, orderBy: { order: 'asc' } }),
  ])

  const todayShifts = await shiftsInRange(userId, startOfDay(now), endOfDay(now))
  const todayShift = todayShifts[0] ?? null

  const nextEvent = await db.calendarEvent.findFirst({
    where: { userId, start: { gte: now } },
    orderBy: { start: 'asc' },
  })

  return {
    balance,
    month,
    savings,
    todayShift: todayShift
      ? { id: todayShift.id, start: todayShift.start, end: todayShift.end, locationName: todayShift.locationName, role: todayShift.role }
      : null,
    nextEvent: nextEvent ? { id: nextEvent.id, title: nextEvent.title, start: nextEvent.start, allDay: nextEvent.allDay } : null,
    tasksRemaining,
    careerCurrent: careerCurrent?.title ?? null,
    billsSoon: bills.slice(0, 3).map((b) => ({ id: b.id, name: b.name, amount: b.amount, days: b.days })),
  }
}

// The dashboard must never stall on the external weather API: results are
// cached in-process for 10 minutes, the fetch hard-aborts after 2.5s, and on
// failure the previous value is served while retries back off for 30s.
const WEATHER_TTL_MS = 10 * 60 * 1000
const WEATHER_RETRY_MS = 30 * 1000
const weatherCache = new Map<string, { at: number; value: { tempC: number; code: number } | null }>()

export async function getWeather(lat: number, lon: number): Promise<{ tempC: number; code: number } | null> {
  const key = `${lat},${lon}`
  const hit = weatherCache.get(key)
  if (hit && Date.now() - hit.at < WEATHER_TTL_MS) return hit.value
  try {
    const res = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`,
      { cache: 'no-store', signal: AbortSignal.timeout(2500) },
    )
    if (!res.ok) throw new Error(`weather api ${res.status}`)
    const json = (await res.json()) as { current_weather?: { temperature: number; weathercode: number } }
    const value = json.current_weather
      ? { tempC: json.current_weather.temperature, code: json.current_weather.weathercode }
      : null
    weatherCache.set(key, { at: Date.now(), value })
    return value
  } catch {
    // Serve stale (or null) and don't retry for WEATHER_RETRY_MS.
    weatherCache.set(key, { at: Date.now() - WEATHER_TTL_MS + WEATHER_RETRY_MS, value: hit?.value ?? null })
    return hit?.value ?? null
  }
}

export function weatherLabel(code: number): string {
  if (code === 0) return 'Clear'
  if (code <= 2) return 'Partly cloudy'
  if (code === 3) return 'Overcast'
  if (code <= 48) return 'Fog'
  if (code <= 57) return 'Drizzle'
  if (code <= 67) return 'Rain'
  if (code <= 77) return 'Snow'
  if (code <= 82) return 'Showers'
  if (code <= 99) return 'Thunderstorm'
  return 'Unknown'
}

export function settingsSafe(settings: { dashboardHidden: unknown } | null): string[] {
  const hidden = settings?.dashboardHidden
  return Array.isArray(hidden) ? hidden.filter((h): h is string => typeof h === 'string') : []
}

export function sum(list: { amount: unknown }[]): number {
  return list.reduce((acc, item) => acc + toDecimalNumber(item.amount), 0)
}
