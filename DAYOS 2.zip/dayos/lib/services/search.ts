import { db } from '@/lib/db/client'

export type SearchHit = { type: string; title: string; subtitle: string; href: string }

export async function globalSearch(userId: string, query: string): Promise<SearchHit[]> {
  const q = query.trim()
  if (q.length < 2) return []
  const like = { contains: q, mode: 'insensitive' as const }
  const [notes, tasks, transactions, events, documents, applications] = await Promise.all([
    db.note.findMany({ where: { userId, archived: false, OR: [{ title: like }, { content: like }] }, take: 5 }),
    db.task.findMany({ where: { userId, status: { not: 'DONE' }, title: like }, take: 5 }),
    db.transaction.findMany({ where: { userId, note: like }, orderBy: { date: 'desc' }, take: 5, include: { category: true } }),
    db.calendarEvent.findMany({ where: { userId, OR: [{ title: like }, { location: like }] }, orderBy: { start: 'asc' }, take: 5 }),
    db.document.findMany({ where: { userId, name: like }, take: 5 }),
    db.careerApplication.findMany({ where: { userId, OR: [{ company: like }, { role: like }] }, take: 5 }),
  ])
  return [
    ...notes.map((n) => ({ type: 'Note', title: n.title, subtitle: n.content.slice(0, 60), href: '/notes' })),
    ...tasks.map((t) => ({ type: 'Task', title: t.title, subtitle: t.status.replaceAll('_', ' ').toLowerCase(), href: '/tasks' })),
    ...transactions.map((t) => ({
      type: t.type === 'INCOME' ? 'Income' : 'Expense',
      title: t.note ?? t.category?.name ?? t.type,
      subtitle: new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(Number(t.amount)),
      href: '/money',
    })),
    ...events.map((e) => ({ type: 'Event', title: e.title, subtitle: e.start.toLocaleDateString('en-GB'), href: '/calendar' })),
    ...documents.map((d) => ({ type: 'Document', title: d.name, subtitle: d.category.toLowerCase(), href: '/vault' })),
    ...applications.map((a) => ({ type: 'Application', title: `${a.role} · ${a.company}`, subtitle: a.status.toLowerCase(), href: '/career' })),
  ].slice(0, 20)
}
