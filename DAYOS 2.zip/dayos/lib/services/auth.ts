import { db } from '@/lib/db/client'
import { hashPassword, verifyPassword } from '@/lib/auth/password'
import { rateLimit, rateLimitKey } from '@/lib/auth/rate-limit'
import type { ChangePasswordInput, LoginInput, ProfileInput, SetupInput } from '@/lib/validation/schemas'

export type AuthResult = { ok: true; userId: string } | { ok: false; error: string }

/** First-run owner setup: only allowed while no user exists. */
export async function setupOwner(input: SetupInput): Promise<AuthResult> {
  const count = await db.user.count()
  if (count > 0) return { ok: false, error: 'An owner account already exists.' }
  const user = await db.user.create({
    data: {
      name: input.name,
      email: input.email.toLowerCase(),
      passwordHash: await hashPassword(input.password),
      settings: { create: {} },
    },
  })
  return { ok: true, userId: user.id }
}

export async function canSetup(): Promise<boolean> {
  return (await db.user.count()) === 0
}

export async function authenticate(input: LoginInput, ip?: string): Promise<AuthResult> {
  // Accept a full email or a bare username; bare names resolve to
  // `<name>@dayos.local` (e.g. `root` → `root@dayos.local`).
  const id = input.email.trim().toLowerCase()
  const email = id.includes('@') ? id : `${id}@dayos.local`
  // Brute-force protection: 30 attempts/min per IP+identifier (bcrypt + single
  // owner account make even that rate impractical to attack).
  const limit = rateLimit(rateLimitKey('login', ip ?? 'local', email), 30, 60_000)
  if (!limit.ok) {
    return { ok: false, error: `Too many attempts. Try again in ${Math.ceil(limit.retryInMs / 1000)}s.` }
  }
  const user = await db.user.findUnique({ where: { email } })
  // Constant-ish time: always run a hash comparison.
  const hash = user?.passwordHash ?? '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidin'
  const valid = await verifyPassword(input.password, hash)
  if (!user || !valid) return { ok: false, error: 'Incorrect email or password.' }
  return { ok: true, userId: user.id }
}

export async function updateProfile(userId: string, input: ProfileInput): Promise<AuthResult> {
  const existing = await db.user.findFirst({ where: { email: input.email.toLowerCase() } })
  if (existing && existing.id !== userId) return { ok: false, error: 'That email is already in use.' }
  await db.user.update({
    where: { id: userId },
    data: { name: input.name, email: input.email.toLowerCase() },
  })
  return { ok: true, userId }
}

export async function changePassword(userId: string, input: ChangePasswordInput): Promise<AuthResult> {
  const user = await db.user.findUnique({ where: { id: userId } })
  if (!user) return { ok: false, error: 'Account not found.' }
  const valid = await verifyPassword(input.currentPassword, user.passwordHash)
  if (!valid) return { ok: false, error: 'Current password is incorrect.' }
  await db.user.update({
    where: { id: userId },
    data: { passwordHash: await hashPassword(input.newPassword) },
  })
  return { ok: true, userId }
}
