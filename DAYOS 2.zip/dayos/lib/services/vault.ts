import { db } from '@/lib/db/client'
import { storage, newStorageKey } from '@/lib/storage'
import { ALLOWED_MIME, MAX_UPLOAD_BYTES, type DocumentMetaInput } from '@/lib/validation/schemas'

export function listDocuments(userId: string, opts: { category?: string; search?: string } = {}) {
  return db.document.findMany({
    where: {
      userId,
      ...(opts.category ? { category: opts.category as never } : {}),
      ...(opts.search ? { name: { contains: opts.search, mode: 'insensitive' } } : {}),
    },
    orderBy: { uploadedAt: 'desc' },
  })
}

export async function uploadDocument(
  userId: string,
  file: { name: string; mime: string; bytes: Buffer },
  meta: DocumentMetaInput,
) {
  if (file.bytes.byteLength > MAX_UPLOAD_BYTES) {
    throw new Error('File too large (limit 10 MB)')
  }
  if (!ALLOWED_MIME.includes(file.mime)) {
    throw new Error(`Unsupported file type: ${file.mime || 'unknown'}`)
  }
  const key = newStorageKey(userId, file.name)
  await storage().put(key, file.bytes, file.mime)
  return db.document.create({
    data: {
      userId,
      name: meta.name || file.name,
      mime: file.mime,
      sizeBytes: file.bytes.byteLength,
      storageKey: key,
      category: meta.category,
      tags: meta.tags,
      description: meta.description ?? null,
    },
  })
}

export async function getDocumentForUser(userId: string, id: string) {
  return db.document.findFirst({ where: { id, userId } })
}

export async function updateDocumentMeta(userId: string, id: string, meta: DocumentMetaInput) {
  const existing = await getDocumentForUser(userId, id)
  if (!existing) throw new Error('Document not found')
  return db.document.update({ where: { id }, data: { ...meta, description: meta.description ?? null } })
}

export async function deleteDocument(userId: string, id: string) {
  const existing = await getDocumentForUser(userId, id)
  if (!existing) throw new Error('Document not found')
  await storage().remove(existing.storageKey)
  await db.document.delete({ where: { id } })
}

export function humanSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}
