import { db } from '@/lib/db/client'
import { upcomingBills } from './money'
import { cleaningStatus } from './stockroom'
import { scheduleStatus } from '@/lib/calc/schedule'
import { startOfDay } from '@/lib/utils'

export type Alert = { id: string; kind: 'bill' | 'task' | 'stock' | 'cleaning' | 'event'; title: string; detail: string; href: string }

/** Computed alert feed shown in the header bell — always derived from real data. */
export async function getAlerts(userId: string, now = new Date()): Promise<Alert[]> {
  const alerts: Alert[] = []

  const bills = await upcomingBills(userId, 7, now)
  for (const b of bills.filter((x) => x.days <= 3)) {
    alerts.push({
      id: `bill-${b.id}`,
      kind: 'bill',
      title: `${b.name} due`,
      detail: b.days < 0 ? `${Math.abs(b.days)} days overdue` : b.days === 0 ? 'Due today' : `Due in ${b.days} days`,
      href: '/money?tab=bills',
    })
  }

  const overdueTasks = await db.task.findMany({
    where: { userId, status: { not: 'DONE' }, dueDate: { lt: startOfDay(now) } },
    take: 5,
  })
  for (const t of overdueTasks) {
    alerts.push({ id: `task-${t.id}`, kind: 'task', title: t.title, detail: 'Overdue task', href: '/tasks' })
  }

  const stock = await db.stockItem.findMany({ where: { userId } })
  for (const s of stock.filter((i) => Number(i.quantity) <= Number(i.threshold)).slice(0, 5)) {
    alerts.push({ id: `stock-${s.id}`, kind: 'stock', title: `${s.name} low`, detail: `${s.quantity} ${s.unit} left`, href: '/stockroom' })
  }

  const cleaning = await cleaningStatus(userId, now)
  for (const c of cleaning.filter((x) => x.status === 'overdue').slice(0, 3)) {
    alerts.push({ id: `clean-${c.id}`, kind: 'cleaning', title: c.title, detail: 'Cleaning overdue', href: '/stockroom?tab=cleaning' })
  }

  const todayEvents = await db.calendarEvent.findMany({
    where: { userId, start: { gte: now, lte: new Date(now.getTime() + 6 * 3600000) } },
    take: 3,
  })
  for (const e of todayEvents) {
    alerts.push({
      id: `event-${e.id}`,
      kind: 'event',
      title: e.title,
      detail: `Starting at ${e.start.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`,
      href: '/calendar',
    })
  }

  return alerts.slice(0, 12)
}

export { scheduleStatus }
