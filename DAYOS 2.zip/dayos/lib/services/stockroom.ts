import { db } from '@/lib/db/client'
import { scheduleStatus, type ScheduleStatus } from '@/lib/calc/schedule'
import { toDecimalNumber } from '@/lib/utils'

export type StockItemRow = {
  id: string
  name: string
  category: string
  unit: string
  quantity: number
  threshold: number
  location: string | null
  low: boolean
}

export async function listStock(userId: string) {
  const items = await db.stockItem.findMany({ where: { userId }, orderBy: [{ category: 'asc' }, { name: 'asc' }] })
  return items.map<StockItemRow>((i) => {
    const quantity = toDecimalNumber(i.quantity)
    const threshold = toDecimalNumber(i.threshold)
    return { ...i, quantity, threshold, low: quantity <= threshold }
  })
}

/** Group-level health: e.g. "KEGS 83%", "LINES 12/14 OK". */
export function categoryHealth(items: StockItemRow[]) {
  const groups = new Map<string, { total: number; ok: number; quantity: number; capacity: number }>()
  for (const i of items) {
    const g = groups.get(i.category) ?? { total: 0, ok: 0, quantity: 0, capacity: 0 }
    g.total += 1
    if (!i.low) g.ok += 1
    g.quantity += i.quantity
    g.capacity += Math.max(i.threshold * 2, i.quantity)
    groups.set(i.category, g)
  }
  return [...groups.entries()].map(([category, g]) => ({
    category,
    total: g.total,
    ok: g.ok,
    percent: g.capacity > 0 ? Math.round((g.quantity / g.capacity) * 100) : 0,
  }))
}

export async function recordCount(userId: string, itemId: string, countedQuantity: number, note?: string | null) {
  const item = await db.stockItem.findFirst({ where: { id: itemId, userId } })
  if (!item) throw new Error('Stock item not found')
  const delta = countedQuantity - toDecimalNumber(item.quantity)
  await db.$transaction([
    db.stockCount.create({
      data: { userId, itemId, countedQuantity, delta, note: note ?? null },
    }),
    db.stockItem.update({ where: { id: itemId }, data: { quantity: countedQuantity } }),
  ])
  return delta
}

export async function adjustStock(userId: string, itemId: string, delta: number) {
  const item = await db.stockItem.findFirst({ where: { id: itemId, userId } })
  if (!item) throw new Error('Stock item not found')
  const next = Math.max(0, toDecimalNumber(item.quantity) + delta)
  await db.stockItem.update({ where: { id: itemId }, data: { quantity: next } })
  return next
}

export type CleaningRow = {
  id: string
  title: string
  area: string | null
  frequency: 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'YEARLY'
  lastCompletedAt: Date | null
  status: ScheduleStatus
}

export async function cleaningStatus(userId: string, now = new Date()): Promise<CleaningRow[]> {
  const tasks = await db.cleaningTask.findMany({ where: { userId }, orderBy: { title: 'asc' } })
  return tasks.map((t) => ({
    id: t.id,
    title: t.title,
    area: t.area,
    frequency: t.frequency,
    lastCompletedAt: t.lastCompletedAt,
    status: scheduleStatus(t.lastCompletedAt, t.frequency, now),
  }))
}

export async function completeCleaning(userId: string, id: string, now = new Date()) {
  const existing = await db.cleaningTask.findFirst({ where: { id, userId } })
  if (!existing) throw new Error('Cleaning task not found')
  await db.cleaningTask.update({ where: { id }, data: { lastCompletedAt: now } })
}
