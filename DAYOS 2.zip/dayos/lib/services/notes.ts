import { db } from '@/lib/db/client'
import type { NoteInput } from '@/lib/validation/schemas'

export function listNotes(userId: string, opts: { archived?: boolean; search?: string; tag?: string } = {}) {
  return db.note.findMany({
    where: {
      userId,
      archived: opts.archived ?? false,
      ...(opts.search
        ? {
            OR: [
              { title: { contains: opts.search, mode: 'insensitive' } },
              { content: { contains: opts.search, mode: 'insensitive' } },
            ],
          }
        : {}),
      ...(opts.tag ? { tags: { some: { tag: { name: opts.tag } } } } : {}),
    },
    include: { tags: { include: { tag: true } } },
    orderBy: [{ favourite: 'desc' }, { updatedAt: 'desc' }],
  })
}

export async function saveNote(userId: string, id: string | null, input: NoteInput) {
  const tagIds: string[] = []
  for (const name of input.tags) {
    const tag = await db.tag.upsert({
      where: { userId_name: { userId, name } },
      update: {},
      create: { userId, name },
    })
    tagIds.push(tag.id)
  }
  const tagWrites = tagIds.map((tagId) => ({ tagId }))
  if (id) {
    const existing = await db.note.findFirst({ where: { id, userId } })
    if (!existing) throw new Error('Note not found')
    return db.note.update({
      where: { id },
      data: {
        title: input.title,
        content: input.content,
        favourite: input.favourite,
        tags: { deleteMany: {}, create: tagWrites },
      },
      include: { tags: { include: { tag: true } } },
    })
  }
  return db.note.create({
    data: {
      userId,
      title: input.title,
      content: input.content,
      favourite: input.favourite,
      tags: { create: tagWrites },
    },
    include: { tags: { include: { tag: true } } },
  })
}

export async function setNoteFlags(userId: string, id: string, flags: { favourite?: boolean; archived?: boolean }) {
  const existing = await db.note.findFirst({ where: { id, userId } })
  if (!existing) throw new Error('Note not found')
  return db.note.update({ where: { id }, data: flags })
}

export async function deleteNote(userId: string, id: string) {
  const existing = await db.note.findFirst({ where: { id, userId } })
  if (!existing) throw new Error('Note not found')
  await db.note.delete({ where: { id } })
}
