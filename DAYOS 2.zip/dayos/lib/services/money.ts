import { db } from '@/lib/db/client'
import { addFrequency, round2 } from '@/lib/calc/schedule'
import { endOfMonth, startOfMonth, toDecimalNumber } from '@/lib/utils'
import type { MoneyType, Prisma } from '@prisma/client'

export type TxFilters = {
  type?: MoneyType
  categoryId?: string
  search?: string
  from?: Date
  to?: Date
  limit?: number
}

export function listTransactions(userId: string, filters: TxFilters = {}) {
  const where: Prisma.TransactionWhereInput = {
    userId,
    ...(filters.type ? { type: filters.type } : {}),
    ...(filters.categoryId ? { categoryId: filters.categoryId } : {}),
    ...(filters.from || filters.to
      ? { date: { ...(filters.from ? { gte: filters.from } : {}), ...(filters.to ? { lte: filters.to } : {}) } }
      : {}),
    ...(filters.search
      ? { OR: [{ note: { contains: filters.search, mode: 'insensitive' } }] }
      : {}),
  }
  return db.transaction.findMany({
    where,
    include: { category: true },
    orderBy: { date: 'desc' },
    take: filters.limit ?? 200,
  })
}

/** Materialise recurring transactions whose nextDueDate has arrived (idempotent). */
export async function materialiseRecurring(userId: string, today = new Date()): Promise<number> {
  const templates = await db.transaction.findMany({
    where: { userId, recurrence: { not: null }, nextDueDate: { lte: today } },
  })
  let created = 0
  for (const t of templates) {
    if (!t.recurrence || !t.nextDueDate) continue
    let due = new Date(t.nextDueDate)
    let guard = 0
    while (due <= today && guard < 60) {
      const exists = await db.transaction.findFirst({
        where: { parentId: t.id, date: { gte: startOfDayOf(due), lt: addFrequency(due, 'DAILY') } },
        select: { id: true },
      })
      if (!exists) {
        await db.transaction.create({
          data: {
            userId,
            categoryId: t.categoryId,
            type: t.type,
            amount: t.amount,
            note: t.note,
            date: due,
            parentId: t.id,
          },
        })
        created += 1
      }
      due = addFrequency(due, t.recurrence)
      guard += 1
    }
    await db.transaction.update({ where: { id: t.id }, data: { nextDueDate: due } })
  }
  return created
}

function startOfDayOf(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate())
}

export async function monthTotals(userId: string, month = new Date()) {
  const from = startOfMonth(month)
  const to = endOfMonth(month)
  const rows = await db.transaction.findMany({
    where: { userId, date: { gte: from, lte: to } },
    select: { type: true, amount: true },
  })
  let income = 0
  let expense = 0
  for (const r of rows) {
    const v = toDecimalNumber(r.amount)
    if (r.type === 'INCOME') income += v
    else expense += v
  }
  return { income: round2(income), expense: round2(expense), remaining: round2(income - expense) }
}

/** Last N months of income/expense totals for charts (oldest first). */
export async function monthlySeries(userId: string, months = 6) {
  const now = new Date()
  const from = startOfMonth(new Date(now.getFullYear(), now.getMonth() - (months - 1), 1))
  const rows = await db.transaction.findMany({
    where: { userId, date: { gte: from } },
    select: { type: true, amount: true, date: true },
  })
  const buckets = new Map<string, { month: string; income: number; expense: number }>()
  for (let i = 0; i < months; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - (months - 1 - i), 1)
    const key = `${d.getFullYear()}-${d.getMonth()}`
    buckets.set(key, { month: d.toLocaleDateString('en-GB', { month: 'short' }), income: 0, expense: 0 })
  }
  for (const r of rows) {
    const key = `${r.date.getFullYear()}-${r.date.getMonth()}`
    const bucket = buckets.get(key)
    if (!bucket) continue
    const v = toDecimalNumber(r.amount)
    if (r.type === 'INCOME') bucket.income = round2(bucket.income + v)
    else bucket.expense = round2(bucket.expense + v)
  }
  return [...buckets.values()]
}

export async function availableBalance(userId: string, upTo = new Date()) {
  const rows = await db.transaction.findMany({
    where: { userId, date: { lte: upTo } },
    select: { type: true, amount: true },
  })
  let balance = 0
  for (const r of rows) {
    const v = toDecimalNumber(r.amount)
    balance += r.type === 'INCOME' ? v : -v
  }
  return round2(balance)
}

export async function savingsTotal(userId: string) {
  const goals = await db.savingsGoal.findMany({ where: { userId }, select: { savedAmount: true } })
  return round2(goals.reduce((sum, g) => sum + toDecimalNumber(g.savedAmount), 0))
}

export async function budgetProgress(userId: string, month = new Date()) {
  const budgets = await db.budget.findMany({
    where: { userId, active: true },
    include: { category: true },
  })
  const from = startOfMonth(month)
  const to = endOfMonth(month)
  const spent = await db.transaction.groupBy({
    by: ['categoryId'],
    where: { userId, type: 'EXPENSE', date: { gte: from, lte: to } },
    _sum: { amount: true },
  })
  const spentByCategory = new Map(spent.map((s) => [s.categoryId, toDecimalNumber(s._sum.amount)]))
  return budgets.map((b) => {
    const limit = toDecimalNumber(b.monthlyLimit)
    const used = spentByCategory.get(b.categoryId) ?? 0
    return {
      id: b.id,
      categoryId: b.categoryId,
      category: b.category.name,
      color: b.category.color,
      limit,
      used: round2(used),
      percent: limit > 0 ? Math.min(100, Math.round((used / limit) * 100)) : 0,
      over: used > limit,
    }
  })
}

export async function upcomingBills(userId: string, withinDays = 30, now = new Date()) {
  const horizon = new Date(now.getTime() + withinDays * 86400000)
  const bills = await db.bill.findMany({
    where: { userId, nextDueDate: { lte: horizon } },
    orderBy: { nextDueDate: 'asc' },
  })
  return bills.map((b) => {
    const days = Math.ceil((b.nextDueDate.getTime() - now.getTime()) / 86400000)
    return {
      ...b,
      amount: toDecimalNumber(b.amount),
      days,
      state: days < 0 ? ('overdue' as const) : days <= 7 ? ('soon' as const) : ('scheduled' as const),
    }
  })
}

export async function payBill(billId: string, userId: string, now = new Date()) {
  const bill = await db.bill.findFirst({ where: { id: billId, userId } })
  if (!bill) throw new Error('Bill not found')
  let next = new Date(bill.nextDueDate)
  while (next <= now) next = addFrequency(next, bill.frequency)
  await db.$transaction([
    db.bill.update({ where: { id: bill.id }, data: { nextDueDate: next, lastPaidAt: now } }),
    db.transaction.create({
      data: {
        userId,
        type: 'EXPENSE',
        amount: bill.amount,
        note: `Bill: ${bill.name}`,
        date: now,
      },
    }),
  ])
}
