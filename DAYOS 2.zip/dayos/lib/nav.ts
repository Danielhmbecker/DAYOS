import {
  Home,
  Wallet,
  Briefcase,
  TrendingUp,
  LayoutGrid,
  StickyNote,
  FolderLock,
  CalendarDays,
  ListTodo,
  Package,
  Settings,
  FlaskConical,
  Zap,
  type LucideIcon,
} from 'lucide-react'

export type NavItem = { href: string; label: string; icon: LucideIcon }

export const PRIMARY_NAV: NavItem[] = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/money', label: 'Money', icon: Wallet },
  { href: '/work', label: 'Work', icon: Briefcase },
  { href: '/career', label: 'Career', icon: TrendingUp },
  { href: '/more', label: 'More', icon: LayoutGrid },
]

export const MORE_NAV: NavItem[] = [
  { href: '/notes', label: 'Notes', icon: StickyNote },
  { href: '/vault', label: 'Vault', icon: FolderLock },
  { href: '/calendar', label: 'Calendar', icon: CalendarDays },
  { href: '/tasks', label: 'Tasks', icon: ListTodo },
  { href: '/stockroom', label: 'Stockroom', icon: Package },
  { href: '/settings', label: 'Settings', icon: Settings },
]

/** Documented future modules — visible but clearly marked, never fake-working. */
export const FUTURE_MODULES: NavItem[] = [
  { href: '#future-betlab', label: 'BetLab', icon: FlaskConical },
  { href: '#future-turbo', label: 'Turbo', icon: Zap },
]

export function isActive(pathname: string, href: string): boolean {
  if (href === '/') return pathname === '/'
  return pathname === href || pathname.startsWith(href + '/')
}
