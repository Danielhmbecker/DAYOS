import { PrismaClient } from '@prisma/client'

/**
 * Single Prisma client for the whole app (PostgreSQL).
 *
 * Local/demo deployments can point DATABASE_URL at the embedded PGlite
 * Postgres server started with `npm run db:demo` — it speaks the standard
 * Postgres wire protocol, so nothing in the application changes.
 */
function createClient(): PrismaClient {
  return new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  })
}

const globalForDb = globalThis as unknown as { __dayosDb?: PrismaClient }

export const db = globalForDb.__dayosDb ?? createClient()

if (process.env.NODE_ENV !== 'production') globalForDb.__dayosDb = db

export type Db = PrismaClient
