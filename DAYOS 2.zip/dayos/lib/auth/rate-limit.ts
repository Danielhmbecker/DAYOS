/**
 * Minimal in-memory fixed-window rate limiter (per process).
 * Good enough for login brute-force protection on a single-instance
 * deployment; document that a proxy-level limit is advisable at scale.
 */
const buckets = new Map<string, { count: number; resetAt: number }>()

export function rateLimit(key: string, max: number, windowMs: number): { ok: boolean; retryInMs: number } {
  const now = Date.now()
  const bucket = buckets.get(key)
  if (!bucket || bucket.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs })
    return { ok: true, retryInMs: 0 }
  }
  bucket.count += 1
  if (bucket.count > max) return { ok: false, retryInMs: bucket.resetAt - now }
  return { ok: true, retryInMs: 0 }
}

export function rateLimitKey(...parts: string[]): string {
  return parts.join('|')
}
