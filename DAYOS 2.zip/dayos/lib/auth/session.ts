import { cache } from 'react'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { SignJWT, jwtVerify } from 'jose'
import { createHash, randomBytes } from 'node:crypto'
import { db } from '@/lib/db/client'
import type { User } from '@prisma/client'

export const SESSION_COOKIE = 'dayos_session'

function secretKey(): Uint8Array {
  const secret = process.env.AUTH_SECRET
  if (!secret) throw new Error('AUTH_SECRET is not set. See .env.example.')
  return new TextEncoder().encode(secret)
}

function sessionDays(): number {
  const days = parseInt(process.env.AUTH_SESSION_DAYS ?? '30', 10)
  return Number.isFinite(days) && days > 0 ? days : 30
}

export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex')
}

async function signToken(sessionId: string, userId: string, expiresAt: Date): Promise<string> {
  return new SignJWT({ sid: sessionId, sub: userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(Math.floor(expiresAt.getTime() / 1000))
    .sign(secretKey())
}

export async function verifyToken(token: string): Promise<{ sid: string; sub: string } | null> {
  try {
    const { payload } = await jwtVerify(token, secretKey())
    if (typeof payload.sid !== 'string' || typeof payload.sub !== 'string') return null
    return { sid: payload.sid, sub: payload.sub }
  } catch {
    return null
  }
}

function cookieOptions(expires: Date) {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    expires,
  }
}

/** Create a persisted session and set the signed cookie. */
export async function startSession(
  userId: string,
  meta?: { userAgent?: string; ip?: string },
): Promise<void> {
  const token = randomBytes(32).toString('base64url')
  const days = sessionDays()
  const expiresAt = new Date(Date.now() + days * 86400000)
  const session = await db.session.create({
    data: {
      userId,
      tokenHash: hashToken(token),
      expiresAt,
      userAgent: meta?.userAgent?.slice(0, 250),
      ip: meta?.ip,
    },
  })
  const jwt = await signToken(session.id, userId, expiresAt)
  const store = await cookies()
  store.set(SESSION_COOKIE, jwt, cookieOptions(expiresAt))
}

export type AuthSession = { user: User; sessionId: string; expiresAt: Date }

/**
 * Resolve the current user from the cookie. Validates signature + DB row + expiry.
 * Wrapped in React cache() so the layout and page in a single render pass share
 * one session lookup instead of each hitting the DB.
 */
export const getCurrentSession = cache(async (): Promise<AuthSession | null> => {
  const store = await cookies()
  const jwt = store.get(SESSION_COOKIE)?.value
  if (!jwt) return null
  const payload = await verifyToken(jwt)
  if (!payload) return null

  const session = await db.session.findUnique({
    where: { id: payload.sid },
    include: { user: true },
  })
  if (!session || session.userId !== payload.sub) return null
  if (session.expiresAt.getTime() < Date.now()) {
    await db.session.delete({ where: { id: session.id } })
    store.set(SESSION_COOKIE, '', { ...cookieOptions(new Date(0)), expires: new Date(0) })
    return null
  }

  // Sliding expiry: refresh when less than half the lifetime remains.
  const total = sessionDays() * 86400000
  const remaining = session.expiresAt.getTime() - Date.now()
  if (remaining < total / 2) {
    const expiresAt = new Date(Date.now() + total)
    await db.session.update({ where: { id: session.id }, data: { expiresAt } })
    const refreshed = await signToken(session.id, session.userId, expiresAt)
    store.set(SESSION_COOKIE, refreshed, cookieOptions(expiresAt))
    return { user: session.user, sessionId: session.id, expiresAt }
  }

  return { user: session.user, sessionId: session.id, expiresAt: session.expiresAt }
})

/** Server components/actions: require an authenticated user or bounce to /login. */
export async function requireUser(): Promise<User> {
  const session = await getCurrentSession()
  if (!session) redirect('/login')
  return session.user
}

export async function requireSession(): Promise<AuthSession> {
  const session = await getCurrentSession()
  if (!session) redirect('/login')
  return session
}

export async function endSession(): Promise<void> {
  const store = await cookies()
  const jwt = store.get(SESSION_COOKIE)?.value
  if (jwt) {
    const payload = await verifyToken(jwt)
    if (payload) await db.session.deleteMany({ where: { id: payload.sid } })
  }
  store.set(SESSION_COOKIE, '', { ...cookieOptions(new Date(0)), expires: new Date(0) })
}

export async function endAllSessions(userId: string, exceptSessionId?: string): Promise<void> {
  await db.session.deleteMany({
    where: { userId, ...(exceptSessionId ? { id: { not: exceptSessionId } } : {}) },
  })
}
