'use server'

import { globalSearch, type SearchHit } from '@/lib/services/search'
import { requireUserId } from './guard'

export async function searchAction(query: string): Promise<SearchHit[]> {
  const userId = await requireUserId()
  if (!userId) return []
  return globalSearch(userId, query)
}
