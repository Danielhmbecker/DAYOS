'use server'

import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { authenticate, canSetup, setupOwner } from '@/lib/services/auth'
import { endSession, startSession } from '@/lib/auth/session'
import { loginSchema, setupSchema } from '@/lib/validation/schemas'
import type { ActionResult } from './guard'

export async function loginAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const parsed = loginSchema.safeParse({
    email: formData.get('email'),
    password: formData.get('password'),
  })
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Invalid input' }
  }
  const ip = (await headers()).get('x-forwarded-for')?.split(',')[0]?.trim() ?? undefined
  const result = await authenticate(parsed.data, ip)
  if (!result.ok) return { ok: false, error: result.error }
  await startSession(result.userId, { userAgent: (await headers()).get('user-agent') ?? undefined, ip })
  redirect('/')
}

export async function setupAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const parsed = setupSchema.safeParse({
    name: formData.get('name'),
    email: formData.get('email'),
    password: formData.get('password'),
  })
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Invalid input' }
  }
  const result = await setupOwner(parsed.data)
  if (!result.ok) return { ok: false, error: result.error }
  await startSession(result.userId)
  redirect('/')
}

export async function logoutAction(): Promise<void> {
  await endSession()
  redirect('/login')
}

export async function isSetupAvailable(): Promise<boolean> {
  'use server'
  return canSetup()
}
