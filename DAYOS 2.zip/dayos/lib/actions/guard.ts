import { getCurrentSession } from '@/lib/auth/session'

export type ActionResult<T = undefined> =
  | { ok: true; data?: T }
  | { ok: false; error: string }

export async function requireUserId(): Promise<string | null> {
  const session = await getCurrentSession()
  return session?.user.id ?? null
}

export async function requireUserIdStrict(): Promise<string> {
  const id = await requireUserId()
  if (!id) throw new Error('Not authenticated')
  return id
}
