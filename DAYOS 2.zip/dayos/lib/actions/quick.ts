'use server'

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db/client'
import { requireUserId, type ActionResult } from './guard'
import {
  quickEventSchema,
  quickMoneySchema,
  quickNoteSchema,
  quickTaskSchema,
} from '@/lib/validation/schemas'
import { combineShiftTimes } from '@/lib/services/work'

function parse(form: FormData, shape: Record<string, unknown>) {
  const data: Record<string, unknown> = {}
  for (const key of Object.keys(shape)) {
    const value = form.get(key)
    data[key] = value === null ? undefined : String(value)
  }
  return data
}

export async function quickNoteAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = quickNoteSchema.safeParse({ title: form.get('title') })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await db.note.create({ data: { userId, title: parsed.data.title } })
  revalidatePath('/notes')
  revalidatePath('/')
  return { ok: true }
}

export async function quickTaskAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = quickTaskSchema.safeParse({
    title: form.get('title'),
    dueDate: form.get('dueDate') || undefined,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await db.task.create({
    data: { userId, title: parsed.data.title, dueDate: parsed.data.dueDate ?? null },
  })
  revalidatePath('/tasks')
  revalidatePath('/')
  return { ok: true }
}

export async function quickMoneyAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = quickMoneySchema.safeParse({
    type: form.get('type'),
    amount: form.get('amount'),
    note: form.get('note') || undefined,
    categoryId: form.get('categoryId') || undefined,
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await db.transaction.create({
    data: {
      userId,
      type: parsed.data.type,
      amount: parsed.data.amount,
      note: parsed.data.note ?? null,
      categoryId: parsed.data.categoryId || null,
    },
  })
  revalidatePath('/money')
  revalidatePath('/')
  return { ok: true }
}

export async function quickEventAction(_prev: ActionResult, form: FormData): Promise<ActionResult> {
  const userId = await requireUserId()
  if (!userId) return { ok: false, error: 'Not authenticated' }
  const parsed = quickEventSchema.safeParse({
    title: form.get('title'),
    date: form.get('date'),
    startTime: form.get('startTime'),
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  const start = combineShiftTimes(parsed.data.date, parsed.data.startTime)
  await db.calendarEvent.create({
    data: { userId, title: parsed.data.title, start },
  })
  revalidatePath('/calendar')
  revalidatePath('/')
  return { ok: true }
}

export { parse as parseFormShape }
