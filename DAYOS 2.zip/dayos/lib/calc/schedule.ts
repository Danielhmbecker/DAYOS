import type { Frequency } from '@prisma/client'

/** Minutes worked for a shift, supporting shifts that cross midnight. */
export function workedMinutes(start: Date, end: Date, breakMinutes = 0): number {
  let ms = end.getTime() - start.getTime()
  if (ms < 0) ms += 86400000 // crossed midnight
  const minutes = Math.round(ms / 60000) - breakMinutes
  return Math.max(0, minutes)
}

export function overtimeMinutes(worked: number, thresholdMinutes: number): number {
  return Math.max(0, worked - thresholdMinutes)
}

export type ShiftPay = {
  workedMinutes: number
  overtimeMinutes: number
  regularMinutes: number
  pay: number
}

export function shiftPay(
  start: Date,
  end: Date,
  breakMinutes: number,
  hourlyRate: number,
  overtimeThresholdMin: number,
  overtimeMultiplier: number,
): ShiftPay {
  const worked = workedMinutes(start, end, breakMinutes)
  const ot = overtimeMinutes(worked, overtimeThresholdMin)
  const regular = worked - ot
  const pay = (regular / 60) * hourlyRate + (ot / 60) * hourlyRate * overtimeMultiplier
  return { workedMinutes: worked, overtimeMinutes: ot, regularMinutes: regular, pay: round2(pay) }
}

export function hoursLabel(minutes: number): string {
  const h = Math.floor(minutes / 60)
  const m = minutes % 60
  return m === 0 ? `${h}h` : `${h}h ${m}m`
}

export function round2(n: number): number {
  return Math.round(n * 100) / 100
}

/** Interval length in days for a Frequency (month/year approximated for status colouring). */
export function frequencyDays(freq: Frequency): number {
  switch (freq) {
    case 'DAILY':
      return 1
    case 'WEEKLY':
      return 7
    case 'MONTHLY':
      return 30
    case 'YEARLY':
      return 365
  }
}

export function addFrequency(date: Date, freq: Frequency): Date {
  const d = new Date(date)
  switch (freq) {
    case 'DAILY':
      d.setDate(d.getDate() + 1)
      break
    case 'WEEKLY':
      d.setDate(d.getDate() + 7)
      break
    case 'MONTHLY': {
      // Clamp day-of-month so e.g. Jan 31 + 1 month → Feb 28/29 (no overflow).
      const day = d.getDate()
      const targetMonth = d.getMonth() + 1
      d.setDate(1)
      d.setMonth(targetMonth)
      const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()
      d.setDate(Math.min(day, lastDay))
      break
    }
    case 'YEARLY':
      d.setFullYear(d.getFullYear() + 1)
      break
  }
  return d
}

export type ScheduleStatus = 'ok' | 'due' | 'overdue'

/** Status of a recurring item given its last completion and frequency. */
export function scheduleStatus(lastCompletedAt: Date | null, freq: Frequency, now = new Date()): ScheduleStatus {
  if (!lastCompletedAt) return 'due'
  const due = addFrequency(lastCompletedAt, freq)
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  if (due.getTime() < todayStart.getTime()) return 'overdue'
  if (due.getTime() < todayStart.getTime() + 86400000) return 'due'
  return 'ok'
}

export function nextDueDate(lastCompletedAt: Date | null, freq: Frequency): Date | null {
  if (!lastCompletedAt) return null
  return addFrequency(lastCompletedAt, freq)
}
