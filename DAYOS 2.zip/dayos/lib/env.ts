import fs from 'node:fs'
import path from 'node:path'

/**
 * Minimal .env loader for CLI scripts (seed, embedded DB server, prisma CLI).
 * Next.js loads .env automatically for the app runtime; the Prisma CLI skips
 * auto-loading when prisma.config.ts exists, so we load it explicitly there.
 * Real environment variables always win over file values.
 */
export function loadEnv(dir = process.cwd()): void {
  const envPath = path.join(dir, '.env')
  if (!fs.existsSync(envPath)) return
  for (const line of fs.readFileSync(envPath, 'utf8').split('\n')) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/)
    if (!match) continue
    let value = match[2].trim()
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1)
    }
    if (process.env[match[1]] === undefined) process.env[match[1]] = value
  }
}
