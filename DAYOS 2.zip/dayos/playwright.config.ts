import { defineConfig, devices } from '@playwright/test'

/**
 * E2E tests run against a running DAYOS instance with a seeded database:
 *   npm run db:demo   (terminal 1, seeded)
 *   npm run build && npm run start   (terminal 2)
 *   npm run test:e2e
 *
 * On first run (empty DB) the suite uses the first-run owner setup flow.
 */
export default defineConfig({
  testDir: 'tests/e2e',
  timeout: 60000,
  expect: { timeout: 15000 },
  fullyParallel: false,
  retries: 1,
  reporter: [['list']],
  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://127.0.0.1:3000',
    trace: 'retain-on-failure',
  },
  projects: [
    {
      name: 'mobile-iphone-13',
      // Chromium engine with iPhone emulation (viewport, DPR, touch, UA).
      use: { ...devices['iPhone 13'], browserName: 'chromium' }, // 390×844
    },
    {
      name: 'mobile-iphone-se',
      use: { ...devices['iPhone SE'], browserName: 'chromium', viewport: { width: 375, height: 812 } },
    },
    {
      name: 'mobile-iphone-14-pro-max',
      use: { ...devices['iPhone 14 Pro Max'], browserName: 'chromium' }, // 430×932
    },
    {
      name: 'desktop',
      use: { ...devices['Desktop Chrome'], viewport: { width: 1280, height: 900 } },
    },
  ],
  webServer: {
    command: 'npm run start',
    url: 'http://127.0.0.1:3000/api/health',
    reuseExistingServer: true,
    timeout: 120000,
  },
})
