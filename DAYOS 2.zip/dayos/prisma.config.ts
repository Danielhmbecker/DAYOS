import path from 'node:path'
import { defineConfig } from 'prisma/config'
import { loadEnv } from './lib/env'

// The Prisma CLI does not auto-load .env when a config file exists.
loadEnv()

export default defineConfig({
  schema: path.join('prisma', 'schema.prisma'),
  migrations: {
    path: path.join('prisma', 'migrations'),
    seed: 'tsx prisma/seed.ts',
  },
})
